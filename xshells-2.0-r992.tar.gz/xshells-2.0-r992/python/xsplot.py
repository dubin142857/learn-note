#
#  Copyright (c) 2010-2016 Centre National de la Recherche Scientifique.
#  written by Nathanael Schaeffer (CNRS, ISTerre, Grenoble, France).
#
#  nathanael.schaeffer@univ-grenoble-alpes.fr
#
#  This software is governed by the CeCILL license under French law and
#  abiding by the rules of distribution of free software. You can use,
#  modify and/or redistribute the software under the terms of the CeCILL
#  license as circulated by CEA, CNRS and INRIA at the following URL
#  "http://www.cecill.info".
#
#  The fact that you are presently reading this means that you have had
#  knowledge of the CeCILL license and that you accept its terms.
#

"""XSHELLS Python/Matplotlib plotting module to load and display xspp output."""

if __name__ == "__main__":
    import matplotlib
    import os
    import argparse

    ## test if we are displaying on screen or not.
    nodisplay = True
    if 'DISPLAY' in os.environ:
        if len(os.environ['DISPLAY']) > 0:
            nodisplay = False

    parser = argparse.ArgumentParser(
        description='XSPP Python module to load and display xspp output.',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('fnames', nargs='+', default=None,
                        help='list of files to display (one figure per file)')
    parser.add_argument('--nodisplay', action='store_true',
                        help='set to inhibit display of the figure (forces a save)')
    parser.add_argument('-z', '--zoom', type=str, default="1",
                        help='zoom level for color bar')
    parser.add_argument('-c', '--components', type=str, default="",
                        help='component list to display')

    clin = parser.parse_args()

    nodisplay = nodisplay + clin.nodisplay
    if nodisplay:
        matplotlib.use("Agg")


from pylab import *     # matplotlib loaded after matplotlib.use("Agg")
import numpy            # loadtxt function
import matplotlib.ticker as ticker


#cmap = cm.PuOr
#cmap = cm.Spectral_r
#cmap = cm.BrBG
#cmap = cm.PiYG
cmap = cm.RdBu_r
#cmap = cm.seismic
#cmap = cm.afmhot
#cmap = cm.gist_heat

# a cool formatter:
fmt=ticker.ScalarFormatter(useMathText=True)
fmt.set_powerlimits((-3,3))
# simple formatter:
#fmt="%g"

## tuning
#rc("font", family="sans")
#rc("font", size=14)
#rc('text', usetex=1)
#rc('mathtext', fontset='stix')

## try to uncomment if you have problems with latex fonts.
#from matplotlib import rcParams
#rcParams['text.usetex']=True
#rcParams['text.latex.unicode']=True


def get_levels(mi,ma, nlevels, czoom):
    if isinstance(czoom, tuple):
        levels = linspace(czoom[0],czoom[1],nlevels+1)
        ext = 'both'
    else:
        if (mi<0) and (ma>0):
            m = max(-mi,ma)
            mi,ma = -m,m    # symmetric color scale
        if czoom == 1:
            levels = linspace(mi,ma,nlevels+1)
            ext = 'neither'
        else:
            c = (ma+mi)/2
            d = (ma-mi)/2
            levels = linspace(c-d/czoom,c+d/czoom,nlevels+1)
            ext = 'both'
    return levels, ext


def load_merid(file,ang=0):
    """ r,cost,V = load_merid(file,ang=0). If ang=1 : convert Up to angular velocity, if ang=2 convert Ut to angular velocity."""
    print('loading',file)
    a=numpy.loadtxt(file,comments='%')
    s = a.shape
    ir0 = 1

    ct = a[0,1:s[1]].reshape(1,s[1]-1)
    r = a[ir0:s[0],0].reshape(s[0]-ir0,1)

    a = a[ir0:s[0],1:s[1]]

    if ang > 0:
        st = sqrt(1-ct*ct)
        x = r*st
        y = r*ct
        #convert Up to angular velocity
        if (ang==1):
            print( amax(abs(x)) )
            a=a/x
            a[:,s[1]-2] = a[:,s[1]-3]   #remove nan
            a[:,0] = a[:,1]         #remove nan
        # convert Ut to angular velocity
        if (ang==2):
            a=a/sqrt(square(x) + square(y))

    return r,ct,a

def plot_merid(r,ct,a, strm=0, czoom=1, rg=0, rm=0, shift=0, title='', levels=20, cbar=1, cmap=cmap):
    """ m = plot_merid(r,ct,a, czoom=1, rg=0, rm=0, shift=0, title='')"""

    r = r.reshape(r.size,1)
    ct = ct.reshape(1,ct.size)
    st = sqrt(1-ct*ct)
    x = r*st
    y = r*ct

    mi,ma = amin(a), amax(a)
    m = max(-mi,ma)
    print('max value=',m)

    #figure()
    #pcolor(array(x),array(y),a,shading='interp')
    #colormaps : cm.PuOr, cm.RdBu, cm.RdGy

    if m>0:
        levels, ext = get_levels(mi,ma, levels, czoom)
        contourf(x+1.1*shift,y,a,levels,cmap=cmap, extend=ext)

    theta = linspace(-pi/2,pi/2,100)
    if rg>0:
        plot(rg*cos(theta)+1.1*shift,rg*sin(theta),color='gray')
    if rm>0:
        plot(rm*cos(theta)+1.1*shift,rm*sin(theta),color='gray')

    axis('equal')
    axis('off')
    if m>0 and cbar>0:
        colorbar(orientation='vertical',fraction=0.07,pad=0.02,format=fmt,extend='both')

    ms = amax(abs(strm))
    if ms > 0:          # plot contour of strm (stream lines)
        lev2 = arange(ms/18,ms,ms/9)
        contour(array(x),array(y),strm,lev2,colors='k')
        contour(array(x),array(y),strm,flipud(-lev2),colors='k')

    if title != '':
        rmax = amax(r)
        text(0.75*rmax,0.8*rmax,title, fontsize=28)

    return m


def load_disc(file,mres=1):
    """ r,phi, vr,vp,vz = plot_disc(file, mres=1)"""
    print('loading',file)
    a=numpy.loadtxt(file,comments='%')
    s = a.shape
    ir0 = 0

    n0 = int((s[1]-1)/3)
    np = mres*n0 +1
    ip = mgrid[0:np]
    ip[len(ip)-1] = 0   # ip loops around
    phi = ip*2*pi/(np-1)
    for i in range(1, mres):
        ip[(i*n0):((i+1)*n0)] = ip[0:n0]    # when mres > 1, we need to copy data around
    r = a[ir0:s[0],0].reshape(s[0]-ir0,1)

    vr = a[:, 1+ip*3]
    vp = a[:, 2+ip*3]
    vz = a[:, 3+ip*3]

    return r,phi, vr,vp,vz


def plot_disc(r,phi,b, czoom=1, rg=0, rm=0, title='',cmap=cmap, levels=20):
    """ plot_disc(r,phi,v, czoom=1, rg=0, rm=0, title='')"""

    r = r.reshape(r.size,1)
    phi = phi.reshape(1,phi.size)
    x = r*cos(phi)
    y = r*sin(phi)

    mi,ma = amin(b), amax(b)
    m = max(-mi,ma)
    print('max value=',m)
    if m > 0.0:
        levels, ext = get_levels(mi,ma, levels, czoom)
        p = contourf(x,y,b,levels,cmap=cmap, extend=ext)
        axis('equal')
        axis('off')

        #if czoom == 1:
            #clim(-m/czoom,m/czoom)
        #subplots_adjust(left=0.02, bottom=0.02, right=0.98, top=0.98, wspace=0.1, hspace=0.1)
        subplots_adjust(left=0.05, bottom=0.05, right=0.95, top=0.95, wspace=0.2, hspace=0.2)
        #fmt = ticker.FormatStrFormatter("%.3e")
        fmt=ticker.ScalarFormatter(useMathText=True)
        fmt.set_powerlimits((-3,3))
        colorbar(format=fmt)

        theta = linspace(-pi/2,pi/2,100)
        if rg>0:
            plot(rg*cos(theta),rg*sin(theta),color='gray')
            plot(-rg*cos(theta),rg*sin(theta),color='gray')
        if rm>0:
            plot(rm*cos(theta),rm*sin(theta),color='gray')
            plot(-rm*cos(theta),rm*sin(theta),color='gray')
        if title != '':
            figtext(0.65, 0.9, title, fontsize=28)

    return m

def load_surf(file):
    """ theta,phi, ur,ut,up = load_surf(file)"""
    print('loading',file)
    a=numpy.loadtxt(file,comments='%')
    s = a.shape

    t = a[0,1:s[1]:3]
    t = t * 180./pi
    p = a[1:s[0],0]
    p = p * 180./pi

    ur = a[1:s[0],1::3].T   # transpose
    ut = a[1:s[0],2::3].T
    up = a[1:s[0],3::3].T

    return t,p,ur,ut,up


def plot_surf(theta, phi, vx, czoom=1, rg_r=0, title='', cmap=cmap, levels=20):
    """ Aitoff projection: plot_surf(theta, phi, vx, czoom=1, rg_r=0, title='', cmap=cmap )"""

    mi,ma = amin(vx), amax(vx)
    m = max(-mi,ma)
    print('max value=',m)
    if m > 0.0:
        t = (90.-theta)*pi/180.

        phi = phi.reshape(phi.size)
        ip = mgrid[0:phi.size]
        ip[ip.size-1] = 0   # ip loops around
        p = (phi[ip] - 180)*pi/360  # longitude
        p[ip.size-1] = pi/2         # last phi value.

        t = t.reshape(t.size, 1)
        p = p.reshape(1, p.size)
        print('=> Aitoff projection')
        al = arccos(cos(t)*cos(p))
        al = al / sin(al)
        x = 2*al * (cos(t)*sin(p))
        y = al * (sin(t)*(p*0+1))

        if rg_r > 0:        # compute the tangent cylinder.
            pp = linspace(-pi/2,pi/2,100)
            tt = arccos(rg_r)
            al = arccos(cos(tt)*cos(pp))
            al = al / sin(al)
            xg = 2*al * (cos(tt)*sin(pp))
            yg = al * (sin(tt)*(pp*0+1))

        b = vx[:,ip]

        levels, ext = get_levels(mi,ma, levels, czoom)
        contourf(x,y,b,levels,cmap=cmap, extend=ext)

        axis('equal')
        axis('off')
        #subplots_adjust(left=0.02, bottom=0.1, right=0.98, top=0.95, wspace=0.1, hspace=0.1)
        #subplots_adjust(left=0.05, bottom=0.05, right=0.95, top=0.95, wspace=0.2, hspace=0.2)
        #subplots_adjust(left=0.01, bottom=0.1, right=0.99, top=0.99, wspace=0.2, hspace=0.2)
        cb=colorbar(orientation='horizontal',fraction=0.05,pad=0.01,format=fmt)
    #   cb.ax.yaxis.get_major_locator()._nbins=4
    #   clim(-m/czoom,m/czoom)
        xlim(-3.2,3.2)
        ylim(-1.6,1.6)

        if rg_r > 0:        # show the tangent cylinder.
            plot(xg,yg,color='gray')
            plot(xg,-yg,color='gray')

        plot(2*p,p*0,color='gray',linestyle='dashed');  # show equator
        if title != '':
            text(2.6, 1.2, title, fontsize=20 )

    return m

def stream_surf(theta, phi, vt, vp, col=0, czoom=1, rg_r=0, projection='aitoff', cmap=cmap):
    """ streamlines and colormap with projection: stream_surf(theta, phi, vt, vp, col, czoom=1, rg_r=0, title='', projection='aitoff' )"""

    vm=sqrt(amax(vt*vt + vp*vp))
    print('max vector value=',vm)
    mi,ma = amin(col), amax(col)
    m = max(-mi,ma)
    print('max scalar value=',m)

    ax=subplot(111,projection=projection)
    if (vm+m) > 0.0:
        t = (90.-theta)*pi/180.

        phi = phi.reshape(phi.size)
        ip = mgrid[0:phi.size+1]
        ip[ip.size-1] = 0   # ip loops around
        p = (phi[ip] - 180.)*pi/180.    # longitude
        p[ip.size-1] = pi           # last phi value.

        t = t.reshape(t.size, 1)
        p = p.reshape(1, p.size)
        print('=> %s projection' % projection)
        x = ones(t.shape)*p
        y = t*ones(p.shape)

        strmcol='k'

        if m>0:
            d = col[:,ip]
            levels, ext = get_levels(mi,ma, 10, czoom)
            pcolormesh(x,y,d,shading='gouraud',cmap=cmap)
            clim(levels[0],levels[-1])
            cb=colorbar(orientation='horizontal',fraction=0.05,pad=0.05,format=fmt, extend=ext)
            cb.ax.yaxis.get_major_locator()._nbins=4
            strmcol='m'     # better seen when there is a colormap in the background...

        if vm>0:
            b = vp[:,ip]
            c = -vt[:,ip]*sin(pi/2-y)       ## mulitply by sin(theta) to workaround a bug
            v2=sqrt(b*b + c*c)
            streamplot(x,y,b,c, color=strmcol,linewidth=v2*(5./vm))

        tick_params(
            axis='x',          # changes apply to the x-axis
            which='both',      # both major and minor ticks are affected
            bottom='off',      # ticks along the bottom edge are off
            top='off',         # ticks along the top edge are off
            labelbottom='off') # labels along the bottom edge are off

    return m+vm

def plot_spec(filename,ir_list=None):
    """loads a spectrum as saved by xspp"""
    sp = loadtxt(filename, comments='%')
    r = sp[:,0]				# radius
    nr = sp.shape[0]
    if ir_list is None:
        ir_list = [10,nr//2,nr-11]		# list of radius indices to plot

    with open(filename) as f:
        a = f.readline()
        if a.startswith('% [XSHELLS] Energy spectrum : MMAX='):
            l = arange(0, sp.shape[1]-1)
            for ir in ir_list:
                loglog(l, sp[ir,1:], label="r=%g" % r[ir])
            xlabel('$\ell$')

        if a.startswith('% [XSHELLS] Energy spectrum : LMAX='):
            m = arange(0, sp.shape[1]-1) + 1
            for ir in ir_list:
                loglog(m, sp[ir,1:], label="r=%g" % r[ir])
            xlabel('$m+1$')

        grid(which='both')
        legend(loc='best')

def load_diags(filename):
    """returns a dictionary of time series for easy lookup (or a numpy array if no header found)"""
    import re   # regular expression
    f = open(filename, 'r')
    h = f.readline()
    header = None
    while h[0] == '%':
        header = h
        print(header)       # display header
        h = f.readline()
    f.close()
    data = loadtxt(filename,comments='%')      # load data
    if header is not None:        # there is a header
        header = header.lstrip('% \n')        # the header
        RE=re.compile(r'[,\s\t]+')  # regex to split up fields
        field=RE.split(header)[0:-1]
        d = {}      # empty dict
        for i in range(0,len(field)):
            if field[i] in d:      # handle collisions
                field[i] = '%s_%d' % (field[i],i)
            d[field[i]] = data[:,i]
        data = d
    return data

def load_slice_npy(filename):
    """load a field slice produced by xspp in numpy format"""
    a = load(filename)      # load numpy data directly
    tag = a[:,0,0]
    x = a[0,1:,0]
    y = a[0,0,1:]
    data = a[:,1:,1:]
    return x,y,data,tag

def get_slice_name(tag):
    comp = { 0: '', 1: '_r', 2: r'_\theta', 3: r'_\phi', 4: '_s', 5: '_x', 6: '_y', 7: '_z', 8: '_P', 9: '_T' }
    tag = int(tag)
    name = comp[tag&15]
    if (tag>>4)&4095 > 0:
        name = chr(((tag >> 4)&63) +64) + name
        if (tag >> 10)&63 > 0:
            name = chr(((tag >> 10)&63) +64) + name
    return name

def get_cmap(name=''):
    cmap = cm.RdBu_r
    if len(name) > 0:
        if   name[0] == 'T':  cmap = cm.inferno
        elif name[0] == 'B':  cmap = cm.PRGn_r
    return cmap

def plot_slice(y, i=0, czoom=1, title_prefix='', levels=20, cmap=None, name=None):
    """plot a field slice produced by xspp in numpy format"""
    if type(y) == str:      # if filename, load it
        y = load(y)
    tag = int(y[i,0,0])
    # decode field name and component
    if name is None:
        name = get_slice_name(tag)
    # choose colormap:
    if cmap is None:
        cmap = get_cmap(name)
    # choose correct plot type
    plottype = tag >> 16
    if plottype == 0:      # a merid plot
        plot_merid(y[i,1:,0], cos(y[i,0,1:]), y[i,1:,1:], cmap=cmap, czoom=czoom, levels=levels)
    elif plottype == 1:    # a disc plot (periodic)
        a=empty((y.shape[1],y.shape[2]))
        a[:,0:-1] = y[i,:,1:]           # copy
        a[:,-1] = y[i,:,1]              # loop around
        a[0,-1] = 2*a[0,-2]-a[0,-3]     # next phi-step (not necessarily a full disc)
        plot_disc(y[i,1:,0], a[0,:], a[1:,:], cmap=cmap, czoom=czoom, levels=levels)
    elif plottype == 2:    # a surf plot
        plot_surf(y[i,0,1:]*180./pi, y[i,1:,0]*180./pi, y[i,1:,1:].T, cmap=cmap, czoom=czoom, levels=levels)
    title( title_prefix + '$' + name + '$' )
    return name

def slice2vtk(fname_vtk, y, phi=0, r=1, z=0):
    """export a slice or slices (special numpy arrays from xspp) to vtk format for paraview"""
    from evtk.hl import gridToVTK
    def add_periodic(y):
        a=empty_like(y)
        a[:,:,0:-1] = y[:,:,1:]           # copy
        a[:,:,-1] = y[:,:,1]              # loop around
        a[:,0,-1] = 2*a[:,0,-2]-a[:,0,-3]     # next phi-step (not necessarily a full disc)
        phi = a[0,0,:].reshape(1,-1)
        a = a[:,1:,:]       # remove phi coordinate from data
        return a, phi

    if type(y) == tuple:
        y = vstack(y)
    tags = y[:,0,0].astype(int)
    slicetype = tags >> 16
    ## assign field names:
    comp = { 0: '', 1: 'r', 2: 'theta', 3: 'phi', 4: 's', 5: 'x', 6: 'y', 7: 'z', 8: 'P', 9: 'T' }
    names = []
    for tag in tags:
        name = comp[tag&15]
        if (tag>>4)&4095 > 0:
            name = chr(((tag >> 4)&63) +64) + name
            if (tag >> 10)&63 > 0:
                name = chr(((tag >> 10)&63) +64) + name
        names.append(name)

    pd = {}
    if all(slicetype == 0):     # a meridian cut
        r = y[0,1:,0].reshape(-1,1)
        th = y[0,0,1:].reshape(1,-1)
        st,ct = sin(th),cos(th)
        sp,cp = sin(phi),cos(phi)
        n1,n2 = y.shape[1]-1, y.shape[2]-1

        for k in range(y.shape[0]):
            if (tags[k]&15) in (0,1,2,3):       # scalar, and r,theta,phi components only.
                pd[names[k]] = y[k,1:,1:].reshape(-1, n2, 1).copy()
        # detect and handle vectors:
        for k in range(y.shape[0]-2):
            if all((tags[k:k+3] & 15) == array([3,4,7])):     # phi,s,z
                vx = y[k+1,1:,1:]*cp - y[k,1:,1:]*sp
                vy = y[k+1,1:,1:]*sp + y[k,1:,1:]*cp
                pd[names[k+1][:-1]] = (vx.reshape(-1, n2, 1).copy(), vy.reshape(-1, n2, 1).copy(), y[k+2,1:,1:].reshape(-1, n2, 1).copy())
    elif all(slicetype == 1):   # a disc (periodic), coords are s,phi,z
        a, phi = add_periodic(y)
        r = y[0,1:,0].reshape(-1,1)
        sp,cp = sin(phi),cos(phi)
        st,ct = 1., 0.
        n1,n2 = y.shape[1]-1, y.shape[2]

        for k in range(y.shape[0]):
            pd[names[k]] = a[k,:,:].reshape(-1, n2, 1).copy()
        # detect and handle vectors:
        for k in range(y.shape[0]-2):
            if all((tags[k:k+3] & 15) == array([4,3,7])):     # s,phi,z
                vx = a[k,:,:]*cp - a[k+1,:,:]*sp
                vy = a[k,:,:]*sp + a[k+1,:,:]*cp
                pd[names[k][:-1]] = (vx.reshape(-1, n2, 1).copy(), vy.reshape(-1, n2, 1).copy(), a[k+2,:,:].reshape(-1, n2, 1).copy())
    elif all(slicetype == 2):   # a shpere
        y = y.swapaxes(1,2)
        a, phi = add_periodic(y)
        th = y[0,1:,0].reshape(-1,1)
        sp,cp = sin(phi),cos(phi)
        st,ct = sin(th),cos(th)
        n1,n2 = y.shape[1]-1, y.shape[2]

        for k in range(y.shape[0]):
            pd[names[k]] = a[k,:,:].reshape(-1,n2,1).copy()
        # detect and handle vectors:
        for k in range(y.shape[0]-2):
            if all((tags[k:k+3] & 15) == array([1,2,3])):     # r,theta,phi
                vz = a[k,:,:]*ct - a[k+1,:,:]*st
                vs = a[k,:,:]*st + a[k+1,:,:]*ct
                vx = vs*cp - a[k+2,:,:]*sp
                vy = vs*sp + a[k+2,:,:]*cp
                pd[names[k][:-1]] = (vx.reshape(-1, n2, 1).copy(), vy.reshape(-1, n2, 1).copy(), vz.reshape(-1, n2, 1).copy())
    else:
        print("slice2vtk ERROR !")

    X = empty( (n1, n2, 1) )
    Y = empty_like(X)
    Z = empty_like(X)
    X[:,:,0] = r*st*cp
    Y[:,:,0] = r*st*sp
    Z[:,:,0] = r*ct + z
    gridToVTK(fname_vtk, X, Y, Z, pointData = pd)


if __name__ == "__main__":
    czoom = eval(clin.zoom)
    figsze = (12,8)
    px = ''
    for fn in clin.fnames:
        print(fn)
        if fn.endswith(".npy"):     # we have a new numpy file format
            a = load(fn)    # load numpy data
            comp = range(0,a.shape[0])
            print(comp)
            if clin.components != '':
                comp = eval(clin.components + ',')
            print(comp)
            for idx in comp:
                if amax(abs(a[idx,1:,1:])) > 0:
                    figure(figsize=figsze)
                    if len(clin.fnames) > 1:    # include filename in title if we have more than one
                        px = fn + ' '
                    plot_slice(a, idx, czoom=czoom, title_prefix=px)
                    if nodisplay:
                        savefig(fn.replace('.npy', '-%d.png' % idx))
        else:
            with open(fn) as f:
                a = f.readline()
                if a == '%plot_merid.py\n':
                    figure(figsize=figsze)
                    plot_merid(*load_merid(fn), czoom=czoom)
                    title(fn)
                if a == '%plot_disc.py\n':
                    r,phi, vr,vp,vz = load_disc(fn)
                    vv = (vr,vp,vz)
                    ss = (r"$s$",r"$\phi$",r"$z$")
                    comp = (0,1,2)
                    if clin.components != '':
                        comp = eval(clin.components + ',')
                    for idx in comp:
                        v,s = vv[idx],ss[idx]
                        if amax(abs(v)) > 0:
                            figure(figsize=figsze)
                            plot_disc(r, phi, v, czoom=czoom)
                            title("%s %s" % (fn,s))
                if a == '%plot_surf.py\n':
                    t,p,vr,vt,vp = load_surf(fn)
                    vv = (vr,vt,vp)
                    ss = (r"$r$",r"$\theta$",r"$\phi$")
                    comp = (0,1,2)
                    if clin.components != '':
                        comp = eval(clin.components + ',')
                    for idx in comp:
                        v,s = vv[idx],ss[idx]
                        if amax(abs(v)) > 0:
                            figure(figsize=figsze)
                            plot_surf(t, p, v, czoom=czoom)
                            title("%s %s" % (fn,s))
                if a.startswith('% [XSHELLS] Energy spectrum'):
                    irlist = None
                    if clin.components != '':
                        irlist = eval(clin.components + ',')
                        print(irlist)
                    figure()
                    plot_spec(fn,ir_list=irlist)
                if a.lstrip('% \n')[0] == 't':     # energy and diagnostics file
                    d = load_diags(fn)
                    t = d['t']
                    job = fn
                    if fn.startswith('energy.'):
                        job = job[7:]
                    keys = ('Eu','Eb')
                    if clin.components != '':
                        keys = clin.components.split(',')
                    for k in keys:
                        semilogy(t, d[k], label=k + ' ' + job)
                    xlabel('t')
                    grid()
                    legend(loc='best')
                    title(job)
                if nodisplay:
                    savefig(fn + '.png')

    if not nodisplay:
        show()
