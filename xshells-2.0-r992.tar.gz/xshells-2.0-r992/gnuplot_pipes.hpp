#ifndef _GNUPLOT_PIPES_H_
#define _GNUPLOT_PIPES_H_

#include <iostream>
#include <string>
#include <fstream>
#include <cstdio>
#include <cstdlib>              // for getenv()

class Gnuplot
{
    private:
	///\brief pointer to the stream that can be used to write to the pipe
        FILE *gnucmd;
        int output;		///< 0: no output;  1: screen;  2: png file;  3: both.
        std::string setpng;
        std::string plotcmd;

    public:
		int  init(const std::string &filename, int out=1);		// screen output by default (defaulting to png)

       Gnuplot();
       ~Gnuplot();

		bool is_valid() { return(gnucmd != 0); }

		/// send a command to gnuplot
        Gnuplot& cmd(const std::string &cmdstr);
        Gnuplot& set_plotcmd(const std::string &cmdstr);
		Gnuplot& plot(); 	 // output plot
		Gnuplot& save();	// output plot to file

		Gnuplot& showonscreen(); // window output is set by default (x11/aqua)
		Gnuplot& writetopng(); 	 // output to file

		/// resets a gnuplot session (next plot will erase previous ones)
		Gnuplot& reset_plot();

		/// resets a gnuplot session and sets all variables to default
		Gnuplot& reset_all();
};


//------------------------------------------------------------------------------
//
// constructor: set a style during construction
//
inline Gnuplot::Gnuplot()
{
	gnucmd = 0;
	output = 0;
}

Gnuplot::~Gnuplot()
{
    // A stream opened by popen() should be closed by pclose()
    if (gnucmd) {
		save();
		pclose(gnucmd);
	}
}



//------------------------------------------------------------------------------
//
// sets terminal type to windows / x11
//
Gnuplot& Gnuplot::showonscreen()
{
    cmd("set output");
    cmd("set terminal x11");
    return *this;
}

Gnuplot& Gnuplot::writetopng()
{
	cmd("set output");
	cmd("set terminal png");
	cmd(setpng);
    return *this;
}


//------------------------------------------------------------------------------
//
// Sends a command to an active gnuplot session
//
Gnuplot& Gnuplot::cmd(const std::string &cmdstr)
{
    if( gnucmd )
    {
		// int fputs ( const char * str, FILE * stream );
		// writes the string str to the stream.
		// The function begins copying from the address specified (str) until it 
		// reaches the terminating null character ('\0'). This final 
		// null-character is not copied to the stream.
		fputs( (cmdstr+"\n").c_str(), gnucmd );

		// int fflush ( FILE * stream );
		// If the given stream was open for writing and the last i/o operation was 
		// an output operation, any unwritten data in the output buffer is written 
		// to the file.  If the argument is a null pointer, all open files are 
		// flushed.  The stream remains open after this call.
		fflush(gnucmd);
    }
    return *this;
}

Gnuplot& Gnuplot::set_plotcmd(const std::string &cmdstr)
{
	plotcmd = cmdstr;
    return *this;
}

Gnuplot& Gnuplot::plot()
{
	if (output & 1) {
		showonscreen();
		cmd(plotcmd);
	}
	if (output & 2) {
		writetopng();
		cmd(plotcmd);
	}
	return *this;
}

/// Save to png if it has not been saved yet.
Gnuplot& Gnuplot::save()
{
	if ((output & 2) == 0) {
		writetopng();
		cmd(plotcmd);
	}
	return *this;
}


//------------------------------------------------------------------------------
//
// Opens up a gnuplot session, ready to receive commands
//
int Gnuplot::init(const std::string &filename, int out)
{
	// store output filename
	setpng = "set output '" + filename + "'";

    // FILE *popen(const char *command, const char *mode);
    // The popen() function shall execute the command specified by the string 
    // command, create a pipe between the calling program and the executed 
    // command, and return a pointer to a stream that can be used to either read
    // from or write to the pipe.
    gnucmd = popen("gnuplot","w");

    // popen() shall return a pointer to an open stream that can be used to read
    // or write to the pipe.  Otherwise, it shall return a null pointer and may 
    // set errno to indicate the error.
    if (!gnucmd)
    {
        //throw GnuplotException("Couldn't open connection to gnuplot");
        fprintf(stderr, "Can't open connection to gnuplot");
        return -2;
    }

    // char * getenv ( const char * name );  get value of environment variable
    // Retrieves a C string containing the value of the environment variable 
    // whose name is specified as argument.  If the requested variable is not 
    // part of the environment list, the function returns a NULL pointer.

	if (out&1) {		// screen display requested	
		char* disp = getenv("DISPLAY");
		if ((disp)&&(strlen(disp) > 0)) {	// we prabably have a correct display.
			output |= 1;	// enable screen output
		} else {
			output |= 2;	// default to png output instead.
		}
	}
	if (out&2)	output |= 2;		// png output requested.

    return 0;	// success.
}



//------------------------------------------------------------------------------
//
// resets a gnuplot session and sets all varibles to default
//
Gnuplot& Gnuplot::reset_all()
{
    cmd("reset");
    cmd("clear");
    return *this;
}

#endif
