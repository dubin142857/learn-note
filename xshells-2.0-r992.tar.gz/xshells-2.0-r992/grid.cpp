/*
 * Copyright (c) 2010-2016 Centre National de la Recherche Scientifique.
 * written by Nathanael Schaeffer (CNRS, ISTerre, Grenoble, France).
 * 
 * nathanael.schaeffer@univ-grenoble-alpes.fr
 * 
 * This software is governed by the CeCILL license under French law and
 * abiding by the rules of distribution of free software. You can use,
 * modify and/or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info".
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */

/// \file grid.cpp
/// Radial finite difference setup.

/** \file grid.cpp
  x-banded matrix inversion (x = 3,5).
	- Boundary condition are taken into acount (or not !).
	- For temporal semi-implicit evolution of fields.
	- Matrices have size NR*(LMAX+1), decomposition is done on NR.
*/

// Handles the various OpenMP possibilities (XS_OMP=1 by default).
#ifndef _OPENMP
	#undef XS_OMP
	#define XS_OMP 0
#else
	#ifndef XS_OMP
		#define XS_OMP 1
	#endif
#endif

#include <complex>
typedef std::complex<double> cplx;

/// finite difference approximations to derivatives
#include "findiff.hpp"

/// A tri-diagonal matrix.
struct TriDiag {
	double l,d,u;		// lower, diagonal, upper.
};

/// A penta-diagonal matrix.
struct PentaDiag {
	double l2,l1, d ,u1,u2;
};

template <typename T, unsigned N>
class LinOpN {
	double *data;		///< store the matrix elements
	int ir_bci, ir_bco;		///< global boundaries

	void _free();

  public:
    LinOpN() : ir_bci(0), ir_bco(-1), data(0) {}
    ~LinOpN() { _free(); }
	void alloc(int ir0, int ir1);
	int bandwidth() const { return (N-1)/2; }

    inline double* Mr(int ir) const { return data + N*ir; }		// data pointer already shifted.
//    inline double* operator()(int ir) const { return Mr(ir)+(N-1)/2; }
	inline T& operator[](int ir) const { return *((T*) Mr(ir)); }		// Backward compatibility to TriDiag/PentaDiag arrays
	inline double coeff(int ir, const int dir) const { return Mr(ir)[(N-1)/2 + dir]; }
};

typedef LinOpN<TriDiag,3> LinOp3;
typedef LinOpN<PentaDiag,5> LinOp5;


/* SPHERICAL HARMONICS using SHTns v2*/
/// \name global variables for spherical harmonics.
//@{
shtns_cfg shtns = NULL;
int NLM, LMAX, MMAX;		// spherical harmonic sizes.
int MRES=1;
int NLAT=0;
int NPHI=0;
shtns_norm sht_norm;
const unsigned short *li;		// integer l array
double *__restrict el;
double *__restrict l2;
double *__restrict l_2;
const double *ct;
const double *st;
const double *wg;	// gauss weights for integration.
#ifdef VAR_LTR
unsigned short *__restrict ltr = NULL;		///< dynamic l truncation.
#endif
//@}

/// \name global variables for spatial discretization.
//@{
int NR;	///< total number of radial shells
int NG;	///< radial shell for the solid inner core limit
int NM;	///< radial shell for the base of the mantle

#ifdef XS_MPI
  int i_mpi, n_mpi;				// mpi rank and number of processes.
  int irs_mpi, ire_mpi;			// limits (inclusive) for this mpi process (excluding ghots shells)
  int *__restrict r_owner = NULL;
  /// true if the shell is owned by me
  #define own(ir) (i_mpi == r_owner[ir])
  #define PRINTF0 if (i_mpi==0) printf
#else
  #define irs_mpi 0
  #define ire_mpi (NR-1)
  #define i_mpi 0
  #define n_mpi 1
  // always true
  #define own(ir) 1
  #define PRINTF0 printf
#endif
double *__restrict r = NULL;	///< r[i] is the radius of grid points i<NR. NULL at init time.
double *__restrict r_1 = NULL;	///< 1/r at each grid point.
double *__restrict r_2;			///< 1/(r^2) 

//@}

/// \name Finite difference operators.
//@{
LinOp3 Gr;		///< Gradient operator
LinOp3 Wr;		///< Vorticity operator Wr = 1/r Gr( r . )
LinOp3 Lr;		///< scalar radial Laplacian operator.
//@}


#undef LM_L_LOOP
#undef LM_LOOP2
#undef LM_L_LOOP2
///\def LM_L_LOOP : loop over all (l,im) and perform "action"  : l and lm are defined. (but NOT m and im)
//  single-loop + lookup array : no assumption on l-storage is made + FASTER !! (cache miss seems better than branch prediction miss...)
#define LM_L_LOOP( action ) { int lm=0; do { int l=li[lm]; action } while(++lm < NLM); }
// partial loop (useful for parallel operation)
#define LM_LOOP2( lms, lme, action ) { int lm=(lms); do { action } while(++lm <= (lme)); }
#define LM_L_LOOP2( lms, lme, action ) { int lm=(lms); do { int l=li[lm]; action } while(++lm <= (lme)); }

#undef LiM
#undef LM
#define LiM(l,im) ( shtns->lmidx[im] + (l) )
#define LM(l,m) ( shtns->lmidx[((unsigned)(m))/shtns->mres] + (l) )

#define Y00_1 sh00_1(shtns)
#define Y10_ct sh10_ct(shtns)
#define Y11_st sh11_st(shtns)


#if XS_VEC && __SSE2__
	// GCC vector support
  #ifdef __AVX512F__
	#include <immintrin.h>
	#ifdef XS_DEBUG
		#warning "using AVX-512 vectorization"
	#endif
	#define VSIZE 8
	// number of rnd vectors in a 2D-array (NLAT must be multiple of 8)
	#define NV2D ((NPHI*NLAT)>>3)
	#define VNLAT (NLAT>>3)
	typedef double rnd __attribute__ ((vector_size (64)));
	#define vall(x) (rnd)_mm512_set1_pd(x)
	#define vread(mem, idx) (rnd)_mm512_loadu_pd( ((double*)(mem)) + (idx)*8 )
	#define vstore(mem, idx, val) _mm512_storeu_pd(((double*)(mem)) + (idx)*8, val)
	#define vmemadd(mem, idx, val) _mm512_storeu_pd(((double*)(mem)) + (idx)*8, val + vread(mem, idx))
	#define vmax(a,b) _mm512_max_pd(a,b)
  #elif defined __AVX__
	#include <immintrin.h>
	#ifdef XS_DEBUG
		#warning "using AVX vectorization"
	#endif
	#define VSIZE 4
	// number of rnd vectors in a 2D-array (NLAT must be multiple of 4)
	#define NV2D ((NPHI*NLAT)>>2)
	#define VNLAT (NLAT>>2)
	typedef double rnd __attribute__ ((vector_size (32)));
	#define vall(x) (rnd)_mm256_set1_pd(x)
	#define vread(mem, idx) (rnd)_mm256_loadu_pd( ((double*)(mem)) + (idx)*4 )
	#define vstore(mem, idx, val) _mm256_storeu_pd(((double*)(mem)) + (idx)*4, val)
	#define vmemadd(mem, idx, val) _mm256_storeu_pd(((double*)(mem)) + (idx)*4, val + vread(mem, idx))
	#define vmax(a,b) _mm256_max_pd(a,b)
  #else
	#ifdef __SSE3__
		#include <pmmintrin.h>
		#ifdef XS_DEBUG
			#warning "using SSE3 vectorization"
		#endif
	#else
		#include <emmintrin.h>
		#ifdef XS_DEBUG
			#warning "using SSE2 vectorization"
		#endif
	#endif
	#define VSIZE 2
	// number of rnd vectors in a 2D-array (NLAT must be even)
	#define NV2D ((NPHI*NLAT)>>1)
	#define VNLAT (NLAT>>1)
	typedef double rnd __attribute__ ((vector_size (16)));
	#define vall(x) vdup(x)
	#define vread(mem, idx) ((s2d*)(mem))[idx]
	#define vstore(mem, idx, val) ((s2d*)(mem))[idx] = (val)
	#define vmemadd(mem, idx, val) ((s2d*)(mem))[idx] += (val)
	#define vmax(a,b) _mm_max_pd(a,b)
  #endif
	// number of s2d vectors in a 2D-array (NLAT must be even)
	#define NS2D ((NPHI*NLAT)>>1)
	#define S2DNLAT (NLAT>>1)
	typedef double s2d __attribute__ ((vector_size (16)));		// vector that should behave like a real scalar for complex number multiplication.
	typedef double v2d __attribute__ ((vector_size (16)));		// vector that contains a complex number
	typedef double s2f;			// 2 floats that can be tested for 0 to a double.
	// vdup(x) takes a double and duplicate it to a vector of 2 doubles.
	#define vdup(x) (s2d)_mm_set1_pd(x)
	// convert a vector of 2 floats to a vector of 2 doubles
	#define vfloat(x) _mm_cvtps_pd( *((__m128*) &(x)) )
	#ifdef __SSE3__
		#define ADDI(a,b)  (v2d)_mm_addsub_pd(a, _mm_shuffle_pd(b,b,1))		// a + I*b
	#else
		const s2d imul_mask = _mm_unpackhi_pd((s2d) _mm_slli_epi64(_mm_cmpeq_epi16(_mm_set1_epi64x(0), _mm_set1_epi64x(0)), 63), vdup(0.));	// (-0, 0)
		#define ADDI(a,b)  ( (a) + _mm_xor_pd(_mm_shuffle_pd(b,b,1), imul_mask) )		// a + I*b
	#endif
	#ifdef __clang__
		// allow to compile with clang (llvm)
		#define VSUM(a) ( (a)[0]+(a)[1] )
	#else
		// gcc extensions
		#define VSUM(a) ( _mm_cvtsd_f64( (a) + (s2d)_mm_unpackhi_pd((a),(a))) )	//__builtin_ia32_vec_ext_v2df(a,0) + __builtin_ia32_vec_ext_v2df(a,1) )
	#endif
#else
	#undef XS_VEC
	#define VSIZE 1
	typedef double rnd;
	typedef double s2d;
	typedef cplx v2d;
	typedef float s2f;
	#define vdup(x) (x)
	#define vfloat(x) (x)
	#define ADDI(a,b) cplx(real(a)-imag(b), imag(a)+real(b))
	#define VSUM(a) (a)
	// number of doubles in a 2D-array
	#define NV2D (NPHI*NLAT)
	#define NS2D (NPHI*NLAT)
	#define VNLAT NLAT
	#define S2DNLAT NLAT
	#define vall(x) (x)
	#define vread(mem, idx) ((double*)mem)[idx]
	#define vstore(mem, idx, val) ((double*)mem)[idx] = (val)
	#define vmemadd(mem, idx, val) ((double*)mem)[idx] += (val)
	#define vmax(a,b) ((a) > (b)) ? (a) : (b)
#endif

#define IN_RANGE_INCLUSIVE(i, low, high) ((unsigned)((i)-(low)) <= ((high)-(low)))


// isNaN testing that works with -ffast-math
/*
double isNaN_0=0, isNaN_1=1;
int isNaN(double x) {
        return ((x == isNaN_0)&&(x == isNaN_1));		// this works with gcc (4.7.2), but NOT with icc (13)
}

volatile double t;
int isNaN(double x) {
	t = x;
	return t != x;		// this works with icc (13) but NOT with gcc (4.7.2)
}

/// this works with gcc (4.7.2) and icc (13) but FAILS with gcc 4.8 and -ffast-math !!!
#define isNaN(x) isnan(x)
*/

// works for IEEE754 double
int isNaN(double d) {
	union { double d; unsigned long long x; } u = { d };
	return (u.x << 1) > 0xff70000000000000ull;
}

void runerr(const char * error_text)
{
	#ifndef XS_MPI
		printf("*** [xshells] Run-time error : %s\n",error_text);
	#else
		printf("*** [xshells mpi rank %d] Run-time error : %s\n", i_mpi, error_text);
		MPI_Abort(MPI_COMM_WORLD,1);
	#endif
	exit(1);
}


template <typename T, unsigned N>
void LinOpN<T,N>::alloc(int ir0, int ir1) {
	_free();		// allow silently reallocating.
	ir_bci = ir0;	// store global boundaries
	ir_bco = ir1;
	int nr = ir_bco - ir_bci + 1;		// allocation of full matrices on each MPI process
	data = (double *) malloc( N * nr * sizeof(double) );
	if (data==0) runerr("[LinOpN] allocation error");
	data -= ir_bci*N;		// shift pointer for faster access.
}

template <typename T, unsigned N>
void LinOpN<T,N>::_free() {
	double* d = data + ir_bci*N;
	if (d) free(d);
}


/*	Grid Generation with radial derivation operators.  */

#ifdef VAR_LTR
  #undef LTR

/// initializes variable l truncation. rsat=0 => no truncation.
void init_ltr(double rsat)
{
	if (ltr == NULL) {
		ltr = (unsigned short *) malloc( sizeof(unsigned short) * (NR+3) );		// allow some overflow.
		ltr += 1;	// ltr[-1] should be defined.
	}
	if (rsat<=0.0) {
		for (int ir=-1; ir<(NR+2); ir++) ltr[ir]=LMAX;
		return;
	}
	if (rsat > 1.) rsat=1.;
	rsat *= r[NR-1];
	printf("   variable l-truncation : ltr = lmax*sqrt(r/%.2f)  ",rsat);
	for (int ir=0; ir<NR; ir++) {
		int l = 1. + sqrt(r[ir]/rsat)*LMAX;
		if (l>LMAX) l=LMAX;
		ltr[ir] = l;
		#ifdef XS_DEBUG
			printf("%hu ",ltr[ir]);
		#endif
	}
	for (int ir=NR; ir<(NR+2); ir++)	ltr[ir] = ltr[NR-1];	// copy last value (ghost point and overflow)
	ltr[-1] = ltr[0];	// copy first value to -1 (ghost point).
	printf("\n");
}
#endif

/// grid with dr prop. to r^(1/3) : constant error as r->0.
void r0_Grid(double rmax, int n_end)
{
	double dr0, dr;

	dr0 = pow(rmax/n_end, 1.5);		// estimate
	r[0] = 0.0;
	dr = dr0;
	for (int i=1; i<=n_end; i++) {
		r[i] = r[i-1] + dr;
		dr = dr0*pow(r[i]/dr0, 1./3.);
	}

	dr = rmax/r[n_end];
	for (int i=1; i<n_end; i++) {		// rescale
		r[i] = r[i]*dr;
	}
	r[n_end] = rmax;
}

void Reg_Grid(double rmin, double rg, double rm, double rmax)		// Regular Grid
{
	double dx;
	long int i;

	if (rmin > rg) runerr("rmin > rg !");
	if (rg >= rm) runerr("rg >= rm !");
	if (rm > rmax) runerr("rm > rmax !");

	NG = ceil( NR*(rg-rmin)/(rmax-rmin) );			// number of radial points in inner core.
	NM = NR-1 - ceil( NR*(rmax-rm)/(rmax-rmin) );	// number of radial points in conducting cmb.

	// inner core
	dx = (rg - rmin)/NG;
	for (i=0; i<NG; i++)
		r[i] = dx*i +rmin;
	r[NG] = rg;

	// outer core
	dx = (rm - rg)/(NM-NG);
	for (i=NG+1; i<NM; i++)
		r[i] = dx*(i-NG) +rg;
	r[NM] = rm;
		
	// mantle
	dx = (rmax - rm)/(NR-1-NM);
	for (i=NM+1; i<NR-1; i++)
		r[i] = dx*(i-NM) +rm;
	r[NR-1] = rmax;
}

/// The sum of the N first powers of the unknown x is y.
/// we assume x<1
double decre(int N,double y)
{	double e,f,x;

	e=y/(y+1.);	f=N+1.;
	x=e;
	while(fabs(y+1-(1-pow(x,f))/(1-x))>0.0001)
		x=e+pow(x,f)/(y+1);
	return x;
}


/// Generate a grid with densification in Boundary Layers, based on code from D. Jault.
/// \param[in] rmin, rg, rmax are respectively the minimal, inner core and outer core radius.
/// \param[out] r[NR] is set with grid points (has to be allocated before function call)
/// \parmin[in] nin, nout are a number of points to be added to the inner and outer boundary layers.
///      NG is set with inner core index.
/// corresponds roughly to BL_Grid if nin >= nh*0.8 and nout <= nh*0.2
void BL_Grid(double rmin, double rg, double rm, double rmax, int nin, int nout)
{
	int nr1,nr2, nb,i,j;
	double e,q,hu,h;

	if (rmin > rg) runerr("rmin > rg !");
	if (rg >= rm) runerr("rg >= rm !");
	if (rm > rmax) runerr("rm > rmax !");
	if (nin+nout >= NR-1) runerr("nin+nout >= NR-1 !");

	#define non_fluid_points( n, size ) n*sqrt(size)

	nb = NR-1-(nin+nout);				// bulk pool
	e = log(nb);	h = 13.5*nb/(1.+e*e);		// points available for non-fluid layers.
	if (rg != rmin) {
		j = non_fluid_points( h, (rg-rmin)/(rmax-rmin) );
		NG = j + nin/4;		// inner core grid points
		nb -= j;		// substract from bulk pool
		nin -= nin/4;	// substract from bl pool
	} else NG = 0;
	if (rm != rmax) {
		j = non_fluid_points( h, (rmax-rm)/(rmax-rmin) );
		i =  j + nout/4;	// conducting mantle grid points
		NM = NR-1 -i;		// index of CMB
		nb -= j;			// substract from bulk pool
		nout -= nout/4;		// substract from bl pool
	} else NM = NR-1;
	nr1 = NG + (nb/4 + nin);		// 0.25 of bulk in inner BL
	nr2 = NM - (nb/4 + nout);		// 0.25 of bulk in outer BL
	if (rg == 0) nr1 = NG + (3*nb/20 + nin);		// don't concentrate without inner core.

	#undef non_fluid_points

//	printf("nr1=%d, nr2=%d\n",nr1,nr2);

	if ((nr1 >= nr2)||(nr1 <= NG)||(nr2 >= NM)) {
		PRINTF0("[Grid] Cannot compute boundary layer grid, switching to regular grid.\n");
		Reg_Grid(rmin, rg, rm, rmax);
		return;
	}

	// each BL has thickness h = 0.15 of the gap
	// nr1 index of external shell of internal BL
	// nr2 index of internal shell of external BL
	h = (rm-rg)*0.15;
	hu=(rm-rg -2.*h)/(nr2-nr1);
	r[NG]=rg;		r[NM]=rm;
	r[nr1]=rg+h;	r[nr2]=rm-h;
	r[0]=rmin;		r[NR-1]=rmax;

	// Uniform grid in the bulk
	for(i=nr1+1; i<nr2; i++)
		r[i] = r[nr1] + (i-nr1)*hu;
//	printf("dr in the bulk = %.5e\n",hu);

	// Outer boundary layer
	q=decre(NM-nr2,h/hu);
	e=hu;
	for(i=nr2+1; i<NM; i++) {
		e*=q;
		r[i]=r[i-1]+e;
	}
//	printf("q outer bl = %f\n",1/q);

	// Inner boundary layer
	q=decre(nr1-NG,h/hu);
	e=hu;
	for(i=nr1-1; i>NG; i--) {
		e*=q;
		r[i]=r[i+1]-e;
	}
//	printf("q inner bl = %f\n",1/q);

	// Inner core
	if (NG > 0) {
		r[NG-1] = 2.*rg - r[NG+1];
		q = 1.09;	i=0;
		while (((e>(0.01/q))||(i==0))&&(q<1.3)) {		// try to limit step size at ir=0
			e = rg - r[NG-1];
			q += 0.01;
			for(i=NG-2; (i>0)&&(e<=(r[i+1]-rmin)/(i+1)); i--) {
				e*=q;
				r[i]=r[i+1]-e;
			}
		}
//		printf("q ic = %f\n",q);
		if (i==0) runerr("  !! Grid_BL : not enough points for good resolution in inner core\n");
		hu=(r[i+2]-rmin)/(i+2);
		for(j=0; j<=i+1; j++)
			r[j]=rmin + j*hu;
	}

	// Mantle
	if ( NM < (NR-1) ) {
		r[NM+1] = 2.*rm - r[NM-1];
		q = 1.02;	i=NR-1;
		while ((i==NR-1)&&(q<1.5)) {
			e = r[NM+1] - rm;
			q += 0.01;
			for (i=NM+2; (i<NR-1)&&(e <=(rmax-r[i-1])/(NR-i)); i++) {
				e*=q;
				r[i] = r[i-1] + e;
			}
		}
//		printf("q mantle = %f\n",q);
		if (i==NR-1) runerr("  !! Grid_BL : not enough points for good resolution in conducting mantle\n");
		hu=(rmax - r[i-2])/(NR-i+1);
		for(j=i-1; j<NR; j++)
			r[j]=rmax - (NR-1-j)*hu;
	}
}

/*
void Exp_Grid(double dx0, double alpha)		// Grille exponentielle.
{
	double dx;
	int i;

	r[0] = 0.0;
	dx = dx0;
	for (i=1;i<NR;i++)
	{
		dx = dx*alpha;
		r[i] = r[i-1] + dx;
	}

	printf("[GRID:Exp] NR=%d alpha=%f rmax=%f, dxmin=%f dxmax=%f\n",NR,alpha,r[NR-1],dx0,dx);
}

void Mixed_Grid(int Nreg, double rreg_max, double dxmax_mul)	// Génère une grille réguliere au centre, puis exponentielle.
{
	double dx, dxmax, alpha;
	int i, Nirr;

	if (Nreg > NR)	Nreg = NR;
// Grille : réguilière dans le coeur ...
	r[0] = 0.0;
	dx = rreg_max/(Nreg-1);
	for(i=1;i<Nreg;i++)
	{
		r[i] = r[0] + dx*i;
	}

// ... puis decroit exponentiellement, d'un facteur alpha.
	Nirr = (NR-1)-(Nreg+1);
	dxmax = dxmax_mul * log(Nirr);
	alpha = exp(log(dxmax/dx)/(double)Nirr);
	for (i=Nreg;i<NR;i++)
	{
		dx = dx*alpha;
		r[i] = r[i-1] + dx;
	}

	dxmax = dx;
	dx = r[1]-r[0];
	printf("[GRID:Mixed] NR=%d alpha=%f rmax=%f, dxmin=%f dxmax=%f\n",NR,alpha,r[NR-1],dx,dxmax);
}
*/

/// Generate Gradients, Laplaciens .... in spherical geometry.
void init_Deriv_sph()
{
	double t;
	int i;

	// quick checks :
	if (r[0] < 0) runerr("Wrong grid: negative radius forbidden.");
	for (i=1; i<NR; i++) {
		if (r[i] <= r[i-1]) runerr("Wrong grid: radii are not strictly increasing.");
	}

	if (r_1 != NULL) {		// free previously allocated global data (NR may have changed !)
		#ifdef XS_DEBUG
			printf("  *** WARNING: init_Deriv_sph() was already called before.\n");
		#endif
		free(r_1);
	}
	// allocate global variables:
	r_1 = (double *) malloc(2*NR * sizeof(double));
	r_2 = r_1 + NR;

	Gr.alloc(0, NR-1);
	Wr.alloc(0, NR-1);
	Lr.alloc(0, NR-1);
	
	i=0;
	if (r[i] == 0.0) {
		r_1[i] = 0.0;	r_2[i] = 0.0;
		i++;
	}
	do {
		r_1[i] = 1./r[i];
		r_2[i] = 1./(r[i]*r[i]);
	} while(++i < NR);

	// gradient et Laplacien (second order)
	for (i=1;i<NR-1;i++)
	{
		TriDiag D2r;
		fd_deriv_o2(r,i, Gr.Mr(i), &(D2r.l));

/*		Wr[i].l = r_1[i]* Gr[i].l * r[i-1];	// Wr = 1/r * d/dr(r .)
		Wr[i].d =         Gr[i].d;			// =0 on a regular grid.
		Wr[i].u = r_1[i]* Gr[i].u * r[i+1];		// good for r^a, with a < 0 [=> bien pour B à l'exterieur de la sphere]
*/
		Wr[i].l = Gr[i].l;				// Wr = 1/r * d/dr(r .) = (d/dr + 1/r)
		Wr[i].d = Gr[i].d + r_1[i];		// diagonal is non-zero on a regular grid.
		Wr[i].u = Gr[i].u;				// good for r^a, with a > 0  [=> 	better close to r=0]

/*
		Lr[i].l = r_1[i]* D2r.l * r[i-1];	// Laplacien radial : 1/r . d2/dr2(r .).
		Lr[i].d =         D2r.d;				// this definition ensures Lr[1].l=0 for r[0]=0.
		Lr[i].u = r_1[i]* D2r.u * r[i+1];
*/
		Lr[i].l = D2r.l + 2.0*r_1[i]*Gr[i].l;	// Laplacien radial : d2/dr2 + 2/r.d/r
		Lr[i].d = D2r.d + 2.0*r_1[i]*Gr[i].d;	// both definitions are equal for regular grid.
		Lr[i].u = D2r.u + 2.0*r_1[i]*Gr[i].u;	// this one seems a little better close to r=0.

/*		t = (r[i-1]*r[i-1])/(r[i]*r[i]);		// With this definition, Lr*(1/r^2) = 2/r^4 (exact) on a regular grid.
		Lr[i].l = t*(D2r.l - 2.0*r_1[i]*Gr[i].l);	// VERY BAD near r=0.
		Lr[i].d = D2r.d - 2.0*r_1[i]*Gr[i].d + 2.0/(r[i]*r[i]);
		t = (r[i+1]*r[i+1])/(r[i]*r[i]);
		Lr[i].u = t*(D2r.u - 2.0*r_1[i]*Gr[i].u);
*/
	}

	// start and end must be determined by BC on a case by case basis.
	i = 0;
		Gr[i].l = 0.0;	Gr[i].d = 0.0;	Gr[i].u = 0.0;
		Wr[i].l = 0.0;	Wr[i].d = 0.0;	Wr[i].u = 0.0;
		Lr[i].l = 0.0;	Lr[i].d = 0.0;	Lr[i].u = 0.0;
	i = NR-1;
		Gr[i].l = 0.0;	Gr[i].d = 0.0;	Gr[i].u = 0.0;
		Wr[i].l = 0.0;	Wr[i].d = 0.0;	Wr[i].u = 0.0;
		Lr[i].l = 0.0;	Lr[i].d = 0.0;	Lr[i].u = 0.0;
}

/*
// Gradients, Laplaciens .... en cylindrique.
void init_Deriv_cyl()
{
	double t, rm, rp, grm, grp;
	int i;

	// creation des variables globales :
	r_1 = (double *) malloc(NR * sizeof(double));
	r_2 = (double *) malloc(NR * sizeof(double));
	dr = (double *) malloc(NR * sizeof(double));
	
	Gr = (struct TriDiag *) malloc(NR * sizeof(struct TriDiag));
	Wr = (struct TriDiag *) malloc(NR * sizeof(struct TriDiag));
	Lr = (struct TriDiag *) malloc(NR * sizeof(struct TriDiag));
	
	for(i=1;i<NR;i++)
	{
		r_1[i] = 1./r[i];
		r_2[i] = 1./(r[i]*r[i]);
	}
	i = 0;
		r_1[i] = 0.0;	r_2[i] = 0.0;

	// increments
	for(i=0;i<NR-1;i++)
		dr[i] = r[i+1]-r[i];
	dr[NR-1] = 0.0;

	// gradient et Laplacien
	for (i=1;i<NR-1;i++)
	{
		t = 1.0/((dr[i-1]+dr[i])*dr[i]*dr[i-1]);
		Gr[i].l = -dr[i]*dr[i]*t;
		Gr[i].d = (dr[i]*dr[i] - dr[i-1]*dr[i-1])*t;	// =0 en grille reguliere.
		Gr[i].u = dr[i-1]*dr[i-1]*t;

		Wr[i].l = r_1[i]* Gr[i].l * r[i-1];	// Wr = 1/r * d/dr(r .), pour la vorticite m=0 !
		Wr[i].d = Gr[i].d;
		Wr[i].u = r_1[i]* Gr[i].u * r[i+1];

		Lr[i].l =  2.0*dr[i]*t            + r_1[i]*Gr[i].l;
		Lr[i].d =  -2.0*(dr[i-1]+dr[i])*t + r_1[i]*Gr[i].d;
		Lr[i].u =  2.0*dr[i-1]*t          + r_1[i]*Gr[i].u;
	}
	// les extremites douvent etre déterminées par les CL au cas par cas.
	i = 0;
		Gr[i].l = 0.0; Gr[i].d = 0.0; Gr[i].u = 0.0;
		Wr[i].l = 0.0;	Wr[i].d = 0.0;	Wr[i].u = 0.0;
		Lr[i].l = 0.0;	Lr[i].d = 0.0;	Lr[i].u = 0.0;
	i = NR-1;
		Gr[i].l = 0.0; Gr[i].d = 0.0; Gr[i].u = 0.0;
		Wr[i].l = 0.0;	Wr[i].d = 0.0;	Wr[i].u = 0.0;
		Lr[i].l = 0.0;	Lr[i].d = 0.0;	Lr[i].u = 0.0;

}
*/

/// finds the index to the shell with closest radius to radius rr
long int r_to_idx(double rr)
{
	long int i;

	i = NR-2;
	while((r[i] > rr)&&(i>0)) i--;
	if ((rr-r[i]) > (r[i+1]-rr)) i++;
	return i;	// i is always between 0 and NR-1
}

/// finds the index of latitudinal grid point with closest colatitude to theta.
long int theta_to_idx(double theta)
{
	int i;
	double ct0 = cos(theta);
	i = NLAT-2;
	while((ct[i] < ct0)&&(i>0)) i--;
	if ((theta-acos(ct[i])) > (acos(ct[i+1])-theta)) i++;
	return i;
}

/// load radial grid points from text file (one grid point per line)
int load_grid(char *fname)
{
	double f;
	long int i;
	FILE *fp;

	if (r != NULL) {
		#ifdef XS_DEBUG
			printf("  *** WARNING! load_grid is overwriting the grid.\n");
		#endif
		free(r);
	}

	if (i_mpi==0) {
		fp = fopen(fname,"r");
		if (fp == NULL) runerr("[load_grid] file not found !");

	// count lines :
		i = 0;
		while ( fscanf(fp, "%lf\n", &f) ) {
			i++;
			if (feof(fp)) break;
		}
		if (i==0) {		// not a valid grid definition.
			fclose(fp);
			return(0);	// abort
		}
		NR = i;
	}
	#ifdef XS_MPI
		MPI_Bcast(&NR, sizeof(NR), MPI_BYTE, 0, MPI_COMM_WORLD);
	#endif

// load values :
	r = (double *) malloc(NR * sizeof(double));		// allocation of radial grid
	if (i_mpi == 0) {
		rewind(fp);		// go back to beginning of file
		for (i=0; i<NR; i++) {
			fscanf(fp, "%lf\n", &r[i]);
		}
		fclose(fp);
		printf("[load_grid] %d radial grid points read from file '%s'\n",NR,fname);
	}
	#ifdef XS_MPI
		MPI_Bcast(r, NR, MPI_DOUBLE, 0, MPI_COMM_WORLD);
	#endif
	return(NR);
}

/// Build the radial grid, and matrices of spatial derivatives.
void init_rad_sph(double rmin, double Ric, double Rcmb, double rmax, int Nin, int Nout)
{
	if (r == NULL) {	// if r not yet allocated, build a new radial grid.
		r = (double *) malloc(NR * sizeof(double));		// allocation of radial grid
#ifdef XS_PENALIZE
		Reg_Grid(rmin, Ric, Rcmb, rmax);
#else
		BL_Grid(rmin, Ric, Rcmb, rmax, Nin, Nout);
#endif
	} else {
		NG = r_to_idx(Ric);
		NM = r_to_idx(Rcmb);
	}
#if XS_MPI
	if (r_owner == NULL) {
		r_owner = (int *) malloc((NR+2) * sizeof(unsigned));
		*r_owner++ = 0;				// skip inner ghost shell, owned by 0.
		r_owner[NR] = n_mpi-1;		// outer ghost shell, owned by last process.
		for (int i=0; i<NR; i++)
			r_owner[i] = i*n_mpi/NR;	// set shell owner.
		irs_mpi = 0;		ire_mpi = NR-1;
		while (r_owner[irs_mpi] < i_mpi) irs_mpi++;		// set local limits
		while (r_owner[ire_mpi] > i_mpi) ire_mpi--;
		if (ire_mpi - irs_mpi < 0) runerr("[Grid] at least 1 shell per process required.");
		#ifdef XS_DEBUG
			MPI_Barrier(MPI_COMM_WORLD);
			printf("mpi process %d handles %d shells (%d to %d)\n", i_mpi, ire_mpi-irs_mpi+1, irs_mpi, ire_mpi);
			MPI_Barrier(MPI_COMM_WORLD);
		#endif
	}
#endif

	init_Deriv_sph();	// build derivative matrices
}

inline double phi_deg(int ip) {
	return (360./(NPHI*MRES))*ip;
}

inline double phi_rad(int ip) {
	return (M_PI/(NPHI*MRES))*(2*ip);
}

/// initializes SH without grid (default norm is orthonormal.
void init_sh_vars(int norm=sht_orthonormal)
{
	if (i_mpi == 0) shtns_verbose(1);		// only root process speaks.
	sht_norm = (shtns_norm) norm;		// set and save norm
	NLM = nlm_calc(LMAX, MMAX, MRES);
	shtns = shtns_create(LMAX, MMAX, MRES, sht_norm);
	li = shtns->li;

	l2 = (double*) malloc(sizeof(double) * 3*NLM);
	if (l2==0) runerr("[init_sh_vars] allocation error");
	l_2 = l2 + NLM;		el = l2 + 2*NLM;
	for (int lm=0; lm<NLM; lm++) {
		unsigned l = li[lm];
		el[lm] = l;
		l2[lm] = l*(l+1);
		l_2[lm] = (l==0) ? 0.0 : 1.0/l2[lm];		// avoid division by 0 !
	}
}

/// initializes SH
void init_sh(int sht_type, double polar_opt_max, int nl_order)
{
	shtns_use_threads( (XS_OMP==2) ? 0 : 1 );		// use multi-threaded SHTns ?
	if (shtns == NULL) init_sh_vars();

	sht_type |= SHT_LOAD_SAVE_CFG;		// load and save SHTns + fftw config
	#ifdef XS_MPI
	if (i_mpi > 0) MPI_Barrier(MPI_COMM_WORLD);    // all processes except 0 wait here until process 0 has initialized shtns.
	#endif
	shtns_set_grid_auto(shtns, (shtns_type) sht_type, polar_opt_max, nl_order, &NLAT, &NPHI);    // this will save the config to a file on process 0 and load from file on other processes.
	#ifdef XS_MPI
	if (i_mpi == 0) MPI_Barrier(MPI_COMM_WORLD);   // other processes now resume and load the config from file.
	#endif

	if (NLAT % VSIZE) runerr("Nlat must be a multiple of vector size.");
	if (i_mpi==0) shtns_print_cfg(shtns);
	ct = shtns->ct;		st = shtns->st;
	double* wg2 = (double*) malloc(NLAT*sizeof(double));
	shtns_gauss_wts(shtns, wg2);		// get gauss weights.
	for (int it=0; it<NLAT/2; it++)  wg2[NLAT-1-it] = wg2[it];		// gauss weights are symmetric.
	wg = wg2;		// set the read-only global pointer to gauss weigths.
}
