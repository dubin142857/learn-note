/*
 * Copyright (c) 2010-2016 Centre National de la Recherche Scientifique.
 * written by Nathanael Schaeffer (CNRS, ISTerre, Grenoble, France).
 * 
 * nathanael.schaeffer@univ-grenoble-alpes.fr
 * 
 * This software is governed by the CeCILL license under French law and
 * abiding by the rules of distribution of free software. You can use,
 * modify and/or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info".
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */

///\file xshells_spectral.cpp
/// 3D Fields definition and operations, in spectral space.

inline void mpi_interval(int& ir0, int& ir1) {
  #ifdef XS_MPI
	if (ir0 < irs_mpi) ir0 = irs_mpi;
	if (ir1 > ire_mpi) ir1 = ire_mpi;
  #endif
}

/// transform the global interval ir0 and ir1 (inclusive) into an interval assigned to a thread.
inline void thread_interval_any(int& i0, int& i1)
{
  #if XS_OMP > 0
	int nth = omp_get_num_threads();
	int ith = omp_get_thread_num();
	int n = i1 - i0 + 1;
	i1 = i0-1 + ((ith+1)*n)/nth;
	i0 += (ith*n)/nth;
  #endif
}

/// transform the global interval ir0 and ir1 (inclusive) into an interval assigned to a thread.
inline void thread_interval_rad(int& ir0, int& ir1)
{
  #if XS_OMP == 1
	thread_interval_any(ir0, ir1);
  #endif
}

/// transform the global interval lm0 and lm1 (inclusive) into an interval assigned to a thread.
/// and keep vsize multiples !
inline void thread_interval_lm(int& lm0, int& lm1)
{
  #if XS_OMP == 2
	thread_interval_any(lm0, lm1);
  #endif
}

/// Bondary condition definition.
enum boundary {
	BC_ZERO=0,				///< the field is zero at the boundary (ie no-slip with zero velocity).
	BC_NO_SLIP=1,			///< no-slip (prescribed velocity).
	BC_FREE_SLIP=2,			///< free-slip (stress-free boundary condition).
	BC_MAGNETIC=3,			///< magnetic field boundary condition for an electrical insulator.
	BC_CURL_FREE_SLIP=4,	///< for the curl of a free-slip field.
	BC_ELLIPTIC=5,			///< elliptic boundary, with radial velocity prescribed by the tangential one.
	BC_FIXED_TEMPERATURE=1,	///< fixed temperature.
	BC_IMPOSED_FLUX=2,		///< imposed flux = radial gradient is zero.
	BC_NONE=127,			///< no boundary condition (use first order approx, or central condition for r=0)
};

/// solid parts : described by their rotation vector.
struct SolidBody {
	int irs, ire;			///< radial boundaries (local).
	int ir_bci, ir_bco;		///< global boundaries.
	double Omega_x, Omega_y, Omega_z;		///< rotation speeds.
	double phi0;			///< keep track of azimutal position.
	double Tb_z;			///< magnetic torque along z-axis.
	double Tu_z;			///< viscous torque along z-axis.
	double Tzo;				///< previous torque (used for 2nd order integration).
	#ifdef XS_ELLIPTIC
		double eps_z;	// axisymmetric ellipticity.
	#endif
	double vol;			///< volume
	double IM;		// inertia moment (divided by rho)
	// associated potential magnetic field :
	int lmax, mmax;			/// truncation for applied potential field
	cplx *PB0lm;	/// spherical harmonic decomposition of externally aplied potential field.
	double *vt_r;		/// spatial velocity field v_theta/r
	double *vp_r;		/// spatial velocity field v_phi/r

	SolidBody();
	~SolidBody();
	void zero_out();
	void free_spatial();
	void invalidate_spatial();
	void calc_spatial();			/// alloc and compute spatial field.
	int spatial_ok() const;

	void set_limits(int i0, int i1);
	void set_external_B(cplx *Pol);
	void set_rotation(double rr, cplx *Tor);
};

/// a static spectral vector, ready for SHT. Usefull to add "for free" a background variable vector value.
struct StatSpecVect {
	unsigned nlm;	///< number of non-zero elements
	unsigned nm0;	///< number of elements with m=0
	unsigned *lm;		///< array of corresponding indices
	cplx *QST;	///< data ready for SHT. QST[ir*nlm*3 + 3*j] is Pol/(r*l(l+1)) ,QST[ir*nlm*3 + 3*j+1] is spheroidal, QST[ir*nlm*3 + 3*j+2] is toroidal.
	int lmax;		///< maximum degree
	int mmax;		///< maximum order
	unsigned short *li;
	unsigned short *mi;
};

/// a static spectral vector, ready for SHT. Usefull to add "for free" a background variable vector value.
struct StatSpecScal {
	unsigned nlm;	///< number of non-zero elements
	unsigned nm0;	///< number of elements with m=0
	unsigned *lm;		///< array of corresponding indices
	cplx *TdT;	///< data ready for SHT. TdT[ir*nlm*2 + 2*j] is Scal[ir][lm[j]], TdT[ir*nlm*2 + 2*j+1] is d(Scal)/dr
	int lmax;		///< maximum degree
	int mmax;		///< maximum order
	unsigned short *li;
	unsigned short *mi;
};

/// allows access in the Esplit array of SpectralDiags.
enum { E_cs, E_ca, Ez_es, Ez_ea, Enz_es, Enz_ea, N_Esplit };

/// a structure recording Spectral diagnostics, used in several methods of the Spectral class.
struct SpectralDiags {
	double Sconv[2];
	double* Esplit;
	double* El;
	double* Em;
	double* Etot;
	int ndbl;

	void clear() {
		for (int k=0; k<ndbl; k++) Esplit[k] = 0.0;
		Sconv[0] = 0.0;		Sconv[1] = 0.0;		
	}
	SpectralDiags(int lmax, int mmax) {
		ndbl = lmax+1 + mmax+1 + 2*N_Esplit +1;
		Esplit = (double*) malloc( sizeof(double) * ndbl );
		Etot = Esplit + 2*N_Esplit;
		El = Esplit + 2*N_Esplit +1;
		Em = El + lmax+1;
		clear();
	}
	~SpectralDiags() {
		if (Esplit) ::free(Esplit);
	}
	double energy() {
		return *Etot;
	}
	double energy_nz() {
		return Esplit[Enz_es]+Esplit[Enz_ea]+Esplit[N_Esplit+Enz_es]+Esplit[N_Esplit+Enz_ea];
	}
	void reduce(const SpectralDiags& sd, const double f = 1.0) {
		for (int k=0; k<ndbl; k++) Esplit[k] += f * sd.Esplit[k];
		for (int k=0; k<2; k++)
			if (Sconv[k] < sd.Sconv[k]) Sconv[k] = sd.Sconv[k];
	}
  #ifdef XS_MPI
	void reduce_mpi() {
		MPI_Allreduce( MPI_IN_PLACE, Esplit, ndbl, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD );
		MPI_Allreduce( MPI_IN_PLACE, Sconv, 2, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD );
	}
  #endif
	void get_lmax_mmax(int& lmax, int& mmax, const double eps = 1e-25) {
		double* Elm[2] = {El, Em};
		int imax[2] = {lmax, mmax};

		for (int k=0; k<2; k++) {		// loop over l and m spectra
			double emax = 0;
			double* Ej = Elm[k];
			int	jmax = imax[k];
			for (int j=0; j<=jmax; j++) {		// find max of spectrum
				if (Ej[j] > emax) emax = Ej[j];
			}
			emax *= eps;
			for (int j=0; j<=jmax; j++) {		// find last index of significant energy.
				if (Ej[j] > emax) imax[k] = j;
			}
		}
		lmax = imax[0];		mmax = imax[1];
	}
};

/// Common spectral field info.
class Spectral {
  public:
	int irs, ire;			///< radial boundaries (local).
	boundary bci, bco;		///< inner and outer boundary conditions.
	int ir_bci, ir_bco;			///< absolute (global) boundaries.
	short share_dn, share_up;	///< share boundary with other processes

  protected:
	unsigned short h0, h1;		/// ghost or halo for lower and upper layers.
	cplx **data;		/// pointer to allocated memory (so that we can free it later).
	unsigned ncomp, nshell, nelem;
	unsigned short halo;		/// required halo.
	short allocated;
	cplx* map_ptr;

	void alloc_rad_ptr(int nc, int istart, int iend, int h=1);
	int map_file(class SpectralFile& F);

  public:
	Spectral();
	Spectral(int ncomp, int nelem, int istart, int iend, int h=1);
	~Spectral();
	void alloc(int ncomp, int nelem, int istart, int iend, int h=1);
	void free_field();
	int get_ncomp() {
		return ncomp;
	}
	int is_unallocated() const {
		return (allocated == 0);
	}

	Spectral & operator*=(const double val);		///< multiply by a real value.
	Spectral & operator+=(const Spectral &rhs);		///< add other field
	Spectral & operator-=(const Spectral &rhs);		///< subtract other field

	cplx* get_data(int ic, int ir) const {
		return data[ic*nshell + ir-irs+h0];		// shift by halo for ghost shell.
	}

	void zero_out_shell(int ir);
	void zero_out();
	void zero_out_comp(int c);
	void copy(const Spectral& src);
	void add_random(double norm, int mmin=0, int mmax=(1<<27), int sym=0);
	void scale(const double s);		///< rescale field by value.

	void filter_scale(double scale);
	void filter_lm(int lmin, int lmax, int mmin, int mmax);
	void filter_parity(int sym);
	void Zrotate(double phi);		///< rotate field by angle phi around the z-axis.

	int load(char *fn, struct FieldInfo *fh=NULL);	///< read PolTor field from file "fn".
	void save(char *fn, double time=0.0, int iter=0, int istep=0) const;		///< writes full field data to disk.
	void save_double(char *fn, int lmax, int mmax, double time=0.0, int iter=0, int istep=0) const;	///< write data in double precision.
	void save_single(char *fn, int lmax, int mmax, double time=0.0, int iter=0, int istep=0) const;	///< write data in single precision.
	void save_generic(char *fn, int lmax, int mmax, double time, int iter, int step, const int prec) const;

	double radius(int ir)  const;	///< returns the shell radius (take into account boundaries).
	double delta_r(int ir) const;	///< returns the shell width (take into account boundaries).

	void energy(SpectralDiags& sd, int irstart=-10, int irend=(1<<27)) const;		///< computes energy related diagnostics.
	double rms(int irstart=-10, int irend=(1<<27)) const;			///< computes rms value (accross processes).
	double spectrum(double *El=0, double *Em=0) const;				///< computes spectrum averaged over whole domain.
	void acc_spectrum(int ir, SpectralDiags& sd) const;
	void r_spectrum(int ir, SpectralDiags& sd) const;
	void energy_split(double* Esplit, int irstart=-10, int irend=(1<<27)) const;
	double absmax(int irstart=-10, int irend=(1<<27)) const;		///< compute the maximum of the absolute value of field.

	virtual double r_absmax2(int ir) const {							///< compute the squared maximum of the absolute value of field at given shell
		return -1.0;	// implemented by derived class.
	}
	virtual void _spectrum(int ir, int llim, int imlim, SpectralDiags& sd, const double w=1.0) const {
		return;	// implemented by derived class.
	}

#ifdef XS_MPI
	void sync_mpi();
	void sync1_mpi(int ic, int istart, int iend, int lmstart, int lmend, int tag, MPI_Request **req);
#endif
};


/// Poloidal/Toroidal spherical harmonic decomposition of a field on many radial shells.
class PolTor : public Spectral {
  public:
	cplx **__restrict Pol;
	cplx **__restrict Tor;
	#if defined(XS_LEGACY) || defined(XS_LINEAR)
	int zero_curl;				///< mark field as beeing curl free.
	#endif

	cplx Prlm(int ir, int l, int im) const;		///< poloidal sh of degree l and order m.
	cplx Trlm(int ir, int l, int im) const;		///< toroidal sh of degree l and order m.
	void set_Prlm(int ir, int l, int m, cplx val);
	void set_Trlm(int ir, int l, int m, cplx val);

	PolTor();
	PolTor(int istart, int iend, int h=2);
	void alloc(int istart, int iend, int h=2);
	void clone(const PolTor& PT);

	void curl(int istart=-10, int iend=(1<<27));		///< take curl of field (in place).
	void curl_from_TQS(Spectral* S, int istart, int iend, int sync_tag);			///< take curl of a general field (not PolTor). if sync_tag>=0, do MPI sync with tag sync_tag.

	void RadSph(int ir, cplx *Qlm, cplx *Slm, int lms=0, int lme=NLM-1) const;
	void qst(int ir, int lm, cplx *Q, cplx *S, cplx *T) const;
	void curl_QST(int ir, cplx *Qlm, cplx *Slm, cplx *Tlm, int lms=0, int lme=NLM-1) const;
	void curl_qst(int ir, int lm, cplx *Q, cplx *S, cplx *T) const;

	void _spectrum(int ir, int llim, int imlim, SpectralDiags& sd, const double w=1.0) const;
	double r_absmax2(int ir) const;									///< compute the squared maximum of the absolute value of field at given shell
	double r_energy_split(int ir, double* Esplit=0) const;			///< computes energies at given shell, returns total energy and other diagnostics
	double energy_lm(int l, int m, int irstart=-10, int irend=(1<<27)) const;		///< computes energy of single mode (l,m)

	#ifdef XS_LEGACY
	int make_static(struct StatSpecVect **pssv, struct StatSpecVect **pcurl) const;
	#endif

	/* spatial methods */
	void curl_from_spat(class VectField *V);
	void to_spat(class VectField *V) const;
	void to_spat(class VectField *V, int istart, int iend) const;		///< convert to spatial field
	void cte_to_spat(struct StatSpecVect *V0, class VectField *V) const;
	void cte_to_spat(struct StatSpecVect *V0, class VectField *V, int istart, int iend) const;
	void to_curl_spat(class VectField *W, int istart, int iend, double Wz0=0.0) const;
	void cte_to_curl_spat(struct StatSpecVect *W0, class VectField *W, int istart, int iend, double Wz0=0.0) const;

	void special_z_avg(int ns, const double *s, double *buf, const int rstep=1) const;

	/* rendering methods */
	void to_point(int ir, double cost, double phi,
					double *vr, double *vt, double *vp) const;
	void to_point_interp(double rr, double cost, double phi,
					double *vr, double *vt, double *vp) const;
	void uncurl_to_point_interp(double rr, double cost, double phi,
					double *vr, double *vt, double *vp) const;
	void to_lat(int ir, double cost,
					 double *vr, double *vt, double *vp, int np) const;
	void to_merid(double phi, double *vr, double *vt, double *vp, int irs, int ire) const;		///< render a meridional slice, at longitude phi.
	int to_zdisc(double z0, int nphi, double* s, double* vs, double *vp, double *vz, int ir0, int ir1) const;
	void to_surf(int ir, double *vr, double *vt, double *vp) const;
	void prolongate_field(double rmin, double rmax);		// prolongate field

	/* io methods */
	void load(char *fn, FieldInfo *fh=0);
	void write_box_hdf5(const char *fn, double x0, double y0, double z0, double lx, double ly, double lz, int nx, int ny, int nz, int uncurl=0);
	void write_hdf5(const char *fn, int istart, int iend, int cartesian, int irstep) const;

  private:
	inline void update_ptr() {
		Pol = data - irs+h0;		Tor = Pol + nshell;
		#if defined(XS_LEGACY) || defined(XS_LINEAR)
		zero_curl = 0;		// mark as not curl-free.
		#endif
	}
};

/// scalar spherical harmonic decomposition of a field on many radial shells.
class ScalarSH : public Spectral {
  public:
	cplx **__restrict Sca;
	cplx rlm(int ir, int l, int im) const;		///< poloidal sh of degree l and order m.
	void set_rlm(int ir, int l, int m, cplx val);

	ScalarSH();
	ScalarSH(int istart, int iend, int h=1);
	void alloc(int istart, int iend, int h=1);
	void clone(const ScalarSH& S);

	cplx* operator[](int ir) const;
	void Gradr(int ir, cplx *Qlm, cplx *Slm, int lms=0, int lme=NLM-1) const;

	void shell_grad(StatSpecScal *S0lm, int ir, cplx *Q, cplx *S, const int lms, const int lme) const;		///< gradient after adding the grad(S0lm) in spectral Q and S.
	void shell_r_grad(StatSpecScal *S0lm, int ir, cplx *S, double *gt, double *gp) const;					///< lateral gradient after adding grad(S0lm), times r

	void _spectrum(int ir, int llim, int imlim, SpectralDiags& sd, const double w=1.0) const;

	double r_absmax2(int ir) const;									///< compute the squared maximum of the absolute value of field at given shell
	double energy_lm(int l, int m, int irstart=-10, int irend=(1<<27)) const;		///< computes energy of single mode (l,m)

	int make_static(struct StatSpecScal **psss) const;

	/* spatial methods */
	void from_spat(class Spatial *V);		///< from scalar spatial field (or first component).
	void from_grad_spat(VectField &V);		///< find scalar potential from spatial gradient.
	void to_spat(class ScalField *S) const;
	void to_spat(class ScalField *S, int istart, int iend) const;
	void cte_to_spat(struct StatSpecScal *S0, ScalField *S) const;
	void cte_to_spat(struct StatSpecScal *S0, ScalField *S, int istart, int iend) const;
	void to_grad_spat(class VectField *V) const;
	void to_grad_spat(class VectField *V, int istart, int iend) const;
	void cte_to_grad_spat(struct StatSpecScal *T0, class VectField *V, int istart, int iend) const;
	
	/* rendering methods */
	double to_point(int ir, double cost, double phi) const;
	double to_point_interp(double rr, double cost, double phi) const;
	void to_lat(int ir, double cost, double *s, int np) const;
	void to_grad_lat(int ir, double cost, 
					double *vr, double *vt, double *vp, int np) const;
	void to_merid(double phi, double *s, int irs, int ire) const;
	int to_zdisc(double z0, int nphi, double* s, double*data, int ir0, int ir1) const;
	void to_grad_merid(double phi, double *vr, double *vt, double *vp, int irs, int ire) const;
	void to_surf(int ir, double *s) const;	

	/* io methods */
	void load(char *fn, FieldInfo *fh=0);
	void write_box_hdf5(const char *fn, double x0, double y0, double z0, double lx, double ly, double lz, int nx, int ny, int nz);
	void write_hdf5(const char *fn, int istart, int iend, int irstep) const;

  private:
	inline void update_ptr() {
		Sca = data - irs+h0;
	}
};


#undef LM_LOOP
///\def LM_LOOP : loop avor all lm's and perform "action". only lm is defined, neither l nor m.
#ifndef VAR_LTR
  #define FOR_SCHED_SH static
  #define LM_LOOP( action ) { int lm=0;	do { action } while(++lm < NLM); }
  #define SPAT_SH( Vr, Q ) spat_to_SH(shtns, Vr, (cplx *) Q )
  #define SH_SPAT( Q, Vr ) SH_to_spat( shtns, (cplx *) Q, Vr )
  #define SPAT_SHV( Vt, Vp, S, Tor ) spat_to_SHsphtor( shtns, Vt, Vp, (cplx *) S, (cplx *) Tor )
  #define SHV_SPAT( S, Tor, Vt, Vp ) SHsphtor_to_spat( shtns, (cplx *) S, (cplx *) Tor, Vt, Vp )
  #define SHT_SPAT( Tor, Vt, Vp ) SHtor_to_spat( shtns, (cplx *) Tor, Vt, Vp )
  #define SHS_SPAT( S, Vt, Vp ) SHsph_to_spat( shtns, (cplx *) S, Vt, Vp )
  #define SHV3_SPAT( Q, S, Tor, Vr, Vt, Vp ) SHqst_to_spat( shtns, (cplx *) Q, (cplx *) S, (cplx *) Tor, Vr, Vt, Vp )
  #define SPAT_SHV3( Vr, Vt, Vp, Q, S, Tor ) spat_to_SHqst( shtns, Vr, Vt, Vp, (cplx *) Q, (cplx *) S, (cplx *) Tor )
#else
  #define FOR_SCHED_SH guided,1
  #define LM_LOOP( action ) { int lm=0;	do { if (li[lm]<=LTR) { action } } while(++lm < NLM); }
//  #define LM_LOOP( action ) { int im=0; int lm=0; do { int l=im*MRES;  if (l>LTR) break; do { { action } lm++; } while(++l<=LTR); lm+=(LMAX-LTR); } while(++im <= MMAX); }
  #define SPAT_SH( Vr, Q ) spat_to_SH_l( shtns, Vr, (cplx *) Q, LTR )
  #define SH_SPAT( Q, Vr ) SH_to_spat_l( shtns, (cplx *) Q, Vr, LTR )
  #define SPAT_SHV( Vt, Vp, S, Tor ) spat_to_SHsphtor_l( shtns, Vt, Vp, (cplx *) S, (cplx *) Tor, LTR )
  #define SHV_SPAT( S, Tor, Vt, Vp ) SHsphtor_to_spat_l( shtns, (cplx *) S, (cplx *) Tor, Vt, Vp, LTR )
  #define SHT_SPAT( Tor, Vt, Vp ) SHtor_to_spat_l( shtns, (cplx *) Tor, Vt, Vp, LTR )
  #define SHS_SPAT( S, Vt, Vp ) SHsph_to_spat_l( shtns, (cplx *) S, Vt, Vp, LTR )
  #define SHV3_SPAT( Q, S, Tor, Vr, Vt, Vp ) SHqst_to_spat_l( shtns, (cplx *) Q, (cplx *) S, (cplx *) Tor, Vr, Vt, Vp, LTR )
  #define SPAT_SHV3( Vr, Vt, Vp, Q, S, Tor ) spat_to_SHqst_l( shtns, Vr, Vt, Vp, (cplx *) Q, (cplx *) S, (cplx *) Tor, LTR )
  #define LTR ltr[ir]
#endif

#define SSE __attribute__((aligned (16)))


#ifdef XS_MPI
  #ifdef XS_DEBUG
	#define CHECK_R_RANGE( i, ret, msg ) if ((i<ir_bci-1)||(i>ir_bco+1)) { fprintf(stderr,"proc %d, shell %i :: " msg, i_mpi,i); return ret; } \
		if ((unsigned)(i-irs+h0) >= nshell) return ret;
  #else
	// ignore unexisting shells (owned by others) but allow to read/write halo.
	#define CHECK_R_RANGE( i, ret, msg ) if ((unsigned)(i-irs+h0) >= nshell) return ret;
  #endif
#else
  #ifdef XS_DEBUG
	#define CHECK_R_RANGE( i, ret, msg ) if ((unsigned)(i-irs+h0) >= nshell) { fprintf(stderr,"shell %i :: " msg, i); return ret; }
  #else
	#define CHECK_R_RANGE( i, ret, msg )
  #endif
#endif

inline int isvalid_lm( int l, int m) {
  	unsigned im = (unsigned)m / MRES;
	unsigned mmod = (unsigned)m % MRES;
	return (((unsigned)l <= LMAX) && (im <= MMAX) && (mmod == 0));
}

double shell_volume(double r0, double r1) {
	return (4.*M_PI/3.)*(r1*r1*r1 - r0*r0*r0);
}

/* SOLIDBODY METHODS */

SolidBody::SolidBody()
{
	vt_r = NULL;	vp_r = NULL;
	irs = 1;		ire = 0;
	ir_bci = 1;		ir_bco = 0;		vol = 0;
	zero_out();
}

SolidBody::~SolidBody()
{
	free_spatial();
}

void SolidBody::free_spatial()
{
	if (vt_r) {
		fftw_free(vt_r);	vt_r = NULL;	vp_r = NULL;
	}
}

void SolidBody::invalidate_spatial()
{
	vp_r = NULL;		// this marks the spatial field as invalid.
}

int SolidBody::spatial_ok() const
{
	return (vp_r != NULL);
}

void SolidBody::calc_spatial()
{
	if (irs <= ire) {	// non-zero solid body:
		#pragma omp single
		if (vp_r == NULL) {		// if invalid, recompute.
			cplx* tlm;
			int nspat = 2*(NPHI/2+1)*NLAT;

			if (vt_r == NULL)	// if not allocated
				vt_r = (double *) fftw_malloc( (2*nspat + 2*(LMAX+2)) * sizeof(double) );
		  #ifdef XS_DEBUG
			if (vt_r == NULL) runerr("[SolidBody::calc_spatial] fftw_malloc error");
		  #endif
			vp_r = vt_r + nspat;
			tlm = (cplx*) (vp_r + nspat);
			tlm[LiM(1,0)] = Y10_ct * Omega_z;
			if ((MRES==1)&&(MMAX>0)) tlm[LiM(1,1)] = Y11_st * cplx(Omega_x, -Omega_y);
			SHtor_to_spat_l(shtns, tlm, vt_r, vp_r, 1);
		}
	}
}

void SolidBody::zero_out()
{
	free_spatial();
	Omega_x = 0;	Omega_y = 0;	Omega_z = 0;
	phi0 = 0;
	Tb_z = 0;	Tu_z = 0;	Tzo = 0;
	IM = 0;		// no inertia moment by default
	#ifdef XS_ELLIPTIC
		eps_z = 0;
	#endif
	lmax = -1;	mmax = -1;
	PB0lm = NULL;
}

void SolidBody::set_limits(int i0, int i1)
{
	ir_bci = i0;	ir_bco = i1;
	if (ir_bci==0) i1--;		// exclude fluid boundaries.
	if (ir_bco==NR-1) i0++;
	if (i0 < irs_mpi) i0 = irs_mpi;
	if (i1 > ire_mpi) i1 = ire_mpi;
	irs = i0;		ire = i1;
	vol = shell_volume(r[ir_bci], r[ir_bco]);
}

/// Copy externaly imposed B to SolidBody, to allow rotating magnetic field.
void SolidBody::set_external_B(cplx *Pol)
{
	cplx* P0;
	int l,im, lm, lmx, mmx;

	if (PB0lm != NULL) runerr("External BC already set");

	lmx = -1;	mmx = -1;
	for (im=0; im<=MMAX; im++) {			// find lmax and mmax for the BC.
		for (l=im*MRES; l<=LMAX; l++) {
			lm = LiM(l, im);
			if (Pol[lm] != 0.0) {
				if (l > lmx) lmx = l;
				if (im > mmx) mmx = im;
			}
		}
	}

	lmax = lmx;		mmax= mmx;
	if (lmx >= 0) {		// non-zero external field :
		P0 = (cplx*) malloc(sizeof(cplx) * nlm_calc(lmx, mmx, MRES));
		if (P0==0) runerr("[SolidBody::set_external_B] allocation error");
		PB0lm = P0;
		for (im=0; im<=mmx; im++) {
			for (l=im*MRES; l<=lmx; l++) {
				lm = LiM(l,im);
				*P0++ = Pol[lm];		// store value.
				// the externally imposed field has been multiplied by 2*(l+1) in load_init().
			}
		}
	}
}

/// Copy solid-body rotation of a shell to SolidBody, to impose it.
void SolidBody::set_rotation(double rr, cplx *Tor)
{

	if ((MRES==1)&&(MMAX>0)) {
		int lm = LiM(1,1);
		Omega_x = real(Tor[lm]) / (rr * Y11_st);
		Omega_y = - imag(Tor[lm]) / (rr * Y11_st);
	}
	Omega_z = real(Tor[LiM(1,0)]) / (rr * Y10_ct);
}


/* FIELD METHODS */

/// radius of shell
double Spectral::radius(int ir) const
{
	if (ir<ir_bci) ir=ir_bci;		// boundary condition shells have same radius as boundary.
	if (ir>ir_bco) ir=ir_bco;
	return r[ir];
}

/// weight for radial integration
double Spectral::delta_r(int ir) const
{
	int ir_p = ir+1;
	int ir_m = ir-1;
	if (ir == ir_bci)      ir_m = ir;
	else if (ir == ir_bco) ir_p = ir;
	return (r[ir_p]-r[ir_m])*0.5;
}

Spectral::Spectral() {
	data = 0;		map_ptr = 0;
	ncomp = 0;		nshell = 0;		nelem = 0;
	irs = 10;		ire = 0;
	ir_bci = irs;	ir_bco = ire;	h0 = 0;			h1 = 0;
	bci = BC_NONE;	bco = BC_NONE;
	allocated = 0;	// marks the field as globally unallocated (or invalid)
	// we can have data == 0 and the field is still allocated on other processes.
}

Spectral::Spectral(int nc, int ne, int istart, int iend, int h) {
	data = 0;			map_ptr = 0;
	bci = BC_NONE;		bco = BC_NONE;
	allocated = 0;
	alloc(nc, ne, istart, iend, h);
}

void free_shells(double **data, int nshell, int h0=0, int h1=0) {
  #if XS_OMP != 1
	fftw_free(data[0]);
  #else
	#pragma omp parallel
	{
		int ir0 = h0;		int ir1 = nshell-1-h1;
		thread_interval_rad(ir0, ir1);
		if (ir1 >= ir0) {
			if (ir0 == h0) ir0 = 0;							// add halo/ghost back in
			if (ir1 == nshell-1-h1) ir1 = nshell-1;			// add halo/ghost back in
			#pragma omp critical
			fftw_free(data[ir0]);
		}
	}
  #endif
}

void Spectral::free_field() {
	if (data) {
		if (!map_ptr)	// don't free if it is an mmap !
		free_shells((double**) data, nshell, h0, h1);
		free(data);
		data = 0;
	}
	allocated = 0;		// mark field as unallocated
}

Spectral::~Spectral() {
	free_field();
}

#ifdef XS_MPI
/// This will exchange data between processes to have up-to-date ghost shells.
void Spectral::sync_mpi()
{
	// WARNING! The shells must be treated one by one, because of NUMA allocation scheme.
	MPI_Request req[4];
	int hmax = (h0 > h1) ? h0 : h1;

	// Sync first halo shell, then second one, etc... to allow 1 shell/process.
	for (int j=0; j<hmax; j++) {
		MPI_Request *req_ptr = req;
		if ((share_dn)&&(j<h0)) {
			MPI_Isend(get_data(0, irs+j),   2*nelem*ncomp, MPI_DOUBLE, i_mpi-1, j, MPI_COMM_WORLD, req_ptr++);	// down sending
			MPI_Irecv(get_data(0, irs-1-j), 2*nelem*ncomp, MPI_DOUBLE, i_mpi-1, j, MPI_COMM_WORLD, req_ptr++);	// down receive
		}
		if ((share_up)&&(j<h1)) {
			MPI_Isend(get_data(0, ire-j),   2*nelem*ncomp, MPI_DOUBLE, i_mpi+1, j, MPI_COMM_WORLD, req_ptr++);	// up sending
			MPI_Irecv(get_data(0, ire+1+j), 2*nelem*ncomp, MPI_DOUBLE, i_mpi+1, j, MPI_COMM_WORLD, req_ptr++);	// up receive
		}
		if (req_ptr - req) {
			int ierr = MPI_Waitall(req_ptr - req, req, MPI_STATUSES_IGNORE);
			if (ierr != MPI_SUCCESS) runerr("[Spectral::sync_mpi] MPI_Waitall failed.\n");
		}
	}
	MPI_Barrier(MPI_COMM_WORLD);
}

void Spectral::sync1_mpi(int ic, int istart, int iend, int lmstart, int lmend, int tag, MPI_Request **req)
{
	if ((ire < istart) || (irs > iend)) return;		// reject processes not involved.
	int shdn = (irs > istart);
	int shup = (ire < iend);
	int nelem = lmend-lmstart+1;
	if (shdn) {
		MPI_Isend(get_data(ic,irs) + lmstart, 2*nelem, MPI_DOUBLE, i_mpi-1, tag, MPI_COMM_WORLD, *req);
		MPI_Irecv(get_data(ic,irs-1) + lmstart, 2*nelem, MPI_DOUBLE, i_mpi-1, tag, MPI_COMM_WORLD, *req +1);
		*req += 2;
	}
	if (shup) {
		MPI_Isend(get_data(ic,ire) + lmstart, 2*nelem, MPI_DOUBLE, i_mpi+1, tag, MPI_COMM_WORLD, *req);
		MPI_Irecv(get_data(ic,ire+1) + lmstart, 2*nelem, MPI_DOUBLE, i_mpi+1, tag, MPI_COMM_WORLD, *req +1);
		*req += 2;
	}
}
#endif

void Spectral::copy(const Spectral& src)
{
	if (src.is_unallocated()) runerr("[Spectral::copy] empty field");
	if (is_unallocated()) {
		alloc(src.ncomp, src.nelem, src.ir_bci, src.ir_bco, src.halo);			// alloc if it is not yet allocated.
	} else {
		if ((ncomp != src.ncomp)||(nshell != src.nshell)||(nelem != src.nelem))
			runerr("[Spectral::copy] field mismatch");
		ir_bci = src.ir_bci;	ir_bco = src.ir_bco;
	}
	bci = src.bci;		bco = src.bco;		// copy boundary conditions.

  #if XS_OMP != 1
	size_t size = ncomp*nshell*nelem * 2*sizeof(double);
	memcpy(data[0], src.data[0], size);		// copy everything.
  #else
	// NUMA optimization.
	#pragma omp parallel
	{
		int ir0 = h0;		int ir1 = nshell-1-h1;		// exclude halo/ghost
		thread_interval_rad(ir0, ir1);
		if (ir1 >= ir0) {
			if (ir0 == h0) ir0 = 0;							// add halo/ghost back in
			if (ir1 == nshell-1-h1) ir1 = nshell-1;			// add halo/ghost back in
			size_t size = ncomp * (ir1-ir0+1) * nelem * 2*sizeof(double);		// components stored together.
			memcpy(data[ir0], src.data[ir0], size);
		}
	}
  #endif
}

/// allocate shells, NUMA friendly if OpenMP.
/// h0 and h1 specify the number of shells (included in nshell) that are lower and upper halo.
void alloc_shells(double **data, int ncomp, long ndouble, int nshell, int h0=0,int h1=0)
{
	size_t stride = ncomp*ndouble;		size_t dist = ndouble;		// interleaved allocation.

  #if XS_OMP != 1
	// we don't care about halo here
	size_t size = ncomp*nshell*ndouble * sizeof(double);
	int ir = 0;
		data[ir] = (double *) fftw_malloc( size );
		if (data[ir] == 0) runerr("[alloc_shells] allocation error 1");
		memset(data[ir], 0, size);		// zero out.
		for (int j=1; j<ncomp; j++) data[j*nshell + ir] = data[ir] + j*dist;
	for (ir = 1; ir < nshell; ir++) {		// shell by shell allocation.
		for (int j=0; j<ncomp; j++) data[j*nshell + ir] = data[j*nshell + ir-1] + stride;
	}
  #else
	/* NUMA optimization: try to keep memory close to the processor executing that thread.
	 * + use num_threads blocks so that allocated memory stays in blocks. */
	#pragma omp parallel
	{
		int ir0 = h0;		int ir1 = nshell-1-h1;		// exclude halo
		thread_interval_rad(ir0, ir1);
		if (ir1 >= ir0) {
			if (ir0 == h0) ir0 = 0;							// add halo back in
			if (ir1 == nshell-1-h1) ir1 = nshell-1;			// add halo back in
			size_t size = ncomp * (ir1-ir0+1) * ndouble * sizeof(double);
			#pragma omp critical
			{
				data[ir0] = (double *) fftw_malloc( size );
				if (data[ir0] == 0) runerr("[alloc_shells] allocation error 2");
			}
				memset(data[ir0], 0, size);		// touch memory and init to zero so that it is allocated near that thread.
				for (int j=1; j<ncomp; j++) data[j*nshell + ir0] = data[ir0] + j*dist;
			for (int ir = ir0+1; ir <= ir1; ir++) {		// shell by shell assignement
				for (int j=0; j<ncomp; j++) data[j*nshell + ir] = data[j*nshell + ir-1] + stride;
			}
		}
	}
  #endif
}

void Spectral::alloc_rad_ptr(int nc, int istart, int iend, int h)
{
	int ir, nr;

	if (!is_unallocated()) runerr("[Spectral::alloc] already allocated.");
	ir_bci = istart;	ir_bco = iend;		// global boundaries.
	h0 = 1;		h1 = 1;						// ghost shells (always 1).
	halo = h;		// halo: number of neighbour shell storage (MPI).
	#ifdef XS_MPI
		share_dn = 0;	share_up = 0;
		if (istart < irs_mpi) {
			share_dn = 1;		h0 = h;
			istart = irs_mpi;
		}
		if (iend > ire_mpi) {
			share_up = 1;		h1 = h;
			iend = ire_mpi;
		}
	#endif
	irs = istart;	ire = iend;		// local boundaries.
	nr = iend-istart+1 + h0+h1;		// add ghost or halo shells.
	ncomp = nc;		nshell = nr;
	if (iend >= istart) {
		if (iend-istart+1 < 1) runerr("[Spectral::alloc] at least 1 shells per process required.");
		// alloc radial structure.
		ir = nc*nr * sizeof(cplx *);
		data = (cplx **) malloc(ir);
		if (data == 0) runerr("[Spectral::alloc] allocation error");
	} else {
		// no field in this process
		irs = ir_bco+10;		ire = -10;
		share_dn = 0;	share_up = 0;
		nshell = 0;
	}
	allocated = 1;		// mark as allocated
}

/// istart,iend : global boundaries.
void Spectral::alloc(int nc, int ne, int istart, int iend, int h)
{
	alloc_rad_ptr(nc, istart, iend, h);
	nelem = ne;
	if (nshell > 0)
		alloc_shells((double**) data, nc, 2*ne, nshell, h0,h1);
}

void Spectral::zero_out()
{
	if (data) {
		int i0 = 0;		int i1 = nshell-1;
		thread_interval_rad(i0, i1);
		for (int ir=i0; ir<=i1; ir++) {
			v2d* sh = (v2d*) data[ir];
			for (long k=nelem*ncomp; k>0; k--) {		// assumes interleaved components.
				*sh++ = vdup(0.0);
			}
		}
		#pragma omp barrier
	}
}

void Spectral::zero_out_comp(int c)
{
	if ((data)&&(c<ncomp)) {
		int i0 = 0;		int i1 = nshell-1;
		thread_interval_rad(i0, i1);
		for (int ir=i0; ir<=i1; ir++) {
			v2d* sh = (v2d*) data[ir+c*nshell];
			for (long k=nelem; k>0; k--) {
				*sh++ = vdup(0.0);
			}
		}
		#pragma omp barrier
	}
}

void Spectral::zero_out_shell(int ir)
{
	if ( (data) && ((unsigned)(ir-irs+1) < nshell) ) {
		int lm0 = 0;
		int lm1 = nelem*ncomp - 1;
		thread_interval_lm(lm0, lm1);
		v2d* sh = (v2d*) get_data(0, ir);
		for (int lm=lm0; lm<=lm1; lm++) {		// assumes interleaved components.
			sh[lm] = vdup(0.0);
		}
	}
}

void Spectral::scale(const double scale)
{
	if (scale == 0.0) {
		zero_out();
	}
	else if ( (data) && (scale != 1.0) ) {
		s2d vscale = vdup(scale);
		int i0 = 0;
		int i1 = nshell-1;
		thread_interval_rad(i0, i1);
		int lm0 = 0;
		int lm1 = nelem*ncomp -1;
		thread_interval_lm(lm0, lm1);
		for (int ir=i0; ir<=i1; ir++) {
			v2d* sh = (v2d*) data[ir];
			for (long lm=lm0; lm<=lm1; lm++) {		// assumes interleaved components.
				sh[lm] *= vscale;
			}
		}
		#pragma omp barrier
	}
}

Spectral & Spectral::operator*=(const double val)
{
	scale(val);
	return *this;
}

Spectral & Spectral::operator+=(const Spectral &rhs)
{
	if ((rhs.ncomp != ncomp)||(rhs.nelem != nelem)) runerr("[+=] field mismatch");
	if ((rhs.irs < irs)||(rhs.ire > ire)) runerr("[+=] radial domain mismatch");

	int i0 = rhs.irs;
	int i1 = rhs.ire;
	thread_interval_rad(i0, i1);
	int lm0 = 0;
	int lm1 = nelem*ncomp -1;
	thread_interval_lm(lm0, lm1);
	for(int i=i0; i<=i1; i++) {
		v2d* d1 = (v2d*) get_data(0, i);
		v2d* d2 = (v2d*) rhs.get_data(0, i);
		for (int lm=lm0; lm<=lm1; lm++) {
			d1[lm] += d2[lm];		// assumes components stored together.
		}
	}
	#pragma omp barrier
	return *this;
}

Spectral & Spectral::operator-=(const Spectral &rhs)
{
	if ((rhs.ncomp != ncomp)||(rhs.nelem != nelem)) runerr("[-=] field mismatch");
	if ((rhs.irs < irs)||(rhs.ire > ire)) runerr("[-=] radial domain mismatch");


	int i0 = rhs.irs;
	int i1 = rhs.ire;
	thread_interval_rad(i0, i1);
	int lm0 = 0;
	int lm1 = nelem*ncomp -1;
	thread_interval_lm(lm0, lm1);
	for(int i=i0; i<=i1; i++) {
		v2d* d1 = (v2d*) get_data(0, i);
		v2d* d2 = (v2d*) rhs.get_data(0, i);
		for (int lm=lm0; lm<=lm1; lm++) {
			d1[lm] -= d2[lm];		// assumes components stored together.
		}
	}
	#pragma omp barrier
	return *this;
}

#ifndef XS_MPI
/// low-pass filter of 3D field at spatial scale "scale".
void Spectral::filter_scale(double scale)
{
	int ir;
	int ir0, ir1;
	Spectral Dlm;		// temp field.
	const double gwidth = 3.0;		// the width for gaussian filtering.
	v2d **dat0, **dat1;

	if (scale == 0.0) return;		// nothing to do.
	scale = 1.0/scale;				// spatial frequency.
	ir0 = irs;		ir1 = ire;

	Dlm.copy(*this);		// copy everything.
	zero_out();	// clear original
	dat0 = (v2d**) data - ir0+1;		// shifted pointer.
	dat1 = (v2d**) Dlm.data -ir0+1;		// shifted pointer.

	double dr2[NR];		// alloc on stack
	dr2[ir0] = 0.5*(r[ir0+1]-r[ir0]);
	dr2[ir1] = 0.5*(r[ir1]-r[ir1-1]);
	for (ir=ir0+1; ir< ir1; ir++) dr2[ir] = 0.5*(r[ir+1]-r[ir-1]);		// for integration.

// radial "quasi-gaussian" filter + spectral SH filter.
	#if XS_OMP == 1
	#pragma omp parallel for schedule(dynamic,1) private(ir)
	#endif
	for (ir=ir0+1; ir<ir1; ir++) {		// exclude boundaries
		double r0 = r[ir];
		double norm = 0.0;
		for (int jr=ir0; jr<=ir1; jr++) {		// convolution
			double  x2 = (r[jr] - r0)*scale;
			x2 *= x2;		// x2;
		/* this is a C2 filter (order 4 polynomial)
			if ( (x2 < 1.0) ) {
				double f = (1.0 - x2*(2.0-x2))*dr2[ir];		// finite support : -1 .. 1
				norm += f;
				for (int lm=0; lm<NLM; lm++) {
					Pol[ir][lm] += Dlm.Pol[jr][lm] * f;		Tor[ir][lm] += Dlm.Tor[jr][lm] * f;
				}
			}
		/* */
//		/* this is a truncated gaussian filter (better spectral convergence, but slower !)
			if ( (x2 < 3.2) ) {
				double f = exp(-gwidth*x2)*dr2[ir];
				norm += f;
				for (int k=0; k<ncomp; k++)
					for (int lm=0; lm<nelem; lm++)
						dat0[k*nshell +ir][lm] += dat1[k*nshell +jr][lm] * vdup(f);
			}
		/* */
		}
		double lc = M_PI * r0 * scale;
		for (int lm=0; lm<NLM; lm++) {
			double f = exp( -l2[lm]/(gwidth*lc*lc) )/norm;
			for (int k=0; k<ncomp; k++) dat0[k*nshell +ir][lm] *= vdup(f);
		}
	}
	for (ir=ir0; ir<=ir1;  ir+=(ir1-ir0)) {		// boundaries : no convolution (preserve boundary conditions)
		double lc = M_PI * r[ir] * scale;
		if (r[ir] != 0.0) {		// avoid NaN.
			for (int lm=0; lm<NLM; lm++) {
				double f = exp( -l2[lm]/(gwidth*lc*lc) );
				for (int k=0; k<ncomp; k++)  dat0[k*nshell +ir][lm] = vdup(f) * dat1[k*nshell +ir][lm];
			}
		}	// else = 0
	}
}
#endif

/// apply (l,m) filter
void Spectral::filter_lm(int lmin, int lmax, int mmin, int mmax)
{
	int ir, im, m, l, lm;

	if (lmax > LMAX) lmax = LMAX;	if (mmax > MMAX) mmax = MMAX;

	for (ir=0; ir < ncomp * nshell; ir++) {		// filter all data, including ghost shells...
		for (im=0; im<mmin; im++) {
			m = im*MRES;
			for(l=m; l<=LMAX; l++) {
				lm = LM(l,m);	data[ir][lm] = 0.0;
			}
		}
		for (im=mmin; im<=mmax; im++) {
			m = im*MRES;
			for(l=m; l<lmin; l++) {
				lm = LM(l,m);	data[ir][lm] = 0.0;
			}
			for(l=lmax+1; l<=LMAX; l++) {
				lm = LM(l,m);	data[ir][lm] = 0.0;
			}
		}
		for (im=mmax+1; im<=MMAX; im++) {
			m = im*MRES;
			for(l=m; l<=LMAX; l++) {
				lm = LM(l,m);	data[ir][lm] = 0.0;
			}
		}
	}
}

/// keep only symmetric or anti-symmetric part (with respect to the equator).
/// sym = 1 : anti-symmetric (odd). sym = 0 : symmetric (even)
void Spectral::filter_parity(int sym)
{
	int ir, im, m, l, lm;

	sym &= 1;		// parity (0 or 1)
	for (ir=0; ir<nshell; ir++) {
		for (im=0; im<=MMAX; im++) {
			m = im*MRES;
			for(l=m+1-sym; l<=LMAX; l+=2) {		// scalar or poloidal
				lm = LM(l,m);	data[ir][lm] = 0.0;
			}
			if (ncomp > 1) {
				for(l=m+sym; l<=LMAX; l+=2) {		// toroidal
					lm = LM(l,m);	data[ir+nshell][lm] = 0.0;
				}
			}
		}
	}
}

/// rotate a spherical harmonic field along the z-axis by 'phi' radians (rotate reference frame by angle -phi).
void Spectral::Zrotate(double phi)
{
	cplx shift;
	int i,im,l,m;

	for (i=0; i<ncomp*nshell; i++) {		// loop over all shells (including ghost shells).
		for (im=0; im<=MMAX; im++) {		// loop over all m's
			m=im*MRES;
			shift = cplx( cos(m*phi),  - sin(m*phi) );		// rotate reference frame by angle -phi
			for (l=m;l<=LMAX; l++) {
				data[i][LiM(l,im)] *= shift;
			}
		}
	}
}

/// Add random data to field.
/// select a symmetry : sym=0 : no symmetry;  sym=1 : odd;  sym=2 : even
void Spectral::add_random(double norm, int mmin, int mmax, int sym)
{
	double cr, clm;
	long int i, im, l, lm;
	long int pshift = 0;
	long int tshift = 0;
	long int linc = 1;
	
	if (mmin<0) mmin=0;
	if (mmax>MMAX) mmax=MMAX;
	if (sym > 0) {
		linc=2;
		if (sym == 1) pshift=1;
		if (sym == 2) tshift=1;
	}
	norm *= 1.0/RAND_MAX;

	/// random field.
	int i0 = irs;
	int i1 = ire;
	if (i0 == ir_bci) i0++;		// exclude boundaries.
	if (i1 == ir_bco) i1--;
	for (i=i0; i<=i1; i++) {
		cplx* d = get_data(0, i);
		for (im=mmin;im<=mmax;im++) {		// non-zero initial value for mmin<= m <= mmax
			int lmax = LMAX;
			#ifdef VAR_LTR
				lmax = ltr[i];		// stop at ltr.
			#endif
			for (l=im*MRES+pshift; l<=lmax; l+=linc) {		// first component is poloidal or scalar
				lm = LiM(l,im);
				clm = norm * el[lm]*l_2[lm];		// for a scalar
				if (ncomp == 2)
					clm *= r[i]*delta_r(i) * l_2[lm]*l_2[lm]*l_2[lm];		// for poloidal scalar
				d[lm] += clm * cplx( (rand()-RAND_MAX/2) , (rand()-RAND_MAX/2) );
				if (im==0) d[lm] = d[lm].real();		// keep m=0 real
			}
			if (ncomp == 2) {
				cplx* d2 = get_data(1, i);
				for (l=im*MRES+tshift; l<=lmax; l+=linc) {	// second component is toroidal
					lm = LiM(l,im);
					clm = norm*delta_r(i) * ((im+1.)/(mmax+1))*el[lm]*l_2[lm]*l_2[lm];
					d2[lm] += clm * cplx( (rand()-RAND_MAX/2) , (rand()-RAND_MAX/2) );
					if (im==0) d2[lm] = d2[lm].real();		// keep m=0 real
				}
			}
		}
	}
}

/* POLTOR METHODS */

PolTor::PolTor() {
	Pol = 0;		Tor = 0;		ncomp = 2;
}

PolTor::PolTor(int istart, int iend, int h) {
	alloc(istart, iend, h);
}

/// Allocate memory for a Spectral representation of a field.
/// This will reset the Boundary Conditions to NONE.
void PolTor::alloc(int istart, int iend, int h)
{
	Spectral::alloc(2, NLM, istart, iend, h);
	update_ptr();
}

void PolTor::clone(const PolTor& PT)
{
	alloc(PT.ir_bci, PT.ir_bco, PT.halo);
	bci = PT.bci;		bco = PT.bco;		// copy boundary conditions.
	update_ptr();
}

void PolTor::load(char *fn, FieldInfo *fh)
{
	Spectral::load(fn, fh);
	if (ncomp != 2) runerr("[load] expected 2 components");
	update_ptr();
}

void ScalarSH::alloc(int istart, int iend, int h)
{
	Spectral::alloc(1, NLM, istart, iend, h);
	update_ptr();
}

void ScalarSH::clone(const ScalarSH& S)
{
	alloc(S.ir_bci, S.ir_bco);
	bci = S.bci;		bco = S.bco;		// copy boundary conditions.
}

void ScalarSH::load(char *fn, FieldInfo *fh)
{
	Spectral::load(fn, fh);
	if (ncomp != 1) runerr("[load] expected 1 component");
	update_ptr();
}


double ScalarSH::energy_lm(int l, int m, int irstart, int irend) const
{
	cplx Qlm, Slm;
	double Elm = 0.0;
	
	if (irstart >= irend) return 0.0;
	if (irstart < irs) irstart = irs;
	if (irend > ire)   irend = ire;

	if (isvalid_lm(l,m)) {
		int lm = LM(l,m);
		for (int ir = irstart; ir <= irend; ir++) {
			Elm += norm(Sca[ir][lm]) * r[ir]*r[ir] * delta_r(ir);
		}
		if (m==0) Elm *= 0.5;
	}
	return Elm;
}


double PolTor::energy_lm(int l, int m, int irstart, int irend) const
{
	cplx Qlm, Slm;
	double Elm = 0.0;
	
	if (irstart >= irend) return 0.0;
	if (irstart < irs) irstart = irs;
	if (irend > ire)   irend = ire;

	if (isvalid_lm(l,m)) {
		int lm = LM(l,m);
		for (int ir = irstart; ir <= irend; ir++) {
			RadSph(ir, &Qlm - lm, &Slm - lm, lm, lm);
			double er = norm(Qlm) + l2[l]*(norm(Slm) + norm(Tor[ir][lm]));
			Elm += er * r[ir]*r[ir] * delta_r(ir);
		}
		if (m==0) Elm *= 0.5;
	}
	return Elm;
}

double coenergy_lrange(cplx* Q1, cplx* Q2, int lm0, int lm1)
{
	size_t l;
	double Er = 0.0;
	double Ei = 0.0;
	for (l=lm0; l<=lm1; l++) {
		Er += real(Q1[l])*real(Q2[l]);
		Ei += imag(Q1[l])*imag(Q2[l]);
	}
	return Er+Ei;
}

double coenergy(cplx* Q1, cplx* Q2)
{
	return 0.5*coenergy_lrange(Q1, Q2, 0, LMAX) 
			 + coenergy_lrange(Q1, Q2, LMAX+1, NLM-1);
}

double coenergy(cplx* Q1, cplx* S1, cplx* T1,  cplx* Q2, cplx* S2, cplx* T2)
{
	double Eq = coenergy(Q1, Q2);

	s2d Er = vdup(0.0);
	for (int im=0; im<=MMAX; im++) {
		int lm = LiM(im*MRES,im);
		for (int l=im*MRES; l<=LMAX; l++) {
			#ifndef XS_VEC
			Er += l2[l]*(real(S1[lm])*real(S2[lm]) + imag(S1[lm])*imag(S2[lm]));
			Er += l2[l]*(real(T1[lm])*real(T2[lm]) + imag(T1[lm])*imag(T2[lm]));
			#else
			v2d s1 = ((v2d*) S1)[lm];		v2d s2 = ((v2d*) S2)[lm];
			v2d t1 = ((v2d*) T1)[lm];		v2d t2 = ((v2d*) T2)[lm];			
			Er += vdup(l2[l])*(t1*t2 + s1*s2);
			#endif
			lm++;
		}
		if (im == 0) {		// factor for energy (1/2)
			Er *= vdup(0.5);
		}
	}
	return VSUM(Er) + Eq;
}

double energy(cplx* Q)
{
	return coenergy(Q, Q);
}

double energy(cplx* Q, cplx* S, cplx* T)
{
	return coenergy(Q,S,T,  Q,S,T);
}

double coenergy(const ScalarSH& S1, const ScalarSH& S2)
{
	int irs = S1.irs;
	int ire = S1.ire;
	if (S2.irs > irs) irs = S2.irs;
	if (S2.ire < ire) ire = S2.ire;

	double E = 0;
	#if XS_OMP == 1
	#pragma omp parallel for schedule(static) reduction(+ : E)
	#endif
	for (int ir=irs; ir <= ire; ir++) {
		double Er = coenergy(S1[ir], S2[ir]);
		E += Er * r[ir]*r[ir] * S1.delta_r(ir);
	}
	return E;
}

double coenergy(const PolTor& V1, const PolTor& V2)
{
	int irs = V1.irs;
	int ire = V1.ire;
	if (V2.irs > irs) irs = V2.irs;
	if (V2.ire < ire) ire = V2.ire;

	double E = 0;
	#if XS_OMP == 1
	#pragma omp parallel for schedule(static) reduction(+ : E)
	#endif
	for (int ir=irs; ir <= ire; ir++) {
		cplx *Q1 = (cplx*) malloc(4*NLM*sizeof(cplx));
		#ifdef XS_DEBUG
		if (Q1==0) runerr("[coenergy] allocation error");
		#endif
		cplx *Q2 = Q1 + 2*NLM;
		cplx *S1 = Q1 + NLM;			cplx *S2 = Q2 + NLM;
		V1.RadSph(ir, Q1, S1);
		V2.RadSph(ir, Q2, S2);
		double Er = coenergy(Q1,S1,V1.Tor[ir], Q2,S2,V2.Tor[ir]);
		free(Q1);
		E += Er * r[ir]*r[ir] * V1.delta_r(ir);
	}
	return E;
}


/** compute the energy of several components of the field.
 Esplit must be an array of 8 doubles that will be filled with:
 4 doubles of zonal energy (Poloidal symmetric, Poloidal anti-symmetric, Toroidal symmetric, Toroidal anti-symmetric),
 followed by 4 doubles of the corresponding non-zonal energies.
 [even indices are symmetric components and odd indices are anti-symmetric components].
 MPI: The result is local to each process, and should be summed using MPI_Reduce()
 TODO: remove, as this is now deprecated (for backward compatibility only).
*/
void Spectral::energy_split(double* Esplit, int irstart, int irend) const
{
	for (int k=0; k<8; k++) Esplit[k] = 0.0;

	if (irstart >= irend) return;
	if (irstart < irs) irstart = irs;
	if (irend > ire)   irend = ire;

	double E=0.0;

	#if XS_OMP == 1
	#pragma omp parallel firstprivate(irstart, irend)
	#endif
	{
		double e=0.0;
		SpectralDiags sd(LMAX,MMAX);
		thread_interval_rad(irstart, irend);
		for (int ir = irstart; ir <= irend; ir++) {
			acc_spectrum(ir, sd);
		}
		#pragma omp critical
		{
			E += *sd.Etot;
			Esplit[0] += sd.Esplit[2];
			Esplit[1] += sd.Esplit[3];
			Esplit[2] += sd.Esplit[8];
			Esplit[3] += sd.Esplit[9];
			Esplit[4] += sd.Esplit[4];
			Esplit[5] += sd.Esplit[5];
			Esplit[6] += sd.Esplit[10];
			Esplit[7] += sd.Esplit[11];
		}
	}
	return;
}

static int sconv_lmin = 3;
static int sconv_mmin = 3;

/// compute spectral convergence, which is a value between 0 [perfectly converged] and 1 [not converged].
double spectral_convergence(double* El, int nmin, int nmax, const int nend=4)
{
	double Sconv = 0.0;
	if (nmax >= (nmin + 2*nend)) {	// Sconv meaningful if the spectrum is large enough.
		double E0 = 0.0;
		for (int l=nmin; l<=nmax; l++) if (E0 < El[l]) E0=El[l];		// max of spectrum
		double E1 = 0.0;
		for (int l=nmax-nend+1; l<=nmax; l++) if (E1 < El[l]) E1=El[l];		// max of end of spectrum
		if (E0 > 0.0)	Sconv = E1/E0;
	}
	return Sconv;
}

// for internal use
void PolTor::_spectrum(int ir, int llim, int imlim, SpectralDiags& sd, const double w) const
{
	cplx *Q, *S, *T;
	double Er, pre;
	int l, im;
	double *const El = sd.El;
	double *const Em = sd.Em;
	double *const Esplit = sd.Esplit;

	Q = (cplx*) fftw_malloc(2*NLM*sizeof(cplx));
	#ifdef XS_DEBUG
	if (Q==0) runerr("[PolTor::_spectrum] allocation error");
	#endif
	S = Q + NLM;
	RadSph(ir, Q, S);
	T = Tor[ir];

	Er = 0.0;
	pre = 0.5 * w;		// factor for energy (1/2 r2*dr)
	for (im=0; im<=imlim; im++) {
		double ep0 = 0.0;
		double ep1 = 0.0;
		double et0 = 0.0;
		double et1 = 0.0;
		int lm = LiM(im*MRES,im);
		for (l=im*MRES; l<llim; l+=2) {
			double v2p0 = norm(Q[lm]) + l2[l]*norm(S[lm]);
			double v2t0 = l2[l]*norm(T[lm]);
			double v2p1 = norm(Q[lm+1]) + l2[l+1]*norm(S[lm+1]);
			double v2t1 = l2[l+1]*norm(T[lm+1]);
			ep0 += v2p0;		et0 += v2t0;
			ep1 += v2p1;		et1 += v2t1;
			lm+=2;
			El[l]   += pre*(v2p0+v2t0);
			El[l+1] += pre*(v2p1+v2t1);
		}
		if (l==llim) {
			double v2p0 = norm(Q[lm]) + l2[l]*norm(S[lm]);
			double v2t0 = l2[l]*norm(T[lm]);
			ep0 += v2p0;		et0 += v2t0;
			El[l] += pre*(v2p0+v2t0);
		}
		ep0 *= pre;		et0 *= pre;
		ep1 *= pre;		et1 *= pre;
		double em_ = ep0+et1+ep1+et0;
		Er += em_;
		Em[im] = em_;
		pre = w;		// for m>0, we count it twice (+m and -m)
		int ofs = (im*MRES)&1;
		Esplit[ofs]   += ep0;		// pol center sym/asym (m)
		Esplit[1-ofs] += ep1;		// pol center sym/asym (m)
		Esplit[6+ofs] += et1;		// tor center sym/asym (m)
		Esplit[7-ofs] += et0;		// tor center sym/asym (m)
		ofs = 0;	if (im > 0) ofs = 2;
		Esplit[2+ofs] += ep0;		// pol equatorially symmetric
		Esplit[3+ofs] += ep1;		// pol equatorially anti-sym
		Esplit[8+ofs] += et1;		// tor equatorially symmetric
		Esplit[9+ofs] += et0;		// tor equatorially anti-sym
	}
	fftw_free(Q);
	*sd.Etot = Er;
}

// for internal use
void ScalarSH::_spectrum(int ir, int llim, int imlim, SpectralDiags& sd, const double w) const
{
	cplx *Q;
	double Er, pre;
	int l, im;
	double *const El = sd.El;
	double *const Em = sd.Em;
	double *const Esplit = sd.Esplit;

	Q = Sca[ir];

	Er = 0.0;
	pre = 0.5 * w;		// factor for energy (1/2 r2*dr)
	for (im=0; im<=imlim; im++) {
		double ep0 = 0.0;
		double ep1 = 0.0;
		int lm = LiM(im*MRES,im);
		for (l=im*MRES; l<llim; l+=2) {
			double v2p0 = pre * norm(Q[lm]);
			double v2p1 = pre * norm(Q[lm+1]);
			ep0 += v2p0;
			ep1 += v2p1;
			lm+=2;
			El[l]   += v2p0;
			El[l+1] += v2p1;
		}
		if (l==llim) {
			double v2p0 = pre * norm(Q[lm]);
			ep0 += v2p0;
			El[l] += v2p0;
		}
		double em_ = ep0+ep1;
		Er += em_;
		Em[im] = em_;
		pre = w;		// for m>0, we count it twice (+m and -m)
		int ofs = (im*MRES)&1;
		Esplit[ofs]   += ep0;		// center symmetric/asym (m)
		Esplit[1-ofs] += ep1;		// center symmetric/asym (m)
		ofs = 0;	if (im > 0) ofs = 2;
		Esplit[2+ofs] += ep0;		// equatorially symmetric
		Esplit[3+ofs] += ep1;		// equatorially anti-sym
	}
	*sd.Etot = Er;
}

/// Accumulate spectra.
void Spectral::acc_spectrum(int ir, SpectralDiags& sd) const
{
	if ((ir < irs)||(ir > ire)) return;

	double Er, r2dr;
	int l, im, llim, imlim;
	cplx *Q, *S, *T;
	SpectralDiags sdr(LMAX,MMAX);

	imlim = MMAX;
	#ifndef VAR_LTR
		llim = LMAX;
	#else
		llim = ltr[ir];
		if (imlim*MRES > llim) imlim = llim/MRES;
	#endif

	r2dr = r[ir]*r[ir]*delta_r(ir);
	_spectrum(ir, llim, imlim, sdr, r2dr);

	// compute Sconv
	sdr.Sconv[0] = spectral_convergence(sdr.El, sconv_lmin, llim);
	sdr.Sconv[1] = spectral_convergence(sdr.Em, sconv_mmin, imlim);
/*	if ((sdr.Sconv[0] > 0.01) || (sdr.Sconv[1] > 0.01)) {		// DEBUG: print spectra when convergence is bad
		printf("ir=%d,llim=%d,imlim=%d, Sconv-l,m=%g, %g \n  l-spec:", ir,llim,imlim, sdr.Sconv[0], sdr.Sconv[1]);
		for (int l=0;l<=llim;l++) printf(" %.2g", sdr.El[l]);
		printf("\n  m-spec:");
		for (int m=0;m<=imlim;m++) printf(" %.2g ", sdr.Em[m]);
		printf("\n");
	}
*/
	sd.reduce(sdr);
}

void Spectral::r_spectrum(int ir, SpectralDiags& sd) const
{
	double Er, r2dr;
	int l, im, llim, imlim;
	cplx *Q, *S, *T;

	sd.clear();	
	if ((ir < irs)||(ir > ire)) return;

	if ((ir >= irs)&&(ir <= ire)) {
		imlim = MMAX;
		#ifndef VAR_LTR
			llim = LMAX;
		#else
			llim = ltr[ir];
			if (imlim*MRES > llim) imlim = llim/MRES;
		#endif

		_spectrum(ir, llim, imlim, sd);
	}

	sd.Sconv[0] = spectral_convergence(sd.El, sconv_lmin, llim);
	sd.Sconv[1] = spectral_convergence(sd.Em, sconv_mmin, imlim);
}


/** compute the energy of the spatial field described by its spectral components.
 For \b orthonormal spherical harmonics :
 for a Scalar field:
 \f[ e(r) = \frac{1}{2} \sum_{l,m} \, (2 - \delta_{m0}) |S_l^m|^2 \f]
 for a PolTor field:
 \f[ e(r) = \frac{1}{2} \sum_{l,m} \, (2 - \delta_{m0}) \left(\frac{l(l+1)}{r} |P_l^m| \right)^2 + l(l+1) (|S_l^m|^2 + |T_l^m|^2) \f]
 and \f[ E = \int_{r0}^{r1} e(r) r^2 dr \f]
 MPI: The result is local to each process, and should be summed using MPI_Reduce()
*/
void Spectral::energy(SpectralDiags& sd, int irstart, int irend) const
{
	sd.clear();

	if (irstart >= irend) return;
	if (irstart < irs) irstart = irs;
	if (irend > ire)   irend = ire;

	#if XS_OMP == 1
	#pragma omp parallel firstprivate(irstart, irend)
	#endif
	{
		thread_interval_rad(irstart, irend);
		SpectralDiags sdr(LMAX,MMAX);
		for (int ir = irstart; ir <= irend; ir++) {
			acc_spectrum(ir, sdr);
		}
		#pragma omp critical
		{
			sd.reduce(sdr);
		}
	}
}

/// return the rms value of a field.
/// MPI: The result is summed and each process has the right answer
double Spectral::rms(int irstart, int irend) const
{
	double nrj, vol;

	if (irstart >= irend) return 0.0;	
	if (irstart < ir_bci) irstart = irs;
	if (irend > ir_bco)   irend = ire;

	SpectralDiags sdr(LMAX,MMAX);
	energy(sdr, irstart, irend);
	nrj = sdr.energy();
	#ifdef XS_MPI
		double nrj2;
		MPI_Allreduce(&nrj, &nrj2, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD );
		nrj = nrj2;			// all ranks have the correct nrj here.
	#endif
	vol = shell_volume(r[irstart], r[irend]);
	return sqrt(2.0*nrj / vol);
}

/// deprecated, for backward compatibility TODO: remove
double Spectral::spectrum(double *El, double *Em) const
{
	SpectralDiags sd(LMAX,MMAX);
	energy(sd);
	if (El) for (int l=0; l<=LMAX; l++) El[l] = sd.El[l];
	if (Em) for (int m=0; m<=MMAX; m++) Em[m] = sd.Em[m];
	return sd.energy();
}


/*
// accurate energy ? (by linear interpolation of field)
// (s-r)*(
//    a2* (s-r)^2 * (6*s^2 + 3*r*s +r^2)/30
//  + b2* (s*s + r*s + r*r)/3
//  + ab* (s-r)*(3*s^2 + 2*r*s + r^2)/6 )
double PolTor::energy(int irstart, int irend) const
{
	double E = 0.0;
	v2d *Q0, *Q1, *S0, *S1, *mem;

	if (irstart >= irend) return 0.0;	
	if (irstart < irs) irstart = irs;
	if (irend > ire)   irend = ire;
	
	mem = (v2d*) fftw_malloc(sizeof(v2d)*4*NLM);
	Q0 = mem;	Q1 = Q0 + NLM;		S0 = Q0 + 2*NLM;		S1 = Q0 + 3*NLM;
	
	RadSph(irstart, (cplx*) Q0, (cplx*) S0);

	for (int ir = irstart; ir < irend; ir++) {
		RadSph(ir+1, (cplx*) Q1, (cplx*) S1);
		double dx = r[ir+1]-r[ir];
		double rs = r[ir]*r[ir+1];
		double r2 = r[ir]*r[ir];
		double s2 = r[ir+1]*r[ir+1];
		s2d c_aa = vdup( (6*s2 + 3*rs + r2)/30 );
		s2d c_bb = vdup( (s2 + rs + r2)/3 );
		s2d c_ab = vdup( (3*s2 +2*rs + r2)/6 );
		s2d der = vdup(0.0);
		for (int lm=0; lm<NLM; ++lm) {
			v2d b = Q0[lm];
			v2d a = Q1[lm]-Q0[lm];
			if (lm <= LMAX)
				der += vdup(0.5)*(a*a*c_aa  + a*b*c_ab  + b*b*c_bb);
			else 
				der += (a*a*c_aa  + a*b*c_ab  + b*b*c_bb);
		}
		for (int lm=0; lm<NLM; ++lm) {
			v2d sb = S0[lm];
			v2d sa = S1[lm]-S0[lm];
			v2d tb = ((v2d**)Tor)[ir][lm];
			v2d ta = ((v2d**)Tor)[ir+1][lm] - tb;
			if (lm <= LMAX)
				der += vdup(0.5)*((sa*sa + ta*ta)*c_aa  + (sa*sb + ta*tb)*c_ab  + (sb*sb + tb*tb)*c_bb) * vdup(l2[lm]);
			else
				der += ((sa*sa + ta*ta)*c_aa  + (sa*sb + ta*tb)*c_ab  + (sb*sb + tb*tb)*c_bb) * vdup(l2[lm]);
		}
		E += dx*VSUM(der);
		v2d *qx = Q0;	Q0 = Q1;	Q1 = qx;		// exchange buffers.
		v2d *sx = S0;	S0 = S1;	S1 = sx;
	}
	fftw_free(mem);
	return E;
}
*/


/* SCALARSH METHODS */

ScalarSH::ScalarSH()
{
	Sca = 0;		ncomp = 1;
}

ScalarSH::ScalarSH(int istart, int iend, int h)
{
	alloc(istart, iend, h);
}

cplx* ScalarSH::operator[](int ir) const
{
	CHECK_R_RANGE( ir, 0, "[] attempt to access unexisting shell !\n" )
	return Sca[ir];
}


/// compute radial derivative of scalar (handle boundary conditions)
/// Qlm = dT/dr;  Slm = T/r
void ScalarSH::Gradr(int ir, cplx *Qlm, cplx *Slm, int lms, int lme) const
{
	s2d ri_1;
	v2d *Q, *S, *Sr, *Si, *Sg;

	#ifdef XS_DEBUG
		if (lms > lme) runerr("[Gradr] nothing to do");
		if ((ir<irs)||(ir>ire))  runerr("[Gradr] out of radial boundaries !");
	#endif

	ri_1 = vdup(r_1[ir]);
	Q = (v2d*) Qlm;		Sr = (v2d*) Sca[ir];		S = (v2d*) Slm;
	if IN_RANGE_INCLUSIVE(ir, ir_bci+1, ir_bco-1) {
		// radial derivative
		s2d Gl = vdup(Gr[ir].l);	s2d Gd = vdup(Gr[ir].d);	s2d Gu = vdup(Gr[ir].u);
		v2d* Sl = (v2d*) Sca[ir-1];		v2d* Su = (v2d*) Sca[ir+1];		// MPI: assumes halo is up to date.
		LM_LOOP2(  lms, lme,
			Q[lm] = Gl*Sl[lm] + Gd*Sr[lm] + Gu*Su[lm];
			S[lm] = Sr[lm]*ri_1;
		)
	} else {	// handle boundary conditions:
		int BC, ii, ig;

		BC = bco;	ii = ir-1;	ig = ir+1;		// values if ir==ir_bco
		if (ir==ir_bci) {
			BC = bci;	ii = ir+1;	ig = ir-1;
			if (r[ir] == 0.0) {
				s2d dr_1 = vdup(r_1[ii]);
				LM_LOOP2( lms, lme,
					v2d s = vdup(0.);
					if (li[lm] == 1) s = ((v2d**) Sca)[ii][lm] * dr_1;		// vector: l=1 only
					Q[lm] = s;		S[lm] = s;
				)
				return;
			}
		}
		Sg = (v2d*) Sca[ig];		Si = (v2d*) Sca[ii];
		s2d dr_1 = vdup(1.0/(r[ii]-r[ir]));
		switch(BC) {
			case BC_ZERO :
				LM_LOOP2( lms, lme,  Q[lm] = Si[lm]*dr_1; 	S[lm] = vdup(0.0); )
				break;
			case BC_IMPOSED_FLUX :
				LM_LOOP2( lms, lme,  Q[lm] = vdup(0.0);		S[lm] = Sr[lm]*ri_1; )			// TODO: use ghost point instead.
				break;
			default:		// also BC_FIXED_TEMPERATURE
				LM_LOOP2( lms, lme,  Q[lm] = (Si[lm] - Sr[lm])*dr_1; 	S[lm] = Sr[lm]*ri_1; )		// order 1 approx of gradient
		}
	}
}

/// returns the gradient after adding the grad(S0lm) in spectral Q and S.
void ScalarSH::shell_grad(StatSpecScal *S0lm, int ir, cplx *Q, cplx *S, const int lms, const int lme) const
{
	Gradr(ir, Q, S, lms, lme);
	if (S0lm) {
		int nj = S0lm->nlm;
		unsigned* lma = S0lm->lm;
		cplx* TdT = S0lm->TdT + ir*nj*2;	//QST[ir*nlm*2 + 2*j]
		for (int j=0; j<nj; j++) {		// Add Background Spectral
			int lm = lma[j];
			#ifdef XS_SPARSE
			if (lm>0) {		// lm=0 is already in the sparse matrix part.
				S[lm] += TdT[j*2]*r_1[ir];		Q[lm] += TdT[j*2 +1];
			}
			#else
			if ((lm>=lms) && (lm<=lme)) {
				S[lm] += TdT[j*2]*r_1[ir];		Q[lm] += TdT[j*2 +1];
			}
			#endif
		}
	}
}

/// returns the lateral gradient after adding grad(S0lm), times r
void ScalarSH::shell_r_grad(StatSpecScal *S0lm, int ir, cplx *S, double *gt, double *gp) const
{
	cplx *tlm = Sca[ir];
	if (S0lm) {
		LM_LOOP(  S[lm] = tlm[lm];  )		// we need a copy here
		int nj = S0lm->nlm;
		unsigned* lma = S0lm->lm;
		cplx* TdT = S0lm->TdT + ir*nj*2;	//QST[ir*nlm*2 + 2*j]
		for (int j=0; j<nj; j++) {		// Add Background Spectral
			int lm = lma[j];
			S[lm] += TdT[j*2];
		}
		tlm = S;
	}
	SHS_SPAT(tlm, gt, gp);
}

/// set a spherical harmonic coefficient, with range checking.
inline void set_Ylm(cplx *ylm, int l, int m, cplx cval)
{
	if ((ylm == NULL)||(!isvalid_lm(l, m))) {
		runerr("attempt to set inexistant spherical harmonic coefficient");
	}
	ylm[LM(l,m)] = cval;
}

/// read a spherical harmonic coefficient, with range checking.
inline cplx get_Ylm(cplx *ylm, int l, int m)
{
	if ((ylm == NULL)||(!isvalid_lm(l, m))) {
		fprintf(stderr,"WARNING: attempt to read unexisting mode.\n");
		return 0.0;
	}
	return ylm[LM(l,m)];
}



inline cplx ScalarSH::rlm(int ir, int l, int m) const
{
	CHECK_R_RANGE( ir, 0, "WARNING: attempt to read unexisting shell.\n" )
	return get_Ylm(Sca[ir],l,m);
}

inline void ScalarSH::set_rlm(int ir, int l, int m, cplx val) {
	CHECK_R_RANGE( ir, , "WARNING: attempt to write unexisting shell.\n" )
	set_Ylm(Sca[ir], l, m, val);
}


inline cplx PolTor::Prlm(int ir, int l, int m) const
{
	CHECK_R_RANGE( ir, 0, "WARNING: attempt to read unexisting shell.\n" )
	return get_Ylm(Pol[ir],l,m);
}
inline cplx PolTor::Trlm(int ir, int l, int m) const
{
	CHECK_R_RANGE( ir, 0, "WARNING: attempt to read unexisting shell.\n" )
	return get_Ylm(Tor[ir],l,m);
}

inline void PolTor::set_Prlm(int ir, int l, int m, cplx val) {
	CHECK_R_RANGE( ir, , "WARNING: attempt to write unexisting shell.\n" )
	set_Ylm(Pol[ir], l, m, val);
}
inline void PolTor::set_Trlm(int ir, int l, int m, cplx val) {
	CHECK_R_RANGE( ir, , "WARNING: attempt to write unexisting shell.\n" )
	set_Ylm(Tor[ir], l, m, val);
}

/// vector vr, vt, vp is converted to cartesian coordinates.
void spher_to_cart(double ct,double p,double *vr,double *vt,double *vp)
{
	double st, cp,sp;
	double vx,vy,vz,vs;

	st = sqrt((1.0-ct)*(1.0+ct));	cp = cos(p);	sp = sin(p);
	vz = *vr*ct - *vt*st;		vs = *vr*st + *vt*ct;
	vx = vs*cp - *vp*sp;		vy = vs*sp + *vp*cp;
	*vr = vx;	*vt = vy;	*vp = vz;
}


/* BOUNDARY AWARE Q,S,T FUNCTIONS */

/// requires lms <= lme
void PolTor::RadSph(int ir, cplx *Qlm, cplx *Slm, int lms, int lme) const		// Q & S
{
	s2d dr_1, ri_1;
	v2d *Q, *S, *Pr, *Pi, *Pg;

	#ifdef XS_DEBUG
		if (lms > lme) runerr("[RadSph] nothing to do");
		if ((ir<irs)||(ir>ire))  runerr("[RadSph] out of radial boundaries !");
	#endif

	Q = (v2d*) Qlm;		S = (v2d*) Slm;		Pr = (v2d*) Pol[ir];
	ri_1 = vdup(r_1[ir]);
	if IN_RANGE_INCLUSIVE(ir, ir_bci+1, ir_bco-1) {			// MPI: assumes halo is up to date.
		// Solenoidal deduced from radial derivative of Poloidal
		s2d Wl = vdup(Wr[ir].l);	s2d Wd = vdup(Wr[ir].d);	s2d Wu = vdup(Wr[ir].u);
		v2d* Pl = (v2d*) Pol[ir-1];		v2d* Pu = (v2d*) Pol[ir+1];
		LM_LOOP2(  lms, lme,
			S[lm] = Wl*Pl[lm] + Wd*Pr[lm] + Wu*Pu[lm];
			Q[lm] = vdup(l2[lm])*ri_1 * Pr[lm];
		)
	} else {	// handle boundary conditions:
		int BC, ii, ig;

		BC = bco;	ii = ir-1;	ig = ir+1;		// values if ir==ir_bco
		if (ir==ir_bci) {
			BC = bci;	ii = ir+1;	ig = ir-1;
			if (r[ir] == 0.0) {	// field at r=0 : Pol=0, Tor=0, but S = 2.dP/dr (l=1 only) and Q=S
				dr_1 = vdup(r_1[ii]);
				LM_LOOP2( lms, lme,
					v2d s = vdup(0.);
					if (li[lm] == 1) s = ((v2d**) Pol)[ii][lm] * (dr_1+dr_1);
					S[lm] = s;		Q[lm] = s;
				)
				return;
			}
		}
		Pg = (v2d*) Pol[ig];		Pi = (v2d*) Pol[ii];
		LM_LOOP2(  lms, lme,  Q[lm] = vdup(l2[lm])*ri_1 * Pr[lm];  )
		dr_1 = vdup(1.0/(r[ii]-r[ir]));
		switch(BC) {
			case BC_ZERO :
				LM_LOOP2( lms, lme,  S[lm] = vdup(0.0);  Q[lm] = vdup(0.0); )
				break;
			case BC_NO_SLIP :	// Velocity field (no slip => Pol,Tor,dP/dr prescribed)
				LM_LOOP2( lms, lme,  S[lm] = ri_1*Pr[lm] + Pg[lm];  )	// Pol/r + dP/dr  [dP/dr stored at ig]
				break;
			case BC_FREE_SLIP :	// Velocity field (free slip BC) : Pol = 0, dT/dr = Tor/r, S = dP/dr
				LM_LOOP2( lms, lme,  S[lm] = dr_1 * Pi[lm];  )
				break;
			case BC_MAGNETIC :	// Magnetic field (insulator BC) : Tor=0, dP/dr = l/r.Pol - (2l+1)/r.Pext => S = (l+1)Pol/r - (2l+1)/r.Pext
				if (ir==ir_bci) {
					LM_LOOP2( lms, lme,  S[lm] = ri_1 * (vdup(el[lm])*Pr[lm] + Pr[lm] - Pg[lm]);  )	// [(2l+1).Pext stored at ig]
				} else {	// ir==ir_bco
					LM_LOOP2( lms, lme,  S[lm] = ri_1 * (Pg[lm] - vdup(el[lm])*Pr[lm]);  )	// [(2l+1).Pext stored at ig]
				}
				break;
			case BC_CURL_FREE_SLIP :	// dP/dr = Pol/r => S = 2P/r
				LM_LOOP2( lms, lme,  S[lm] = (ri_1+ri_1) * Pr[lm];  )
				break;
			case BC_ELLIPTIC :	// Pol imposed by ellipticity, d2P/dr2 deduced from stress-free condition.
			{	s2d dx = vdup(r[ii]-r[ir])*ri_1*ri_1;
				LM_LOOP2( lms, lme,
					S[lm] = (ri_1 - dr_1 - dx + dx*vdup(0.5*l2[lm])) * Pr[lm] + dr_1 * Pi[lm];  )
				break;
			}
			default :	// use order 1 approx for dP/dr
				LM_LOOP2( lms, lme,  S[lm] = (ri_1 - dr_1) * Pr[lm] + dr_1 * Pi[lm];  )
		}
	}
}

/// Computes the Q,S,Tor coefficients of a PolTor field, including proper boundary conditions.
void PolTor::qst(int ir, int lm, cplx *Q, cplx *S, cplx *T) const
{
	RadSph(ir, Q-lm, S-lm, lm, lm);
	*T = Tor[ir][lm];
}

void PolTor::curl_QST(int ir, cplx *Qlm, cplx *Slm, cplx *Tlm, int lms, int lme) const
{
	s2d ri_1, dr_1;
	v2d *Q, *S, *T;
	v2d **Pr, **Tr;

	#ifdef XS_DEBUG
		if (lms > lme) runerr("[curl_QST] nothing to do");
		if ((ir<irs)||(ir>ire))  runerr("[curl_QST] out of radial boundaries !");
	#endif

	Q = (v2d*) Qlm;		S = (v2d*) Slm;		T = (v2d*) Tlm;
	Pr = (v2d**) Pol;		Tr = (v2d**) Tor;
	ri_1 = vdup(r_1[ir]);
	if IN_RANGE_INCLUSIVE(ir, ir_bci+1, ir_bco-1) {			// MPI: assumes halo is up to date.
		s2d Wl = vdup(Wr[ir].l);	s2d Wd = vdup(Wr[ir].d);	s2d Wu = vdup(Wr[ir].u);
		v2d* PTl = Tr[ir-1];		v2d* PTd = Tr[ir];			v2d* PTu = Tr[ir+1];
		LM_LOOP2( lms, lme,  Q[lm] = ri_1*vdup(l2[lm]) * PTd[lm];
					S[lm] = Wl*PTl[lm] + Wd*PTd[lm] + Wu*PTu[lm];  )
		s2d ri_2 = ri_1*ri_1;		// 1/r^2
		Wl = vdup(Lr[ir].l);	Wd = vdup(Lr[ir].d);	Wu = vdup(Lr[ir].u);
		PTl = Pr[ir-1];			PTd = Pr[ir];			PTu = Pr[ir+1];
		LM_LOOP2( lms, lme,  T[lm] = (ri_2*vdup(l2[lm]) - Wd)*PTd[lm] - Wl*PTl[lm] - Wu*PTu[lm];  )
	} else {	// handle boundary conditions:
		int BC, ii, ig;
		BC = bco;	ii = ir-1;	ig = ir+1;		// values if ir==ir_bco
		if (ir==ir_bci) {
			BC = bci;	ii = ir+1;	ig = ir-1;
			if (r[ir] == 0.0) {	// field at r=0 : Pol=0, Tor=0, but S = 2.dP/dr (l=1 only) and Q=S
				s2d dr_1 = vdup(r_1[ii]);
				LM_LOOP2( lms, lme,
					v2d s = vdup(0.);	T[lm] = s;
					if (li[lm] == 1) s = Tr[ii][lm] * (dr_1+dr_1);
					S[lm] = s;		Q[lm] = s;
				)
				return;
			}
		}
		dr_1 = vdup(1.0/(r[ii]-r[ir]));
		switch(BC) {
			case BC_ZERO:
			case BC_NO_SLIP :	// Velocity field (no slip => Pol,Tor,dP/dr prescribed)
			{	s2d dr_2 = dr_1*dr_1;		dr_2 += dr_2;		// 2/dr2
				LM_LOOP2( lms, lme,  T[lm] = (dr_2 + vdup(l2[lm])*ri_1*ri_1) * Pr[ir][lm]
											- dr_2 * Pr[ii][lm]
											+ vdup(2.)*(dr_1-ri_1) * Pr[ig][lm];  )  // [dP/dr stored at ig]
				break;
			}
			case BC_FREE_SLIP :	// Velocity field (free slip BC) : Pol = 0, dT/dr = Tor/r, S = dP/dr
			{	s2d dr_2 = -(ri_1+ri_1)*dr_1;
				LM_LOOP2( lms, lme,	 Q[lm] = vdup(l2[lm])*ri_1 * Tr[ir][lm];
									 S[lm] = (ri_1+ri_1) * Tr[ir][lm];
									 T[lm] = dr_2 * Pr[ii][lm];  )
				return;
			}
			case BC_MAGNETIC :	// Magnetic field (insulator BC) : Tor=0, dP/dr = l/r.Pol - (2l+1)/r.Pext => S = (l+1)Pol/r - (2l+1)/r.Pext
			{	LM_LOOP2( lms, lme,	 Q[lm] = vdup(0.0);
									 S[lm] = dr_1 * Tr[ii][lm];  )		// Jr=0, T=0
				s2d cg = ri_1*(ri_1 - dr_1);	cg += cg;			// ghost coeff.
				s2d dr_2 = dr_1*dr_1;			dr_2 += dr_2;		// 2/dr2
				s2d ri_2 = ri_1*ri_1;		// 1/r2
				s2d dx = ri_1*dr_1;				dx += dx;		// 2/(rdr)
				if (ir==ir_bci) {
					LM_LOOP2( lms, lme,  T[lm] = (dr_2 + dx*vdup(el[lm]) + vdup(el[lm]*el[lm]-el[lm])*ri_2) * Pr[ir][lm]
												- dr_2 * Pr[ii][lm]
												+ cg * Pr[ig][lm];  )	// [(2l+1).Pext stored at ig]
				} else {	// ir==ir_bco
					LM_LOOP2( lms, lme,  T[lm] = (dr_2 - dx*vdup(el[lm]+1.) + vdup((el[lm]-2.)*(el[lm]+1.))*ri_2) * Pr[ir][lm]
												- dr_2 * Pr[ii][lm]
												- cg * Pr[ig][lm];  )	// [(2l+1).Pext stored at ig]
				}
				return;
			}
			case BC_ELLIPTIC :	// Pol imposed by ellipticity, d2P/dr2 deduced from stress-free condition.
			{	s2d dx = vdup(r[ii]-r[ir])*ri_1*ri_1;
				LM_LOOP2( lms, lme,	 Q[lm] = vdup(l2[lm])*ri_1 * Tr[ir][lm];
									 S[lm] = (ri_1+ri_1) * Tr[ir][lm];
									 T[lm] = (ri_1+ri_1) * ( Pr[ir][lm] * (dr_1-ri_1+dx + ri_1*vdup(l2[lm]) - dx*vdup(0.5*l2[lm]))
																- dr_1*Pr[ii][lm] );  )
				return;
			}
			default :	// use order 1 approx for dP/dr
				LM_LOOP2( lms, lme,	 T[lm] = vdup(0.0);  )		// ???? \TODO Check this !
		}
		LM_LOOP2( lms, lme,	 Q[lm] = vdup(l2[lm])*ri_1 * Tr[ir][lm];
							 S[lm] = Tr[ir][lm] * (ri_1 - dr_1) + dr_1 * Tr[ii][lm];  )	// Tor/r + dT/dr
	}
}


/// Computes the Q,S,Tor coefficients of the curl of a PolTor field, including proper boundary conditions.
void PolTor::curl_qst(int ir, int lm, cplx *Q, cplx *S, cplx *T) const
{
	curl_QST(ir, Q-lm, S-lm, T-lm, lm, lm);
}

/// compute curl of PolTor vector.
void PolTor::curl(int istart, int iend)
/// Pol = Tor;  Tor = - Lap.Pol
{
	cplx *lapl, *lapd, *lapt, *mem, *scratch;
	int ir;

	if (istart < irs) istart = irs;
	if (iend > ire) iend = ire;
	if (istart >= iend) return;

	mem = (cplx*) fftw_malloc( 3*NLM*sizeof(cplx) );
	#ifdef XS_DEBUG
	if (mem==0) runerr("[PolTor::curl] allocation error");
	#endif
	lapl = mem;	lapd = mem + NLM;	scratch = mem + 2*NLM;

	ir = istart;
		curl_QST(ir, scratch, scratch, lapl);		// only lapl is interesting here.
	for (ir=istart+1; ir < iend; ir++) {
		LM_LOOP(  lapd[lm] = (l2[lm]*r_2[ir] - Lr[ir].d)*Pol[ir][lm] - Lr[ir].l*Pol[ir-1][lm] - Lr[ir].u*Pol[ir+1][lm];  )
		LM_LOOP(  Pol[ir-1][lm] = Tor[ir-1][lm];  )
		LM_LOOP(  Tor[ir-1][lm] = lapl[lm];  )
		lapt = lapl;	lapl = lapd;	lapd = lapt;	// rotate buffers.
	}
	ir = iend;
		curl_QST(ir, scratch, scratch, lapd);
		LM_LOOP(  Pol[ir-1][lm] = Tor[ir-1][lm];  )
		LM_LOOP(  Tor[ir-1][lm] = lapl[lm];  )
		LM_LOOP(  Pol[ir][lm] = Tor[ir][lm];  )
		LM_LOOP(  Tor[ir][lm] = lapd[lm];  )

	fftw_free(mem);
	// update BC
	bci = (bci == BC_FREE_SLIP) ? BC_CURL_FREE_SLIP : BC_NONE;
	bco = (bco == BC_FREE_SLIP) ? BC_CURL_FREE_SLIP : BC_NONE;
	#ifdef XS_MPI
		sync_mpi();
	#endif
}


/// compute the curl of the field.
/// on input, Pol must be the toroidal component T, Tor must be the radial component Q,
/// the third (extra) component must be the spheroidal one S.
/// on output, Pol is unchanged, Tor = Q/r - 1/r.d(rS)/dr = (Q-S)/r - dS/dr
void PolTor::curl_from_TQS(Spectral* S, int istart, int iend, int sync_tag)
{
#ifdef XS_DEBUG
	if (S==0) runerr("[PolTor::curl_from_TQS] missing extra component");
#endif
#ifdef XS_MPI
	if ((ire < istart) || (irs > iend)) return;		// reject processes not involved.
	if (sync_tag >= 0) {
		#pragma omp barrier
		#pragma omp master
		{
			MPI_Request req[4];
			MPI_Request *req_ptr = req;
			S->sync1_mpi(0, istart, iend, 0, NLM-1, sync_tag, &req_ptr);
			if (req_ptr-req > 0) {
				int ierr = MPI_Waitall(req_ptr-req, req, MPI_STATUSES_IGNORE);
				if (ierr != MPI_SUCCESS) runerr("[curl_from_TQS] MPI_Waitall failed.\n");
			}
		}
		#pragma omp barrier
	}
#endif
	int ir0 = (istart < irs) ? irs : istart;
	int ir1 = (iend > ire)   ? ire : iend;
	thread_interval_rad(ir0, ir1);
	int lm0 = 0;
	int lm1 = NLM-1;
	thread_interval_lm(lm0, lm1);
	for (int ir=ir0; ir <= ir1; ir++) {
		s2d r1 = vdup(r_1[ir]);
		v2d* Tr = (v2d*) Tor[ir];		v2d* Sd = (v2d *) S->get_data(0,ir);
		if (lm0==0) Tr[lm0++] = vdup(0.0);		// l=0 contribution is zero after curl.
		if IN_RANGE_INCLUSIVE(ir, istart+1, iend-1) {
			v2d* Sl = (v2d *) S->get_data(0,ir-1);		v2d* Su = (v2d *) S->get_data(0,ir+1);
			s2d Wl = vdup(Wr[ir].l);	s2d Wd = vdup(Wr[ir].d);	s2d Wu = vdup(Wr[ir].u);
			for (int lm=lm0; lm<=lm1; lm++) {
				Tr[lm] = r1*Tr[lm] - (Wl * Sl[lm] + Wd * Sd[lm] + Wu * Su[lm]);
			}
		} else {
			int ii = (ir==istart) ? ir+1 : ir-1;
			s2d dx = vdup(1.0/(r[ii]-r[ir]));
			v2d* Si = (v2d *) S->get_data(0,ii);
			for (int lm=lm0; lm<=lm1; lm++) {
				Tr[lm] = r1*(Tr[lm] - Sd[lm]) - dx*(Si[lm] - Sd[lm]);
			}
		}
	}
}


/****************************
 *** DIAGNOSTIC FUNCTIONS ***
 ****************************/

void fill_stdt(double* stdt)
{
	int it;
	int nth_2 = (NLAT+1)/2;
// compute dtheta, assume symmetry.
	for (it=0; it <= nth_2; it++)
		stdt[it+1] = acos(ct[it]);		// theta
	it = 0;
		stdt[it] = st[it] * 0.5*(stdt[it+2] + stdt[it+1]);
	for (it=1; it<nth_2; it++)
		stdt[it] = st[it] * 0.5*(stdt[it+2] - stdt[it]);
	for (it=nth_2; it<NLAT; it++)
		stdt[it] = stdt[NLAT-1-it];
}

inline double hvmax(rnd a)
{
  #ifndef XS_VEC
	return a;
  #else
	#ifdef __AVX512F__
		return _mm512_reduce_max_pd(a);
	#else
		#ifdef __AVX__
			s2d max1 = _mm_max_pd( _mm256_castpd256_pd128(a), _mm256_extractf128_pd(a, 1) );
		#else
			s2d max1 = a;
		#endif
		return _mm_cvtsd_f64(_mm_max_sd(max1, _mm_unpackhi_pd(max1,max1)));
	#endif
  #endif
}

/// compute the maximum of the squared norm of vector field (vr,vt,vp)
double absmax2(double *vr, double *vt, double *vp, size_t nspat0, size_t nspat1)
{
	rnd v2_max = vall(0.0);
	for (size_t k=nspat0/VSIZE; k<nspat1/VSIZE; k++) {
		rnd vvr = vread(vr,k);
		rnd vvt = vread(vt,k);
		rnd vvp = vread(vp,k);
		rnd v2 = vvr*vvr + vvt*vvt + vvp*vvp;
		v2_max = vmax(v2_max, v2);
	}
	return hvmax(v2_max);
}

/// compute the maximum of the squared norm of vector field (vt,vp)
double absmax2(double *vt, double *vp, size_t nspat0, size_t nspat1)
{
	rnd v2_max = vall(0.0);
	for (size_t k=nspat0/VSIZE; k<nspat1/VSIZE; k++) {
		rnd vvt = vread(vt,k);
		rnd vvp = vread(vp,k);
		rnd v2 = vvt*vvt + vvp*vvp;
		v2_max = vmax(v2_max, v2);
	}
	return hvmax(v2_max);
}

/// compute the maximum of the squared norm of scalar field s
double absmax2(double *s, size_t nspat0, size_t nspat1)
{
	#ifndef XS_VEC
		double v_max = 0.0;
		for (size_t k=nspat0; k<nspat1; k++) {
			double vs = fabs(s[k]);		// it is faster to take absolute value than to square.
			v_max = vmax(v_max, vs);
		}
		return v_max*v_max;
	#else
		rnd v2_max = vall(0.0);
		for (size_t k=nspat0/VSIZE; k<nspat1/VSIZE; k++) {
			rnd vs = vread(s,k);
			vs *= vs;
			v2_max = vmax(v2_max, vs);
		}
		return hvmax(v2_max);
	#endif
}

double PolTor::r_absmax2(int ir) const
{
	cplx *Q, *S;
	double *vr, *vt, *vp;
	const int nspat = 2*(NPHI/2+1)*NLAT;

	Q = (cplx *) fftw_malloc( 3*nspat * sizeof(double) + 2*NLM * sizeof(cplx));
	#ifdef XS_DEBUG
	if (Q==0) runerr("[PolTor::r_absmax2] allocation error");
	#endif
	S = Q + NLM;
	vr = (double *) (S + NLM);
	vt = vr + nspat;	vp = vt + nspat;

	RadSph(ir, Q, S);
	SHV3_SPAT(Q, S, Tor[ir], vr, vt, vp);
	double max2 = absmax2(vr, vt, vp, 0,NPHI*NLAT);

	fftw_free(Q);
	return max2;
}

double ScalarSH::r_absmax2(int ir) const
{
	double* s = (double *) fftw_malloc( 2*(NPHI/2+1)*NLAT * sizeof(double));
	#ifdef XS_DEBUG
	if (s==0) runerr("[ScalarSH::r_absmax2] allocation error");
	#endif
	SH_SPAT(Sca[ir], s);
	double max2 = absmax2(s, 0,NPHI*NLAT);

	fftw_free(s);
	return max2;
}

/// compute Linf norm (maximum value) of the spatial field described by its spectral components.
/// First and last shells are ignored, so that boundary conditions are not important.
/// MPI: reduction is performed, all ranks have the correct result.
double Spectral::absmax(int irstart, int irend) const
{
	double maxmax = 0.0;

	if (irstart > irend) return 0.0;
	if (irstart < irs) irstart = irs;
	if (irend > ire)   irend = ire;

	#if XS_OMP == 1
	#pragma omp parallel shared(maxmax) firstprivate(irstart, irend)
	#endif
	{
		double max,v2;

		max = 0.0;
		thread_interval_rad(irstart, irend);
		for (int ir=irstart; ir<=irend; ir++) {
			double maxr = r_absmax2(ir);
			if (maxr > max) max = maxr;
		}
		#pragma omp critical
		{
			if (max > maxmax) maxmax = max;
		}
	}
	#ifdef XS_MPI
		double max2;
		MPI_Allreduce( &maxmax, &max2, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD );
		maxmax = max2;			// all ranks have the correct max here.
	#endif
	return sqrt(maxmax);
}

/// compute z-averages in spatial domain (using interpolation).
/// buf is the output buffer, where vs,vp,vs2,vp2,vsvp averaged over z is stored.
/// It must contain 5*ns*NPHI doubles.
/// Uses multiple threads if called from an OpenMP parallel region.
void PolTor::special_z_avg(int ns, const double *s, double *buf, const int rstep) const
{
	double z, dz, H_1, ztop;
	double s2, cost, sint;
	cplx *Q, *S;
	double *vr, *vt, *vp, *buf2;
	double *vs1, *vp1, *vs2, *vp2, *vsvp;
	int i0, is_tc;
	const int nphi = NPHI;
	const int nspat = (NPHI/2+1)*2*NLAT;

	// TODO: make it work with XS_OMP 1 or 2.
	#ifdef _OPENMP
		#pragma omp single
		{
			memset(buf, 0, sizeof(double)*5*ns*nphi);
		}
		// allocate temporary fields for zavg (private)
		buf2 = (double*) malloc(sizeof(double)*ns*nphi*5);
		#ifdef XS_DEBUG
		if (buf2==0) runerr("[PolTor::special_z_avg] allocation error 1");
		#endif
	#else
		buf2 = buf;
	#endif
	vs1 = buf2;		vp1 = buf2 + nphi*ns;
	vs2 = buf2 + 2*nphi*ns;		vp2 = buf2 + 3*nphi*ns;		vsvp = buf2 + 4*nphi*ns;
	memset(buf2, 0, sizeof(double)*5*ns*nphi);

	// allocate temporary fields for one shell (private)
	vr = (double*) fftw_malloc(sizeof(double)*(4*NLM + 3*nspat));
	#ifdef XS_DEBUG
	if (vr==0) runerr("[PolTor::special_z_avg] allocation error 2");
	#endif
	Q = (cplx*) (vr + 3*nspat);
	vt = vr + nspat;	vp = vr + 2*nspat;
	S = Q + NLM;

	i0 = ((irs + rstep-1)/rstep);		// start at an rstep multiple.
	is_tc = 0;
	while( s[is_tc] < r[ir_bci] ) is_tc++;		// find the tangent-cylinder boundary in s-domain.
	i0 *= rstep;		// rstep multiple.

	#pragma omp for schedule(dynamic) nowait
	for (int ir=i0; ir<=ire; ir+=rstep) {		// span radial domain of each process.
		RadSph(ir, Q, S);
		SHV3_SPAT(Q, S, Tor[ir], vr, vt, vp);		// render one shell
		int it = 1;			// start at north pole.
		for (int is=0; is<ns; is++) {
			if (s[is] > r[ir]) break;		// span whole equatorial domain contained in the spherical shell.
			s2 = s[is]*s[is];
			z = sqrt(r[ir]*r[ir] - s2);
			ztop = sqrt(r[ir_bco]*r[ir_bco] - s2);
			cost = z * r_1[ir];		sint = s[is] * r_1[ir];
			if (is < is_tc) {		// inside tangent cylinder.
				H_1 = 1.0/(ztop - sqrt(r[ir_bci]*r[ir_bci]-s2));		// inverse height of column.
			} else {
				H_1 = 0.5/ztop;		// inverse height of half-column outside tangent-cylinder.
			}
			if (r[ir] == 0.0) {
				cost = 1.0;		sint = 0.0;
			}
			double r_p = (ir+rstep <= ir_bco) ? r[ir+rstep] : r[ir_bco];
			double r_m = (ir-rstep >= ir_bci) ? r[ir-rstep] : r[ir_bci];
			dz = sqrt( r_p*r_p - s2)  -  sqrt( r_m*r_m - s2 );
			if (r_m < s[is])	dz = sqrt( r_p*r_p - s2) + z;		// count twice the space below z !
			dz *= 0.5*H_1;		// normalize.
			if (s[is]==r[ir_bco]) {		// only one point contributes !
				dz = 1.0;		H_1 = 1.0;
				cost = 0.0;		sint = 1.0;
			}

			// find intersection
			while( (it < NLAT/2) && (shtns->ct[it] > cost) )  it++;
			double a = (cost - ct[it])/(ct[it-1]-ct[it]);		// angular interpolation (1D)
			double b = 1.0 - a;		// interpolation coeffs
			int nit = NLAT-1-it;	// south index

			for (int ip=0; ip<NPHI; ip++) {
				double vrn = vr[ip*NLAT +it-1]*a  + vr[ip*NLAT + it]*b;
				double vrs = vr[ip*NLAT +nit+1]*a + vr[ip*NLAT + nit]*b;
				double vtn = vt[ip*NLAT +it-1]*a  + vt[ip*NLAT + it]*b;
				double vts = vt[ip*NLAT +nit+1]*a + vt[ip*NLAT + nit]*b;
				double vpn = vp[ip*NLAT +it-1]*a  + vp[ip*NLAT + it]*b;
				double vps = vp[ip*NLAT +nit+1]*a + vp[ip*NLAT + nit]*b;
				double vsn = vrn*sint + vtn*cost;
				double vss = vrs*sint - vts*cost;
				if (is < is_tc) {		// store north and south hemisphere in successive radial points.
					vs1[is*nphi +ip]     += vsn *dz;
					vs1[(is+1)*nphi +ip] += vss *dz;
					vs2[is*nphi +ip]     += vsn*vsn *dz;
					vs2[(is+1)*nphi +ip] += vss*vss *dz;
					vp1[is*nphi +ip]     += vpn *dz;
					vp1[(is+1)*nphi +ip] += vps *dz;
					vp2[is*nphi +ip]     += vpn*vpn *dz;
					vp2[(is+1)*nphi +ip] += vps*vps *dz;
					vsvp[is*nphi +ip]    += vsn*vpn *dz;
					vsvp[(is+1)*nphi +ip] += vss*vps *dz;
				} else {
					vs1[is*nphi +ip] += (vsn+vss) *dz;
					vs2[is*nphi +ip] += (vsn*vsn + vss*vss) *dz;
					vp1[is*nphi +ip] += (vpn+vps) *dz;
					vp2[is*nphi +ip] += (vpn*vpn + vps*vps) *dz;
					vsvp[is*nphi +ip] += (vsn*vpn + vss*vps) *dz;
				}
			}
			if (is < is_tc)  is++;	// another point is consumed !
		}
	}
 	fftw_free(vr);		// free private buffers
	#ifdef _OPENMP
		#pragma omp critical
		{	// commit to shared buffer
			for (int i=0; i<5*ns*nphi; i++) buf[i] += buf2[i];
		}
		free(buf2);
	#endif

	#ifdef XS_MPI
		#pragma omp barrier
		#pragma omp master
		MPI_Reduce((i_mpi==0) ? MPI_IN_PLACE : buf, buf , 5*nphi*ns, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);		// sum all contributions.
	#endif
 	#pragma omp barrier
}



#ifdef XS_LEGACY
/// Allocate memory for a dynamic vector field (like U or B) and its pol/tor representation + non-linear term storage.
/// (fields are optional)
void alloc_DynamicField(PolTor *PT, PolTor *NL1, PolTor *NL2, PolTor *PTtmp, int istart, int iend)
{
	if (PT != NULL)		PT->alloc(istart, iend);
	if (PTtmp != NULL)	PTtmp->alloc(istart, iend);
  #ifndef XS_PURE_SPECTRAL
	if (NL1 != NULL)	NL1->alloc(istart, iend);
	if (NL2 != NULL)	NL2->alloc(istart, iend);
  #else
	if (NL1 != NULL)	NL1->alloc(istart, iend, 3);		// temporary extra component needed
	if (NL2 != NULL)	NL2->alloc(istart, iend, 3);		// temporary extra component needed
  #endif
}

void alloc_DynamicField(ScalarSH *SH, ScalarSH *NL1, ScalarSH *NL2, ScalarSH *SHtmp, int istart, int iend)
{
	if (SH != NULL)		SH->alloc(istart, iend);
	if (SHtmp != NULL)	SHtmp->alloc(istart, iend);
	if (NL1 != NULL)	NL1->alloc(istart, iend);
	if (NL2 != NULL)	NL2->alloc(istart, iend);
}

/// Isolate the non-zero modes and store them pre-computed (ready for SHT) in a minimal way.
/// \param **pssv, **pcurl point on pointers on StatSpecVect structures => allocated if needed, or NULL is returned.
/// Gives the ability to add "for free" background fields (B, ...)
/// Boundary condition should be carefuly set (usually to BC_NONE)
/// return value is the number of non-zero modes.
int PolTor::make_static(struct StatSpecVect **pssv, struct StatSpecVect **pcurl) const
{
	struct StatSpecVect *ssv, *curl;
	void *ptr;
	double dx, max;
	int i,j,lm;
	int lmcount, maxl, maxm, m;
	double *A2;		// max amplitudes for each lm-mode.
	int *lms;
	unsigned short *lis, *mis;

	lms = (int*) malloc( NLM*(sizeof(int)+2*sizeof(unsigned short)) );
	lis = (unsigned short*) (lms+NLM);		mis = lis + NLM;

	A2 = (double*) malloc( NLM*sizeof(double) );
	if (A2==0) runerr("[PolTor::make_static] allocation error 1");
	// get max amplitude
	for (lm=0; lm<NLM; lm++) {
		A2[lm] = 0.0;
		for (i=irs; i<=ire; i++) {
			dx = norm(Pol[i][lm]) + norm(Tor[i][lm]);		// |P|^2 + |T|^2
			dx *= l2[lm];
			if (dx > A2[lm]) A2[lm] = dx;
		}
	}
  #ifdef XS_MPI
	double *tmp = (double*) malloc( NLM*sizeof(double) );
	if (tmp==0) runerr("[PolTor::make_static] allocation error 2");
	MPI_Allreduce(A2, tmp, NLM, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
	free(A2);
	A2 = tmp;
  #endif
	max = 0.0;
	for (lm=0; lm<NLM; lm++) {
		if (A2[lm] > max) max = A2[lm];
	}

	maxl = 0;	maxm = 0;	m=0;
	lmcount = 0;
	// count "non-zero" modes
	max *= 1.e-20;		// no more than 1e-10 amplitude contrast allowed between modes.
	for (lm=0; lm<NLM; lm++) {
		int l = li[lm];
		if (A2[lm] > max) {		// mode is non-zero
			lms[lmcount] = lm;	// store mode
			lis[lmcount] = l;
			mis[lmcount] = m;
			lmcount++;		// count
			if (l > maxl) maxl = l;
			if (m > maxm) maxm = m;
		}
		if (l == LMAX) m += MRES;
	}
	free(A2);
	if (lmcount == 0) {
		free(lms);
		if (pssv != NULL) *pssv = NULL;
		if (pcurl != NULL) *pcurl = NULL;		/// \todo Possible memory leak !
		return lmcount;	// stop here.
	}
	if ((zero_curl) && (pcurl != NULL)) {		// field has been marked as zero curl.
		*pcurl = NULL;		/// \todo Possible memory leak !
		pcurl = NULL;
	}

	ssv = NULL;		curl = NULL;
	if (pssv != NULL) {
		if (*pssv == NULL)	*pssv = (struct StatSpecVect *) malloc( sizeof(struct StatSpecVect) );
		ssv = *pssv;		ssv->nlm = lmcount;
	}
	if (pcurl != NULL) {
		if (*pcurl == NULL)	*pcurl = (struct StatSpecVect *) malloc( sizeof(struct StatSpecVect) );
		curl = *pcurl;		curl->nlm = lmcount;
	}

	if (ssv != NULL) {
		// TODO MPI: use only local shell numbers instead of NR
		j = ((lmcount+3)>>2)*4;		// lmcount rounded up for SSE alignement.
		ptr = fftw_malloc( j*sizeof(int) + lmcount*3*NR*sizeof(cplx) + 2*lmcount*sizeof(unsigned short) );
		if (ptr==0) runerr("[PolTor::make_static] allocation error 3");
		ssv->lm = (unsigned *) ptr;
		ptr = ssv->lm + j;
		ssv->QST = (cplx *) ptr;		// should be SSE aligned.
		ptr = ssv->QST + 3*lmcount*NR;
		ssv->li = (unsigned short*) ptr;
		ssv->mi = ssv->li + lmcount;

		for (j=0; j<lmcount; j++) {
			ssv->lm[j] = lms[j];		// copy lm indices
			ssv->li[j] = lis[j];		// copy l
			ssv->mi[j] = mis[j];		// copy m
		}
		ssv->lmax = maxl;		ssv->mmax = maxm;			// save max values.

		for (i=0; i<NR; i++) {				// zero out modes
			for (j=0; j<lmcount*3; j++) ssv->QST[i*lmcount*3 +j] = 0.0;
		}

		// pre-compute and store QST values.
		for (i=irs; i<=ire; i++) {
			if ((i==ir_bci)||(i==ir_bco)) {
				for (j=0; j<lmcount; j++) {
					lm = lms[j];
					qst(i, lm, &ssv->QST[(i*lmcount+j)*3], &ssv->QST[(i*lmcount+j)*3+1], &ssv->QST[(i*lmcount+j)*3+2]);
				}
			} else {
				for (j=0; j<lmcount; j++) {
					lm = lms[j];
					ssv->QST[(i*lmcount +j)*3] = r_1[i]*l2[lm] * Pol[i][lm];
					ssv->QST[(i*lmcount +j)*3 + 1] = Wr[i].l*Pol[i-1][lm] + Wr[i].d*Pol[i][lm] + Wr[i].u*Pol[i+1][lm];
					ssv->QST[(i*lmcount +j)*3 + 2] = Tor[i][lm];
				}
			}
		}
	}
	if (curl != NULL) {
		// TODO MPI: use only local shell numbers instead of NR
		j = ((lmcount+3)>>2)*4;		// lmcount rounded up for SSE alignement.
		ptr = fftw_malloc( j*sizeof(int) + lmcount*3*NR*sizeof(cplx) + 2*lmcount*sizeof(unsigned short) );
		if (ptr==0) runerr("[PolTor::make_static] allocation error 4");
		curl->lm = (unsigned *) ptr;
		ptr = curl->lm + j;
		curl->QST = (cplx *) ptr;		// should be SSE aligned.
		ptr = curl->QST + 3*lmcount*NR;
		curl->li = (unsigned short*) ptr;
		curl->mi = curl->li + lmcount;

		for (j=0; j<lmcount; j++) {
			curl->lm[j] = lms[j];		// copy lm indices
			curl->li[j] = lis[j];		// copy l
			curl->mi[j] = mis[j];		// copy m
		}
		curl->lmax = maxl;		curl->mmax = maxm;			// save max values.

		for (i=0; i<NR; i++) {				// zero out modes
			for (j=0; j<lmcount*3; j++) curl->QST[i*lmcount*3 +j] = 0.0;
		}
		// pre-compute and store QST values.
		for (i=irs; i<=ire; i++) {
			if ((i==ir_bci)||(i==ir_bco)) {
				for (j=0; j<lmcount; j++) {
					lm = lms[j];
					curl_qst(i, lm, &curl->QST[(i*lmcount+j)*3], &curl->QST[(i*lmcount+j)*3+1], &curl->QST[(i*lmcount+j)*3+2]);
				}
			} else {
				for (j=0; j<lmcount; j++) {
					lm = lms[j];
					curl->QST[(i*lmcount +j)*3] = r_1[i]*l2[lm] * Tor[i][lm];
					curl->QST[(i*lmcount +j)*3 + 1] = Wr[i].l*Tor[i-1][lm] + Wr[i].d*Tor[i][lm] + Wr[i].u*Tor[i+1][lm];
					curl->QST[(i*lmcount +j)*3 + 2] = (r_2[i]*l2[lm] - Lr[i].d)*Pol[i][lm] - Lr[i].l*Pol[i-1][lm] - Lr[i].u*Pol[i+1][lm];
				}
			}
		}
	}
	free(lms);
	return lmcount;
}
#endif

/// Isolate the non-zero modes and store them pre-computed (ready for SHT) in a minimal way.
/// \param **sss, point on pointers on StatSpecScal structures => allocated if needed, or NULL is returned.
/// Gives the ability to add "for free" background scalar fields and gradients (T0, grad(T0))
/// Boundary condition should are treated as BC_NONE.
/// return value is the number of non-zero modes.
int ScalarSH::make_static(struct StatSpecScal **psss) const
{
	struct StatSpecScal *sss;
	void *ptr;
	double dx, max;
	int i,j,lm;
	int lmcount, maxl, maxm, m, nm0;
	double *A2;		// max amplitudes for each lm-mode.
	int *lms;
	unsigned short *lis, *mis;

	lms = (int*) malloc( NLM*(sizeof(int)+2*sizeof(unsigned short)) );
	lis = (unsigned short*) (lms+NLM);		mis = lis + NLM;

	A2 = (double*) malloc( NLM*sizeof(double) );
	if (A2==0) runerr("[ScalarSH::make_static] allocation error 1");
	// get max amplitude
	for (lm=0; lm<NLM; lm++) {
		A2[lm] = 0.0;
		for (i=irs; i<=ire; i++) {
			dx = norm(Sca[i][lm]);		// |Sca|^2
			if (dx > A2[lm]) A2[lm] = dx;
		}
	}
  #ifdef XS_MPI
	double *tmp = (double*) malloc( NLM*sizeof(double) );
	if (tmp==0) runerr("[ScalarSH::make_static] allocation error 2");
	MPI_Allreduce(A2, tmp, NLM, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
	free(A2);
	A2 = tmp;
  #endif
	max = 0.0;
	for (lm=0; lm<NLM; lm++) {
		if (A2[lm] > max) max = A2[lm];
	}

	maxl = 0;	maxm = 0;	m=0;
	lmcount = 0;	nm0 = 0;
	// count "non-zero" modes
	max *= 1.e-20;		// no more than 1e-10 amplitude contrast allowed between modes.
	for (lm=0; lm<NLM; lm++) {
		int l = li[lm];
		if (A2[lm] > max) {		// mode is non-zero
			lms[lmcount] = lm;	// store mode
			lis[lmcount] = l;
			mis[lmcount] = m;
			lmcount++;		// count
			if (l > maxl) maxl = l;
			if (m > maxm) maxm = m;
			if (m==0) nm0++;
		}
		if (l == LMAX) m += MRES;
	}
	free(A2);

	if (lmcount == 0) {
		free(lms);
		if (psss != NULL) *psss = NULL;		/// \todo Possible memory leak !
		return lmcount;	// stop here.
	}

	sss = NULL;
	if (psss != NULL) {
		if (*psss == NULL)	*psss = (struct StatSpecScal *) malloc( sizeof(struct StatSpecScal) );
		sss = *psss;		sss->nlm = lmcount;
	}

	if (sss != NULL) {
		// TODO MPI: use only local shell numbers instead of NR
		j = ((lmcount+3)>>2)*4;		// lmcount rounded up for SSE alignement.
		ptr = fftw_malloc( j*sizeof(int) + lmcount*2*NR*sizeof(cplx) + 2*lmcount*sizeof(unsigned short) );
		if (ptr==0) runerr("[ScalarSH::make_static] allocation error 3");
		sss->lm = (unsigned *) ptr;
		ptr = sss->lm + j;
		sss->TdT = (cplx *) ptr;		// should be SSE aligned.
		ptr = sss->TdT + 2*lmcount*NR;
		sss->li = (unsigned short*) ptr;
		sss->mi = sss->li + lmcount;

		for (j=0; j<lmcount; j++) {
			sss->lm[j] = lms[j];		// copy lm indices
			sss->li[j] = lis[j];		// copy l
			sss->mi[j] = mis[j];		// copy m
		}
		sss->lmax = maxl;		sss->mmax = maxm;			// save max values.

		for (i=0; i<NR; i++) {				// zero out modes
			for (j=0; j<lmcount*2; j++) sss->TdT[i*lmcount*2 +j] = 0.0;
		}

		// pre-compute and store T and dT/dr values.
		for (i=irs; i<=ire; i++) {
			if ((i==ir_bci)||(i==ir_bco)) {
				int ii=i+1;
				if (i==ir_bco) ii = i-1;
				dx = 1.0/(r[ii]-r[i]);
				for (j=0; j<lmcount; j++) {
					lm = lms[j];
					sss->TdT[(i*lmcount +j)*2] = Sca[i][lm];
					if ((r[i] == 0.0) && (lis[j] != 1)) {
						sss->TdT[(i*lmcount +j)*2 + 1] = 0.0;
					} else {
						sss->TdT[(i*lmcount +j)*2 + 1] = (Sca[ii][lm] - Sca[i][lm]) * dx;		// WARNING: less acurate (1st order)
					}
				}
			} else {
				for (j=0; j<lmcount; j++) {
					lm = lms[j];
					sss->TdT[(i*lmcount +j)*2] = Sca[i][lm];
					sss->TdT[(i*lmcount +j)*2 + 1] = Gr[i].l * Sca[i-1][lm] + Gr[i].d * Sca[i][lm] + Gr[i].u * Sca[i+1][lm];
				}
			}
		}
	}
	free(lms);
	return lmcount;
}

void free_StatSpecVect(struct StatSpecVect *ss) {
	if (ss) fftw_free(ss->lm);
}

void free_StatSpecScal(struct StatSpecScal *ss) {
	if (ss) fftw_free(ss->lm);
}


/// Allocate a constant scalar field like mask or constant ... (low precision, 64 bit aligned)
/// store nf floats per latitude.
void alloc_float(float ***msk, int istart, int iend, int nf)
{
	void *ptr;
	int ir, nspat;

	nspat = ((NLAT +1)>>1)*2;		// even for alignement
	nspat *= nf;		// store nf floats per location.
	ir = ((NR+1)>>1)*2;		// even for alignement
	ptr = fftw_malloc( ir*sizeof(float *) + (iend-istart+1)*nspat*sizeof(float) );
	if (ptr==0) runerr("[alloc_float] allocation error");
	*msk = (float **) ptr;
	ptr = (*msk + ir);
	(*msk)[istart] = (float *) ptr;
	for (ir = istart+1; ir <= iend; ir++)
		(*msk)[ir] = (*msk)[ir-1] + nspat;
	for (ir = 0; ir < istart; ir++) (*msk)[ir] = NULL;
	for (ir = iend+1; ir<NR; ir++) (*msk)[ir] = NULL;
}



#ifdef XS_LINEAR
/// Class holding a spatial vector field, with specialization for axisymmetric fields.
class SpatVect {
  public:
	int irs, ire;			///< radial boundaries.

  private:
	int poltor;		///< 0: no component. 1=pol (vr+vt), 2=tor (vp), 3=pol+tor (vr+vt+vp)
	size_t nelem;	///< number of elements in a shell. Can be NLAT for axisymmetric fields, or NLAT*NPHI for general fields.
	double *vr;
	double *vt;
	double *vp;
	double *v2_max;

  public:
	SpatVect() {
		poltor = 0;
		vr = 0;		vt = 0;		vp = 0;		v2_max = 0;
	}
	~SpatVect() {
		if (vr) fftw_free(vr);
		if (vt) fftw_free(vt);
		if (vp) fftw_free(vp);
		if (v2_max) fftw_free(v2_max);
	}

	int from_SH(const PolTor& Vlm, int curl=0);		///< compute spatial field from Vlm.
	int from_SH(const ScalarSH& Tlm);				///< compute spatial field from gradient of ScalarSH

	int V0_cross_w(int ir, double* xr, double* xt, double *xp, double *wr, double *wt, double *wp, int add = 0) const;
	int w_cross_V0(int ir, double* xr, double* xt, double *xp, double *wr, double *wt, double *wp, int add = 0) const;
	int V0_dot_w(int ir, double* dot, double *wr, double *wt, double *wp, int add = 0) const;
	int V0_times_s(int ir, double* xr, double* xt, double *xp, double *s, int add = 0) const;
	void absmax2(int ir, double& vr2_max, double& vh2_max) const;
	void absmax2(int ir, double& v2max) const;
	double absmax2() const;

	double* r(int ir) {
		double* p = vr;
		if (p) p += nelem*(ir-irs);
		return p;
	}
	double* t(int ir) {
		double* p = vt;
		if (p) p += nelem*(ir-irs);
		return p;
	}
	double* p(int ir) {
		double* p = vp;
		if (p) p += nelem*(ir-irs);
		return p;
	}
};

int SpatVect::from_SH(const PolTor& Vlm, int curl)
{
	double Epol0, Etor0;
	size_t mem_sze;
	int nr = Vlm.ire - Vlm.irs + 1;

	irs = Vlm.irs;		ire = Vlm.ire;
	vr = 0;			vt = 0;			vp = 0;
	poltor = 0;
	if ((curl) && (Vlm.zero_curl)) return 0;

	if (NLAT % VSIZE) runerr("[SpatVect::from_SH] NLAT must be a multiple of vector size.");

	SpectralDiags sd(LMAX,MMAX);
	Vlm.energy(sd);
	#ifdef XS_MPI
		sd.reduce_mpi();
	#endif
	if (sd.energy() == 0.0) runerr("empty field");
	if (curl==0) {
		Epol0 = sd.Esplit[Ez_es]+sd.Esplit[Ez_ea];
		Etor0 = sd.Esplit[N_Esplit+Ez_es]+sd.Esplit[N_Esplit+Ez_ea];
	} else {
		Etor0 = sd.Esplit[Ez_es]+sd.Esplit[Ez_ea];
		Epol0 = sd.Esplit[N_Esplit+Ez_es]+sd.Esplit[N_Esplit+Ez_ea];
	}
	if (sd.energy_nz() > 0.0) {		// non-axisymmetric field.
		nelem = NLAT*NPHI;
		PRINTF0("  non-axisymmetric field\n");
		poltor = 3;		// all components.
	} else {		// axisymmetric field.
		nelem = NLAT;
		PRINTF0("  axisymmetric field\n");
		if (Epol0 > 0.0) poltor |= 1;
		if (Etor0 > 0.0) poltor |= 2;
	}

	mem_sze = nelem*nr*sizeof(double);
	if (poltor & 1) {
		vr = (double*) fftw_malloc(mem_sze);
		vt = (double*) fftw_malloc(mem_sze);
		if ((vr==0) || (vt==0)) runerr("[SpatVect::from_SH] allocation error 1");
	}
	if (poltor & 2) {
		vp = (double*) fftw_malloc(mem_sze);
		if (vp==0) runerr("[SpatVect::from_SH] allocation error 2");
	}

	if (nelem == NLAT) {		// axisymmetric case
		#if XS_OMP == 1
		#pragma omp parallel for
		#endif
		for (int ir=irs; ir<=ire; ir++) {
			cplx qlm[LMAX+1] SSE;		// alloc private variables on stack
			cplx slm[LMAX+1] SSE;
			cplx tlm[LMAX+1] SSE;
			cplx spat1[NLAT] SSE;
			cplx spat2[NLAT] SSE;
			if (curl==0) {
				Vlm.RadSph(ir, qlm, slm, 0, LMAX);		// m=0
				for (int l=0; l<=LMAX; l++) tlm[l] = Vlm.Tor[ir][l];
			} else {
				Vlm.curl_QST(ir, qlm, slm, tlm, 0, LMAX);		// m=0
			}
			if (poltor & 1) {
				SHsph_to_spat_ml(shtns, 0, slm, spat1, spat2, LMAX);
				SH_to_spat_ml(shtns, 0, qlm, spat2, LMAX);
				for (size_t it=0; it<nelem; it++) {
					vr[nelem*(ir-irs)+it] = real(spat2[it]);
					vt[nelem*(ir-irs)+it] = real(spat1[it]);
				}
			}
			if (poltor & 2) {
				SHtor_to_spat_ml(shtns, 0, tlm, spat1, spat2, LMAX);
				for (size_t it=0; it<nelem; it++) {
					vp[nelem*(ir-irs)+it] = real(spat2[it]);
				}
			}
		}
	} else {					// non-axisymmetric case
		#if XS_OMP == 1
		#pragma omp parallel for
		#endif
		for (int ir=irs; ir<=ire; ir++) {
			cplx* qlm = (cplx*) fftw_malloc(sizeof(cplx) * 3*NLM);		// alloc private large buffers
			cplx* slm = qlm + NLM;		cplx* tlm = qlm + 2*NLM;
			double* vrr = (double*) fftw_malloc(sizeof(double) * 3*shtns->nspat);	// alloc private spatial buffers (with additional space for fft)
			double* vtt = vrr + shtns->nspat;		double* vpp = vrr + 2*shtns->nspat;
			if ((qlm==0)||(vrr==0)) runerr("[SpatVect::from_SH] allocation error 3");
			if (curl==0) {
				Vlm.RadSph(ir, qlm, slm, 0, NLM-1);		// m=0
				for (int l=0; l<NLM; l++) tlm[l] = Vlm.Tor[ir][l];
			} else {
				Vlm.curl_QST(ir, qlm, slm, tlm, 0, NLM-1);		// m=0
			}
			SHV3_SPAT(qlm, slm, tlm, vrr, vtt, vpp);
			memcpy(vr+nelem*(ir-irs), vrr, sizeof(double)*nelem);	// copy to tight shells
			memcpy(vt+nelem*(ir-irs), vtt, sizeof(double)*nelem);
			memcpy(vp+nelem*(ir-irs), vpp, sizeof(double)*nelem);
			fftw_free(vrr);		fftw_free(qlm);
		}
	}

	// Compute maximum vectors for CFL
	v2_max = (double*) fftw_malloc(2*nr*sizeof(double));
	for (int ir=irs; ir<=ire; ir++) {
		double vr2_max = 0.0;
		double vh2_max = 0.0;
		for (int it=0; it<nelem; it++) {
			double vri = 0.0;		double vti = 0.0;		double vpi = 0.0;
			if (poltor & 1) {
				vri = vr[nelem*(ir-irs)+it];
				vti = vt[nelem*(ir-irs)+it];
			}
			if (poltor & 2) {
				vpi = vp[nelem*(ir-irs)+it];
			}
			double vr2 = vri*vri;
			double vh2 = vti*vti + vpi*vpi;
			if (vr2 > vr2_max) vr2_max = vr2;
			if (vh2 > vh2_max) vh2_max = vh2;
		}
		v2_max[2*(ir-irs)] = vr2_max;
		v2_max[2*(ir-irs)+1] = vh2_max;
	}

	return poltor;
}

int SpatVect::from_SH(const ScalarSH& Tlm)
{
	size_t mem_sze;
	int nr = Tlm.ire - Tlm.irs + 1;

	irs = Tlm.irs;		ire = Tlm.ire;
	vr = 0;			vt = 0;			vp = 0;
	poltor = 0;

	if (NLAT % VSIZE) runerr("[SpatVect::from_SH] NLAT must be a multiple of vector size.");

	SpectralDiags sd(LMAX,MMAX);
	Tlm.energy(sd);
	#ifdef XS_MPI
		sd.reduce_mpi();
	#endif
	if (sd.energy() == 0.0) runerr("empty field");
	if (sd.energy_nz() > 0.0) {		// non-axisymmetric field.
		nelem = NLAT*NPHI;
		PRINTF0("  non-axisymmetric field\n");
		poltor = 3;		// all components.		
	} else {		// axisymmetric field
		nelem = NLAT;
		PRINTF0("  axisymmetric field\n");
		poltor = 1;		// only r and theta components		
	}

	mem_sze = nelem*nr*sizeof(double);
	if (poltor & 1) {
		vr = (double*) fftw_malloc(mem_sze);
		vt = (double*) fftw_malloc(mem_sze);
		if ((vr==0) || (vt==0)) runerr("[SpatVect::from_SH] allocation error 1");
	}
	if (poltor & 2) {
		vp = (double*) fftw_malloc(mem_sze);
		if (vp==0) runerr("[SpatVect::from_SH] allocation error 2");
	}

	if (nelem == NLAT) {		// axisymmetric case
		#if XS_OMP == 1
		#pragma omp parallel for
		#endif
		for (int ir=irs; ir<=ire; ir++) {
			cplx qlm[LMAX+1] SSE;		// alloc private variables on stack
			cplx slm[LMAX+1] SSE;
			cplx spat1[NLAT] SSE;
			cplx spat2[NLAT] SSE;
			Tlm.Gradr(ir, qlm, slm, 0, LMAX);		// m=0;
			if (poltor & 1) {
				SHsph_to_spat_ml(shtns, 0, slm, spat1, spat2, LMAX);
				SH_to_spat_ml(shtns, 0, qlm, spat2, LMAX);
				for (size_t it=0; it<nelem; it++) {
					vr[nelem*(ir-irs)+it] = real(spat2[it]);
					vt[nelem*(ir-irs)+it] = real(spat1[it]);
				}
			}
		}
	} else {					// non-axisymmetric case
		#if XS_OMP == 1
		#pragma omp parallel for
		#endif
		for (int ir=irs; ir<=ire; ir++) {
			cplx* qlm = (cplx*) fftw_malloc(sizeof(cplx)*2*NLM);		// alloc private large buffers
			cplx* slm = qlm + NLM;
			double* vrr = (double*) fftw_malloc(sizeof(double) * 3*shtns->nspat);	// alloc private spatial buffers (with additional space for fft)
			double* vtt = vrr + shtns->nspat;		double* vpp = vrr + 2*shtns->nspat;
			if ((qlm==0)||(vrr==0)) runerr("[SpatVect::from_SH] allocation error 3");
			Tlm.Gradr(ir, qlm, slm, 0, NLM-1);
			SH_SPAT(qlm, vrr);
			SHS_SPAT(slm, vtt, vpp);
			memcpy(vr+nelem*(ir-irs), vrr, sizeof(double)*nelem);	// copy to tight shells
			memcpy(vt+nelem*(ir-irs), vtt, sizeof(double)*nelem);
			memcpy(vp+nelem*(ir-irs), vpp, sizeof(double)*nelem);
			fftw_free(vrr);		fftw_free(qlm);
		}
	}

	// Compute maximum vectors for CFL
	v2_max = (double*) fftw_malloc(2*nr*sizeof(double));
	for (int ir=irs; ir<=ire; ir++) {
		double vr2_max = 0.0;
		double vh2_max = 0.0;
		for (int it=0; it<nelem; it++) {
			double vri = 0.0;		double vti = 0.0;		double vpi = 0.0;
			if (poltor & 1) {
				vri = vr[nelem*(ir-irs)+it];
				vti = vt[nelem*(ir-irs)+it];
			}
			if (poltor & 2) {
				vpi = vp[nelem*(ir-irs)+it];
			}
			double vr2 = vri*vri;
			double vh2 = vti*vti + vpi*vpi;
			if (vr2 > vr2_max) vr2_max = vr2;
			if (vh2 > vh2_max) vh2_max = vh2;
		}
		v2_max[2*(ir-irs)] = vr2_max;
		v2_max[2*(ir-irs)+1] = vh2_max;
	}
	return poltor;
}


void SpatVect::absmax2(int ir, double& vr2max, double& vh2max) const
{
	vr2max = v2_max[2*(ir-irs)];
	vh2max = v2_max[2*(ir-irs)+1];
}

void SpatVect::absmax2(int ir, double& v2max) const
{
	double v2r = v2_max[2*(ir-irs)];
	double v2h = v2_max[2*(ir-irs)+1];
	if (v2h > v2r) v2r = v2h;
	v2max = v2r;
}

double SpatVect::absmax2() const
{
	double v2 = 0.0;
	for (int ir=irs; ir<=ire; ir++) {
		double v2r = v2_max[2*(ir-irs)] + v2_max[2*(ir-irs)+1];
		if (v2r > v2) v2 = v2r;
	}
	return v2;
}

int SpatVect::V0_cross_w(int ir, double* xr, double* xt, double *xp, double *wr, double *wt, double *wp, const int add) const
{
	const size_t vnelem = nelem/VSIZE;
	const size_t vnspat = NPHI*(NLAT/VSIZE);
	double* Vr = vr + nelem*(ir-irs);
	double* Vt = vt + nelem*(ir-irs);
	double* Vp = vp + nelem*(ir-irs);

	if ((ir < irs) || (ir > ire)) return 0;
	if ((poltor & 3) == 3) {	// pol+tor
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd vvt = vread(Vt,it);		rnd vwt = vread(wt,k);
			rnd vvp = vread(Vp,it);		rnd vwp = vread(wp,k);
			rnd rr = vvt*vwp - vvp*vwt;	// AxB
			rnd vvr = vread(Vr,it);		rnd vwr = vread(wr,k);
			rnd rt = vvp*vwr - vvr*vwp;
			rnd rp = vvr*vwt - vvt*vwr;
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(xr,k, rr);	vmemadd(xt,k, rt);	vmemadd(xp,k, rp);
			} else {
				vstore(xr,k, rr);	vstore(xt,k, rt);	vstore(xp,k, rp);
			}
		}
		return 1;
	} else if (poltor & 2) {	// tor only
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd vvp = vread(Vp,it);
			rnd rr = - vvp * vread(wt,k);	// AxB
			rnd rt =   vvp * vread(wr,k);
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(xr,k, rr);		vmemadd(xt,k, rt);
			} else {
				vstore(xr,k, rr);	vstore(xt,k, rt);
			}
		}
		if (add==0) memset(xp, 0, sizeof(double)*NLAT*NPHI);
		return 1;
	} else if (poltor & 1) {		// pol only
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd vvt = vread(Vt,it);		rnd vwt = vread(wt,k);
										rnd vwp = vread(wp,k);
			rnd rr = vvt*vwp;	// AxB
			rnd vvr = vread(Vr,it);		rnd vwr = vread(wr,k);
			rnd rt = - vvr*vwp;
			rnd rp = vvr*vwt - vvt*vwr;
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(xr,k, rr);		vmemadd(xt,k, rt);		vmemadd(xp,k, rp);
			} else {
				vstore(xr,k, rr);	vstore(xt,k, rt);	vstore(xp,k, rp);
			}
		}
		return 1;
	}
	return 0;
}

int SpatVect::w_cross_V0(int ir, double* xr, double* xt, double *xp, double *wr, double *wt, double *wp, const int add) const
{
	const size_t vnelem = nelem/VSIZE;
	const size_t vnspat = NPHI*(NLAT/VSIZE);
	double* Vr = vr + nelem*(ir-irs);
	double* Vt = vt + nelem*(ir-irs);
	double* Vp = vp + nelem*(ir-irs);

	if ((ir < irs) || (ir > ire)) return 0;
	if ((poltor & 3) == 3) {	// pol+tor
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd vvt = vread(Vt,it);		rnd vwt = vread(wt,k);
			rnd vvp = vread(Vp,it);		rnd vwp = vread(wp,k);
			rnd rr = vvp*vwt - vvt*vwp;	// BxA
			rnd vvr = vread(Vr,it);		rnd vwr = vread(wr,k);
			rnd rt = vvr*vwp - vvp*vwr;
			rnd rp = vvt*vwr - vvr*vwt;
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(xr,k, rr);	vmemadd(xt,k, rt);	vmemadd(xp,k, rp);
			} else {
				vstore(xr,k, rr);	vstore(xt,k, rt);	vstore(xp,k, rp);
			}
		}
		return 1;
	} else if (poltor & 2) {	// tor only
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd vvp = vread(Vp,it);
			rnd rr =   vvp * vread(wt,k);	// BxA
			rnd rt = - vvp * vread(wr,k);
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(xr,k, rr);	vmemadd(xt,k, rt);
			} else {
				vstore(xr,k, rr);	vstore(xt,k, rt);
			}
		}
		if (add==0) memset(xp, 0, sizeof(double)*NLAT*NPHI);
		return 1;
	} else if (poltor & 1) {		// pol only
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd vvt = vread(Vt,it);		rnd vwt = vread(wt,k);
										rnd vwp = vread(wp,k);
			rnd rr = - vvt*vwp;	// BxA
			rnd vvr = vread(Vr,it);		rnd vwr = vread(wr,k);
			rnd rt =   vvr*vwp;
			rnd rp = vvt*vwr - vvr*vwt;
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(xr,k, rr);	vmemadd(xt,k, rt);	vmemadd(xp,k, rp);
			} else {
				vstore(xr,k, rr);	vstore(xt,k, rt);	vstore(xp,k, rp);
			}
		}
		return 1;
	}
	return 0;
}


int SpatVect::V0_dot_w(int ir, double* dot, double *wr, double *wt, double *wp, int add) const
{
	const size_t vnelem = nelem/VSIZE;
	const size_t vnspat = NPHI*(NLAT/VSIZE);
	double* Vr = vr + nelem*(ir-irs);
	double* Vt = vt + nelem*(ir-irs);
	double* Vp = vp + nelem*(ir-irs);

	if ((poltor & 3) == 3) {	// pol+tor
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd vvr = vread(Vr,it);		rnd vwr = vread(wr,k);
			rnd vvt = vread(Vt,it);		rnd vwt = vread(wt,k);
			rnd vvp = vread(Vp,it);		rnd vwp = vread(wp,k);
			rnd d = vvr*vwr + vvt*vwt + vvp*vwp;
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(dot,k, d);
			} else {
				vstore(dot,k, d);
			}
		}
		return 1;
	} else if (poltor & 2) {	// tor only
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd vvp = vread(Vp,it);		rnd vwp = vread(wp,k);
			rnd d = vvp*vwp;
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(dot,k, d);
			} else {
				vstore(dot,k, d);
			}
		}
		return 1;
	} else if (poltor & 1) {		// pol only
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd vvr = vread(Vr,it);		rnd vwr = vread(wr,k);
			rnd vvt = vread(Vt,it);		rnd vwt = vread(wt,k);
			rnd d = vvr*vwr + vvt*vwt;
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(dot,k, d);
			} else {
				vstore(dot,k, d);
			}
		}
		return 1;
	}
	return 0;
}

int SpatVect::V0_times_s(int ir, double* xr, double* xt, double *xp, double *s, const int add) const
{
	const size_t vnelem = nelem/VSIZE;
	const size_t vnspat = NPHI*(NLAT/VSIZE);
	double* Vr = vr + nelem*(ir-irs);
	double* Vt = vt + nelem*(ir-irs);
	double* Vp = vp + nelem*(ir-irs);

	if ((ir < irs) || (ir > ire)) return 0;
	if ((poltor & 3) == 3) {	// pol+tor
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd sk = vread(s, k);
			rnd rr = vread(Vr,it) * sk;
			rnd rt = vread(Vt,it) * sk;
			rnd rp = vread(Vp,it) * sk;
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(xr,k, rr);	vmemadd(xt,k, rt);	vmemadd(xp,k, rp);
			} else {
				vstore(xr,k, rr);	vstore(xt,k, rt);	vstore(xp,k, rp);
			}
		}
		return 1;
	} else if (poltor & 2) {	// tor only
		for (size_t k=0, it=0; k<vnspat; k++) {			
			rnd rp = vread(Vp,it) * vread(s,k);
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(xp,k, rp);
			} else {
				vstore(xp,k, rp);
			}
		}
		if (add==0) {
			memset(xr, 0, sizeof(double)*NLAT*NPHI);
			memset(xt, 0, sizeof(double)*NLAT*NPHI);
		}
		return 1;
	} else if (poltor & 1) {		// pol only
		for (size_t k=0, it=0; k<vnspat; k++) {
			rnd sk = vread(s, k);
			rnd rr = vread(Vr,it) * sk;
			rnd rt = vread(Vt,it) * sk;
			if (++it >= vnelem) it=0;
			if (add) {
				vmemadd(xr,k, rr);		vmemadd(xt,k, rt);
			} else {
				vstore(xr,k, rr);	vstore(xt,k, rt);
			}
		}
		if (add==0) memset(xp, 0, sizeof(double)*NLAT*NPHI);
		return 1;
	}
	return 0;
}

#endif

