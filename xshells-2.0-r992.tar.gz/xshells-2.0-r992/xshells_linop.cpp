/*
 * Copyright (c) 2010-2017 Centre National de la Recherche Scientifique.
 * written by Nathanael Schaeffer (CNRS, ISTerre, Grenoble, France).
 * 
 * nathanael.schaeffer@univ-grenoble-alpes.fr
 * 
 * This software is governed by the CeCILL license under French law and
 * abiding by the rules of distribution of free software. You can use,
 * modify and/or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info".
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */

/// \file xshells_linop.cpp
/// Linear Operators: 3 banded matrices, 5-banded matrices (real), applied to complex vectors.

/* TODO: 
 * No (partial) pivoting is necessary for a strictly column diagonally dominant matrix when performing Gaussian elimination (LU factorization).
 *  	source: https://en.wikipedia.org/wiki/Diagonally_dominant_matrix#Applications_and_properties
 * for tridiagonal matrices, use	 https://en.wikipedia.org/wiki/Tridiagonal_matrix_algorithm
*/

#ifdef __INTEL_COMPILER
    #if __INTEL_COMPILER >= 1700
        #error "intel compiler 17+ are buggy and break xshells. Please use earlier versions (icpc 15 to 16) or g++."
    #endif
#endif

//enum op_bc { none, dr_zero, d2r_zero, free_slip };

class LinOpR {
	double *data;		///< store the matrix elements
  protected:
	unsigned nelem;

    void _alloc(int ir0, int ir1, int _nelem);
    void _free();

  public:
	int ir_bci, ir_bco;		///< global boundaries
	int irs, ire;			///< local boundaries (MPI)
    LinOpR() : irs(0), ire(-1), ir_bci(0), ir_bco(-1), data(0), nelem(0) {}
    ~LinOpR() { _free(); }
    inline double* Mr(int ir) const {
		//if ((ir < ir_bci) || (ir > ir_bco)) printf("out of bound access\n");
		return data + nelem*ir;		// data pointer already shifted.
	}
//    inline double* operator[](int ir) const { return Mr(ir); }
    void copy_r(int ir, const LinOpR& L);
    void scale(int ir, const double s);
    void zero(int ir);
};

template <class T>
class _LinOp3l : public LinOpR {		// Base class using CRTP, for static polymorphism.
  protected:
	int lmax;

  public:
	inline void set_lo(int ir, double v) { static_cast<T*>(this)->set_lo(ir, v); }
	inline void set_up(int ir, double v) { static_cast<T*>(this)->set_up(ir, v); }
	inline void set_di(int ir, int l, double v)  { static_cast<T*>(this)->set_di(ir,l, v); }
	inline double coeff(int ir, int l, const int dir) {	static_cast<T*>(this)->coeff(ir,l, dir); }
	int bandwidth() const { return 1; }

	void set_Laplace(int ir, const double s=1.0);
	void set_Laplace_bc(int ir, double a0, double a1, const double s=1.0);
	void set_Laplace(int ir, const double* d1r, const double* d2r, const double s=1.0);
#ifdef XS_MPI
	void solve_finish(Spectral& X, int icomp, int tag, MPI_Request **req, int lms_block, int nlm_block) const;
#endif
};

/// tri-diagonal operator, with only the diagonal dependend on l.
class LinOp3ld : public _LinOp3l<LinOp3ld> {
	void _precalc_solve(int i0, int i1, int l0, int l1);

 public:
    void alloc(int ir0, int ir1, int _lmax);
	void apply(cplx**__restrict x, cplx**__restrict y, int lmstart, int lmend, const double s=0.0);

	inline double lo(int ir) const { return Mr(ir)[0]; }
	inline double up(int ir) const { return Mr(ir)[1]; }
	inline double di(int ir, int l) const { return Mr(ir)[2+l]; }

	inline double coeff(int ir, int l, const int dir) {
		if (dir==0) return Mr(ir)[2+l];
		return Mr(ir)[(dir+1)/2];
	}

	inline void set_lo(int ir, double v) { Mr(ir)[0] = v; }
	inline void set_up(int ir, double v) { Mr(ir)[1] = v; }
	inline void set_di(int ir, int l, double v) { Mr(ir)[2+l] = v; }
	
	inline void add_lo(int ir, double v) { Mr(ir)[0] += v; }
	inline void add_up(int ir, double v) { Mr(ir)[1] += v; }
	inline void add_di(int ir, int l, double v) { Mr(ir)[2+l] += v; }

	void precalc_solve();
	void set_op(const double a, const double b, const LinOp3ld& L);		///< set operator to (a + b*L)
	void scale(int ir, const double* sl);		///< operation not supported, use LinOp3l instead !!
#ifndef XS_MPI
	void solve(cplx** x, int lms, int lme) const;
#else
	void solve_up(cplx** x, int lms, int lme, int tag, MPI_Request **req, int lms_block, int nlm_block) const;
	void solve_dn(cplx** x, int lms, int lme, int tag, MPI_Request **req, int lms_block, int nlm_block) const;
#endif
};

/// tri-diagonal operator
class LinOp3l : public _LinOp3l<LinOp3l> {
  protected:
	inline double* M(int ir, int l) const { return LinOpR::Mr(ir) + 3*l + 1; }
	inline double* operator()(int ir, int l) const { return M(ir,l); }

  public:
	void alloc(int ir0, int ir1, int _lmax);
	void apply(cplx**__restrict x, cplx**__restrict y, int lmstart, int lmend, const double s=0.0);

	inline double coeff(int ir, int l, const int dir) { return Mr(ir)[3*l+1+dir]; }

	inline void set_lo(int ir, int l, double v) { Mr(ir)[3*l] = v; }
	inline void set_di(int ir, int l, double v) { Mr(ir)[3*l+1] = v; }
	inline void set_up(int ir, int l, double v) { Mr(ir)[3*l+2] = v; }
	
	inline void add_lo(int ir, int l, double v) { Mr(ir)[3*l] += v; }
	inline void add_di(int ir, int l, double v) { Mr(ir)[3*l+1] += v; }
	inline void add_up(int ir, int l, double v) { Mr(ir)[3*l+2] += v; }

	inline void set_lo(int ir, double v) { for (int l=0; l<=lmax; l++) set_lo(ir, l, v); }	///< broadcast on all l
	inline void set_up(int ir, double v) { for (int l=0; l<=lmax; l++) set_up(ir, l, v); }	///< broadcast on all l
	inline void add_lo(int ir, double v) { for (int l=0; l<=lmax; l++) add_lo(ir, l, v); }	///< broadcast on all l
	inline void add_up(int ir, double v) { for (int l=0; l<=lmax; l++) add_up(ir, l, v); }	///< broadcast on all l

    void scale(int ir, const double* s);		///< scale a line by a value function of l (array from 0 to lmax)
	void set_op(const double a, const double b, const LinOp3l& L);		///< set operator to (a + b*L)
	void set_op(const double a, const double b, const LinOp3ld& L);		///< set operator to (a + b*L)
};

/// 5-diagonal operator
class LinOp5l : public LinOpR {
  protected:
	int lmax;

//	void _set_BiLaplace(int ir, double* d1r, double* d2r, double* d3r, double* d4r, const double s1, const double s2);

  public:
	void alloc(int ir0, int ir1, int _lmax);
	void apply(cplx**__restrict x, cplx**__restrict y, int lmstart, int lmend, const double s=0.0);
	int bandwidth() const { return 2; }

	inline double coeff(int ir, int l, const int dir) { return Mr(ir)[5*l+2+dir]; }

	inline double* M(int ir, int l) const { return LinOpR::Mr(ir) + 5*l + 2; }
	inline double* operator()(int ir, int l) const { return M(ir,l); }

	void set_op(double a,  double b, const LinOp5l& L);							///< set operator to (a + b*L)
	void set_op(double a,  const LinOp3ld& La, double b, const LinOp5l& Lb);	///< set operator to (a*La + b*Lb)
	void set_op(double a,  const LinOp3l& La, double b, const LinOp5l& Lb);		///< set operator to (a*La + b*Lb)
	void set_op(double a,  const LinOp5l& La, double b, const LinOp5l& Lb);		///< set operator to (a*La + b*Lb)

	void set_BiLaplace4(int ir, const double* d1r, const double* d2r, const double* d3r, const double* d4r, const double s1 = 0.0, const double s2 = 1.0);
	void set_Laplace4(int ir, const double* d1r, const double* d2r, const double s = 1.0);
	void set_Laplace2(int ir, const double* Lr, const double s = 1.0);
	void set_BiLaplace2(int ir, const double* Lrl, const double* Lrd, const double* Lru, const double s = 1.0);

    void scale(int ir, const double* s);		///< scale a line by a value function of l (array from 0 to lmax)
};

/// Stores L and U factors for efficient memory access
class LUstorage {
  protected:
	double *L;		// lower diagonal
	double *U;		// upper diagonal
	int nelem_L;
	int nelem_U;

	void alloc(int irs, int ire, int lmax, int b) {
		nelem_L = (lmax+1)*(b+1);
		nelem_U = (lmax+1)*b;
		L = (double*) malloc( sizeof(double) * (ire-irs+1)*(nelem_L + nelem_U) );		// alloc storage for local shells only.
		U = L + (ire-irs+1)*nelem_L;
	}
  public:
	~LUstorage() {  if (L) free(L);  }
};

class LU3l : public LinOp3l, public LUstorage {
	void _precalc_solve(int i0, int i1, int l0, int l1);

  public:
	void alloc(int ir0, int ir1, int _lmax);

	void precalc_solve();						///< precompute solve
#ifndef XS_MPI
	void solve(cplx** x, int lms, int lme) const;
#else
	void solve_up(cplx** x, int lms, int lme, int tag, MPI_Request **req, int lms_block, int nlm_block) const;
	void solve_dn(cplx** x, int lms, int lme, int tag, MPI_Request **req, int lms_block, int nlm_block) const;
#endif
};

class LU5l : public LinOp5l, public LUstorage {
  public:
	void alloc(int ir0, int ir1, int _lmax);

	void precalc_solve();						///< precompute solve
#ifndef XS_MPI
	void solve(cplx** x, int lms, int lme) const;
#else
	void solve_up(cplx** x, int lms, int lme, int tag, MPI_Request **req, int lms_block, int nlm_block) const;
	void solve_dn(cplx** x, int lms, int lme, int tag, MPI_Request **req, int lms_block, int nlm_block) const;
	void solve_finish(Spectral& X, int icomp, int tag, MPI_Request **req, int lms_block, int nlm_block) const;
#endif
};

void LinOpR::_alloc(int ir0, int ir1, int _nelem) {
	_free();		// allow silently reallocating.
	nelem = _nelem;
	ir_bci = ir0;	// store global boundaries
	ir_bco = ir1;
	mpi_interval(ir0, ir1);		// reduce to local boundaries
	irs = ir0;
	ire = ir1;
	int nr = ir_bco - ir_bci + 1;		// allocation of full matrices on each MPI process
	data = (double *) malloc( nelem * nr * sizeof(double) );
	if (data==0) runerr("[LinOpR] allocation error");
	data -= ir_bci*nelem;		// shift pointer for faster access.
}

void LinOpR::_free() {
	double* d = data + ir_bci*nelem;
	if (d) free(d);
}

/// copy one radius from operator L
void LinOpR::copy_r(int ir, const LinOpR& L) {
  #ifdef XS_DEBUG
	if (L.nelem != nelem) runerr("[LinOpR::copy_r] operators mismatch");
  #endif
	double* Mi = Mr(ir);
	double* Li = L.Mr(ir);
	for (unsigned l=0; l<nelem; l++) 	Mi[l] = Li[l];
}


void LinOp3ld::alloc(int ir0, int ir1, int _lmax) {
	lmax = _lmax;
	_alloc(ir0, ir1, lmax+3);
}

void LinOp3l::alloc(int ir0, int ir1, int _lmax) {
	lmax = _lmax;
	_alloc(ir0, ir1, 3*(lmax+1));
}

void LinOp5l::alloc(int ir0, int ir1, int _lmax) {
	lmax = _lmax;
	_alloc(ir0, ir1, 5*(lmax+1));
}

void LU3l::alloc(int ir0, int ir1, int _lmax)
{
	LinOp3l::alloc(ir0, ir1, _lmax);
	LUstorage::alloc(irs, ire, lmax, bandwidth());
}

void LU5l::alloc(int ir0, int ir1, int _lmax)
{
	LinOp5l::alloc(ir0, ir1, _lmax);
	LUstorage::alloc(irs, ire, lmax, bandwidth());
}

/// scale a line (radius) of the matrix by s
void LinOpR::scale(int ir, const double s) {
	if (s != 1.0) {
		double* Mi = Mr(ir);
		for (unsigned l=0; l<nelem; l++)  Mi[l] *= s;
	}
}

void LinOpR::zero(int ir) {
	for (unsigned l=0; l<nelem; l++)  Mr(ir)[l] = 0.0;
}

void LinOp3l::scale(int ir, const double* s) {
	double* Md = Mr(ir);
	for (int l=0; l<=lmax; l++) {
		for (int k=0; k<3; k++)  Md[3*l+k] *= s[l];
	}
}

void LinOp3ld::scale(int ir, const double* s) {
	runerr("[LinOp3ld::scale] scaling as a function of l not supported, use LinOp3l instead.");
}

void LinOp5l::scale(int ir, const double* s) {
	double* Md = Mr(ir);
	for (int l=0; l<=lmax; l++) {
		for (int k=0; k<5; k++)  Md[5*l+k] *= s[l];
	}
}

/// compute y = (L+s)*x
void LinOp3ld::apply(cplx**__restrict x, cplx**__restrict y, int lmstart, int lmend, const double s)
{
	int i0 = irs;
	int i1 = ire;
	thread_interval_rad(i0, i1);
	for (int j=i0; j<=i1; j++) {
		double *Md = Mr(j) + 2;
		v2d* vy = (v2d*) y[j];		v2d* vxl = (v2d*) x[j-1];		v2d* vxd = (v2d*) x[j];		v2d* vxu = (v2d*) x[j+1];
		s2d Ml = vdup(Md[-2]);		s2d Mu = vdup(Md[-1]);
		LM_L_LOOP2( lmstart, lmend,  vy[lm] = Ml * vxl[lm] + vdup(s+Md[l]) * vxd[lm] + Mu * vxu[lm];  )
	}
}


/// Multiply complex vector x by a Tri-diagonal matrix (l-dependant)
/// y = (M+s).x    (y and x MUST be different)
/// x MUST have elements istart-1 and iend+1 defined ! (boundary conditions).
void LinOp3l::apply(cplx**__restrict x, cplx**__restrict y, int lmstart, int lmend, const double s)
{
	v2d** vx = (v2d**) x;
	int i0 = irs;
	int i1 = ire;
	thread_interval_rad(i0, i1);
	for (int j=i0; j<=i1; j++) {
		v2d* vy = (v2d*) y[j];		double *Mj = Mr(j) + 1;
		LM_L_LOOP2( lmstart, lmend,  vy[lm] = vdup(Mj[3*l-1]) * vx[j-1][lm] + vdup(s+Mj[3*l]) * vx[j][lm] + vdup(Mj[3*l+1]) * vx[j+1][lm];  )
	}
}

/// Multiply complex vector x by a Penta-diagonal matrix (l-dependant)
/// y = (M+s).x    (y and x MUST be different)
/// x MUST have elements istart-2 and iend+2 defined ! (boundary conditions).
void LinOp5l::apply(cplx**__restrict x, cplx**__restrict y, int lmstart, int lmend, const double s)
{
	v2d** vx = (v2d**) x;
	int i0 = irs;
	int i1 = ire;
	thread_interval_rad(i0, i1);
	for (int j=i0; j<=i1; j++) {
		v2d* vy = (v2d*) y[j];		double *Mj = Mr(j) + 2;
		LM_L_LOOP2( lmstart, lmend,  vy[lm] = vdup(Mj[5*l-2]) * vx[j-2][lm] + vdup(Mj[5*l-1]) * vx[j-1][lm] + vdup(s+Mj[5*l]) * vx[j][lm] + vdup(Mj[5*l+1]) * vx[j+1][lm] + vdup(Mj[5*l+2]) * vx[j+2][lm];  )
	}
}

void LinOp3ld::set_op(const double a, const double b, const LinOp3ld& L)
{
	for (int j=ir_bci; j<=ir_bco; j++) {
		double* Mj = Mr(j);
		double* Lj = L.Mr(j);
		Mj[0] = b*Lj[0];
		Mj[1] = b*Lj[1];
		for (int l=0; l<=lmax; l++)
			Mj[2+l]   = a + b*Lj[2+l];
	}
}

void LinOp3l::set_op(double a, double b, const LinOp3l& L)
{
	for (int j=ir_bci; j<=ir_bco; j++) {
		double* Mj = Mr(j);
		double* Lj = L.Mr(j);
		for (int l=0; l<=lmax; l++) {
			Mj[3*l]   = b*Lj[3*l];
			Mj[3*l+1] = b*Lj[3*l+1] + a;
			Mj[3*l+2] = b*Lj[3*l+2];
		}
	}
}

void LinOp3l::set_op(double a, double b, const LinOp3ld& L)
{
	for (int j=ir_bci; j<=ir_bco; j++) {
		double* Mj = Mr(j);
		double lo = L.lo(j);
		double up = L.up(j);
		for (int l=0; l<=lmax; l++) {
			Mj[3*l]   = b*lo;
			Mj[3*l+1] = b*L.di(j,l) + a;
			Mj[3*l+2] = b*up;
		}
	}
}

void LinOp5l::set_op(double a, double b, const LinOp5l& L)
{
	for (int j=ir_bci; j<=ir_bco; j++) {
		double* Mj = Mr(j);
		double* Lj = L.Mr(j);
		for (int l=0; l<=lmax; l++) {
			Mj[5*l]   = b*Lj[5*l];
			Mj[5*l+1] = b*Lj[5*l+1];
			Mj[5*l+2] = b*Lj[5*l+2] + a;
			Mj[5*l+3] = b*Lj[5*l+3];
			Mj[5*l+4] = b*Lj[5*l+4];
		}
	}
}

void LinOp5l::set_op(double a, const LinOp3ld& La, double b, const LinOp5l& Lb)
{
	for (int j=ir_bci; j<=ir_bco; j++) {
		double* Mj = Mr(j);
		double* Aj = La.Mr(j);
		double* Bj = Lb.Mr(j);
		for (int l=0; l<=lmax; l++)	{
			Mj[5*l]   = b*Bj[5*l];
			Mj[5*l+1] = b*Bj[5*l+1] + a*Aj[0];
			Mj[5*l+2] = b*Bj[5*l+2] + a*Aj[2+l];
			Mj[5*l+3] = b*Bj[5*l+3] + a*Aj[1];
			Mj[5*l+4] = b*Bj[5*l+4];
		}
	}
}

void LinOp5l::set_op(double a, const LinOp3l& La, double b, const LinOp5l& Lb)
{
	for (int j=ir_bci; j<=ir_bco; j++) {
		double* Mj = Mr(j);
		double* Aj = La.Mr(j);
		double* Bj = Lb.Mr(j);
		for (int l=0; l<=lmax; l++)	{
			Mj[5*l]   = b*Bj[5*l];
			Mj[5*l+1] = b*Bj[5*l+1] + a*Aj[3*l];
			Mj[5*l+2] = b*Bj[5*l+2] + a*Aj[3*l+1];
			Mj[5*l+3] = b*Bj[5*l+3] + a*Aj[3*l+2];
			Mj[5*l+4] = b*Bj[5*l+4];
		}
	}
}

void LinOp5l::set_op(double a, const LinOp5l& La, double b, const LinOp5l& Lb)
{
	for (int j=ir_bci; j<=ir_bco; j++) {
		double* Mj = Mr(j);
		double* Aj = La.Mr(j);
		double* Bj = Lb.Mr(j);
		for (int l=0; l<nelem; l++)	Mj[l] = a*Aj[l] + b*Bj[l];
	}
}


void LinOp3ld::precalc_solve() {
	if (r[ir_bci] == 0.0) {		// only l=0 exists at r==0
		_precalc_solve(ir_bci, ir_bco, 0, 0);		// l=0
		_precalc_solve(ir_bci+1, ir_bco, 1, lmax);	// l>0
		for (int l=1; l<=lmax; l++)
			set_di(ir_bci, l, 0.0);		// l>0, r=0  => trick to force to zero when solving
	}
	else _precalc_solve(ir_bci, ir_bco, 0, lmax);
}

void LU3l::precalc_solve() {
	if (r[ir_bci] == 0.0) {		// only l=0 exists at r==0
		_precalc_solve(ir_bci, ir_bco, 0, 0);		// l=0
		_precalc_solve(ir_bci+1, ir_bco, 1, lmax);	// l>0
		for (int l=1; l<=lmax; l++) {		// l>0, r=0  => trick to force to zero when solving
			set_lo(ir_bci, l, 0.0);
			set_di(ir_bci, l, 0.0);
			set_up(ir_bci, l, 0.0);
		}
	}
	else _precalc_solve(ir_bci, ir_bco, 0, lmax);

	// copy to L and U arrays to optimize cache usage during solve
	for (int i=0; i<=ire-irs; i++) {
		for (int l=0; l<=lmax; l++) {
			double* Mil = M(i+irs,l);
			L[i*nelem_L + 2*l]   = Mil[0];
			L[i*nelem_L + 2*l+1] = Mil[-1];
			U[(ire-irs-i)*nelem_U + l]     = Mil[1];
		}
	}
}

/// PARTIAL decomposition of tri-banded matrix M. All divisions happen here.
/// only the diagonal element is modified !!!
void LinOp3ld::_precalc_solve(const int i0, const int i1, const int l0, const int l1)
{
	int flag = 0;
	for (int j=i0; j<=i1; j++) {			//Decomposition.
		double dmin = fabs(di(j,l0));
		for (int l=l0; l<=l1; l++) {
			double p = di(j,l);
			double d = fabs(p);
			if (j>i0) p -= lo(j)*up(j-1) * di(j-1,l);
			if (d < dmin) dmin = d;
			set_di(j,l, 1.0/p);
		}
		double lu = 0.0;
		if (j > i0) lu += fabs(lo(j));
		if (j < i1) lu += fabs(up(j));
		if (dmin <= lu) flag = 1;
	}
	if (flag) runerr("[LinOp3ld::precalc_solve] non diagonal-dominant matrix !!!\n");
}

/// Full decomposition of tri-banded matrix M. All divisions happen here.
void LU3l::_precalc_solve(const int i0, const int i1, const int l0, const int l1)
{
	int flag = 0;
	for (int j=i0; j<=i1; j++) {			//Decomposition.
		for (int l=l0; l<=l1; l++) {
			double p = M(j,l)[0];
			double lu = 0.0;
			double d = fabs(p);
			if (j>i0) {
				p -= M(j,l)[-1] * M(j-1,l)[1] * M(j-1,l)[0];
				lu += fabs(M(j,l)[-1]);
			}
			M(j,l)[0] = 1.0/p;
			if (j < i1) lu += fabs(M(j,l)[1]);
			if (d <= lu) flag = 1;
		}
	}
	if (flag) runerr("[LU3l::_precalc_solve] non diagonal-dominant matrix !!!\n");

	for(int i=i0; i<=i1; i++) {
		for (int l=l0; l<=l1; l++) {
			double* Mil = M(i,l);
			double p_1 = Mil[0];
			Mil[-1] *= p_1;
			Mil[1]  *= p_1;
		}
	}
}

void LU5l::precalc_solve()
{
	int flag = 0;
	int i = ir_bci+1;
		for (int l=0; l<=lmax; l++) {
			double pp = M(i-1,l)[0];
			double d = fabs(pp);
			pp = 1.0/pp;
			double lu = fabs(M(i-1,l)[1]) + fabs(M(i-1,l)[2]);
			M(i-1,l)[0] = pp;
			if (d <= lu) flag = 1;
			double bet = M(i,l)[-1] * pp;
			double p = M(i,l)[0];
			d = fabs(p);
			p -= bet * M(i-1,l)[1];
			lu = fabs(M(i,l)[-1]) + fabs(M(i,l)[1]) + fabs(M(i,l)[2]);
			M(i,l)[1] -= bet * M(i-1,l)[2];
			M(i,l)[0] = 1.0/p;
			if (d <= lu) flag = 1;
		}
	for(int i=ir_bci+2; i<=ir_bco; i++) {
		for (int l=0; l<=lmax; l++) {
			double alp = M(i,l)[-2] * M(i-2,l)[0];
			double t = M(i,l)[-1] - alp * M(i-2,l)[1];
			double lu = fabs(M(i,l)[-2]) + fabs(M(i,l)[-1]);
			M(i,l)[-1] = t;
			double bet = t * M(i-1,l)[0];
			double p = M(i,l)[0];
			double d = fabs(p);
			p -= bet * M(i-1,l)[1] + alp * M(i-2,l)[2];
			lu += fabs(M(i,l)[1]) + fabs(M(i,l)[2]);
			M(i,l)[1] -= bet * M(i-1,l)[2];
			M(i,l)[0] = 1.0/p;
			if (d <= lu) flag = 1;
		}
	}
	//if (flag) runerr("[LU5l::_precalc_solve] non diagonal-dominant matrix !!!\n");
	if (flag) PRINTF0("[LU5l::_precalc_solve] warning: non diagonal-dominant matrix !!!\n");

	for(int i=ir_bci; i<=ir_bco; i++) {
		for (int l=0; l<=lmax; l++) {
			double* Mil = M(i,l);
			double p_1 = Mil[0];
			Mil[-2] *= p_1;
			Mil[-1] *= p_1;
			Mil[1]  *= p_1;
			Mil[2]  *= p_1;
		}
	}

	// copy to L and U arrays to optimize cache usage during solve
	for (int i=0; i<=ire-irs; i++) {
		for (int l=0; l<=lmax; l++) {
			double* Mil = M(i+irs,l);
			L[i*nelem_L + 3*l]   = Mil[0];
			L[i*nelem_L + 3*l+1] = Mil[-1];
			L[i*nelem_L + 3*l+2] = Mil[-2];
			U[(ire-irs-i)*nelem_U + 2*l]   = Mil[1];
			U[(ire-irs-i)*nelem_U + 2*l+1] = Mil[2];
		}
	}
}


#ifndef XS_MPI
/// Solve M x = b, where b is initially stored in x.
/// x can have elements istart-1 and iend+1 set (if not => same as cTriSolve).
/// iend - istart >= 2  (ie at least 3 elements)
void LinOp3ld::solve(cplx** x, int lmstart, int lmend) const
{
	int j = irs;	// handle lower boundary : b(j) -> b(j) - Ml(j).x(j-1)
	{
		v2d* vx = (v2d*) x[j];		v2d* vxl = (v2d*) x[j-1];
		s2d Ml = vdup(lo(j));
		LM_LOOP2( lmstart, lmend,  vx[lm] -= Ml * vxl[lm];  )
	}
	while (++j<=ire) {		// Forward substitution.
		v2d* vx = (v2d*) x[j];		v2d* vxl = (v2d*) x[j-1];
		s2d Ml = vdup(lo(j));	double* Md = Mr(j-1) + 2;
		LM_L_LOOP2( lmstart, lmend,  vx[lm] -= vdup(Md[l]) * Ml * vxl[lm];  )
	}	// j = iend+1;
	j = ire+1;	// handle upper boundary : b(j) -> b(j) - Mu(j).x(j+1)
	while (--j >= irs) {		// Back-substitution.
		v2d* vx = (v2d*) x[j];		v2d* vxu = (v2d*) x[j+1];
		s2d Mu = vdup(up(j));	double* Md = Mr(j) + 2;
		LM_L_LOOP2( lmstart, lmend,  vx[lm] = ( vx[lm] - Mu *vxu[lm] ) * vdup(Md[l]);  )
	}
}
#endif


#ifdef XS_MPI
/// Solve M x = b, where b and x can be the same array.
/// x can have elements istart-1 and iend+1 set (if not => same as cTriSolve).
/// iend - istart >= 2  (ie at least 3 elements) 
void LinOp3ld::solve_up(cplx **x, int lmstart, int lmend, int tag, MPI_Request **req, int lms_block, int nlm_block) const
{
	if (irs > ire) return;		// reject processes not involved.

	int j = irs;
	if (irs > ir_bci) {		// we are not the first block
		j -= 1;
		#pragma omp master
		MPI_Recv(x[j]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);	// blocking receive
		#pragma omp barrier
	} else
		{	// handle lower boundary : b(j) -> b(j) - Ml(j).x(j-1)
			v2d* vx = (v2d*) x[j];		v2d* vxl = (v2d*) x[j-1];
			s2d Ml = vdup(lo(j));
			LM_LOOP2( lmstart, lmend,  vx[lm] -= Ml * vxl[lm];  )		
		}
	while(++j <= ire) {
		v2d* vx = (v2d*) x[j];		v2d* vxl = (v2d*) x[j-1];
		s2d Ml = vdup(lo(j));	double* Md = Mr(j-1) + 2;
		LM_L_LOOP2( lmstart, lmend,  vx[lm] -= vdup(Md[l]) * Ml * vxl[lm];  )		
	}	// j = ire+1;
	if (ire < ir_bco) {		// we are not the last block
		#pragma omp barrier
		#pragma omp master
		{
			MPI_Isend(x[j-1]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag, MPI_COMM_WORLD, *req);		// non-blocking send
			*req += 1;
		}
	}
}

void LinOp3ld::solve_dn(cplx **x, int lmstart, int lmend, int tag, MPI_Request **req, int lms_block, int nlm_block) const
{
	if (irs > ire) return;		// reject processes not involved.

	int j = ire+1;	// handle upper boundary : x(j) -> x(j) - Mu(j).x(j+1)
	if (ire < ir_bco) {		// we are not the last block.
		#pragma omp master
		MPI_Recv (x[j]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);		// blocking receive
		#pragma omp barrier
	}
	while (--j >= irs) {		// Back-substitution.
		v2d* vx = (v2d*) x[j];		v2d* vxu = (v2d*) x[j+1];
		s2d Mu = vdup(up(j));	double* Md = Mr(j) + 2;
		LM_L_LOOP2( lmstart, lmend,  vx[lm] = ( vx[lm] - Mu *vxu[lm] ) * vdup(Md[l]);  )
	}
	#pragma omp barrier
	#pragma omp master
	{
		if (irs > ir_bci) {		// we are not the first block
			MPI_Isend(x[irs]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag, MPI_COMM_WORLD, *req);		// for solve down to go on
			*req += 1;
		}
	}
}

template <class T>
void _LinOp3l<T>::solve_finish(Spectral& X, int icomp, int tag, MPI_Request **req, int lms_block, int nlm_block) const
{
	int istart = ir_bci;
	int iend = ir_bco;
	int ir0 = X.ir_bci;
	int ir1 = X.ir_bco;
	if ((ir1 < irs_mpi)||(ir0 > ire_mpi)) return;		// reject processes not involved.
	#pragma omp master
	{
		iend = ir1;				// this fixes the last shell.
		if (istart != ir0) {		// fixes the first shell.
			if (irs_mpi == ir0+1) {		// send down
				MPI_Isend(X.get_data(icomp,irs_mpi)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag, MPI_COMM_WORLD, *req);		// for boundary to be up to date !
				*req += 1;
			}
		 	if (ire_mpi == ir0) {		// receive up
				MPI_Irecv(X.get_data(icomp,ire_mpi+1)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag, MPI_COMM_WORLD, *req);		// for boundary to be up to date !
				*req += 1;
			}
		}
		if (irs_mpi > istart) {		// we are not the first block
			istart=irs_mpi;
			MPI_Irecv(X.get_data(icomp,istart-1)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag, MPI_COMM_WORLD, *req);		// sync halo
			*req += 1;
		}
		if ((ire_mpi < iend)&&(ire_mpi >= istart)) {		// we are not the last block.
			iend=ire_mpi;
			MPI_Isend(X.get_data(icomp,iend)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag, MPI_COMM_WORLD, *req);		// sync halo
			*req += 1;
		}
	}	
}
#endif

#ifndef XS_MPI
/// Solve M x = b, where b is initially stored in x.
/// x MUST have elements istart-1 and iend+1 defined ! (boundary conditions).
void LU3l::solve(cplx** x, int lmstart, int lmend) const
{
	v2d** vx = (v2d**) x;
// forward
	double* Lj = L;
	for(int j=ir_bci; j<=ir_bco; j++) {
		LM_L_LOOP2( lmstart, lmend,  vx[j][lm] = vdup(Lj[2*l]) * vx[j][lm] - vdup(Lj[2*l+1]) * vx[j-1][lm];  )
		Lj += nelem_L;
	}
// backward
	double* Uj = U;
	for(int j=ir_bco; j>=ir_bci; j--) {
		LM_L_LOOP2( lmstart, lmend,  vx[j][lm] -= vdup(Uj[l]) * vx[j+1][lm];  )
		Uj += nelem_U;
	}
}

/// Solve M x = b, where b is initially stored in x.
/// x MUST have elements istart-2 and iend+2 defined ! (boundary conditions).
void LU5l::solve(cplx** x, int lmstart, int lmend) const
{
	v2d** vx = (v2d**) x;
// forward
	double* Lj = L;
	for(int j=ir_bci; j<=ir_bco; j++) {
		LM_L_LOOP2( lmstart, lmend,  vx[j][lm] = vdup(Lj[3*l]) * vx[j][lm] - vdup(Lj[3*l+1]) * vx[j-1][lm] - vdup(Lj[3*l+2]) * vx[j-2][lm];  )
		Lj += nelem_L;
	}
// backward
	double* Uj = U;
	for(int j=ir_bco; j>=ir_bci; j--) {
		LM_L_LOOP2( lmstart, lmend,  vx[j][lm] -= vdup(Uj[2*l]) * vx[j+1][lm] + vdup(Uj[2*l+1]) * vx[j+2][lm];  )
		Uj += nelem_U;
	}
}
#endif

#ifdef XS_MPI
/// x MUST have elements istart-1 and iend+1 defined ! (boundary conditions).
void LU3l::solve_up(cplx **x, int lmstart, int lmend, int tag, MPI_Request **req, int lms_block, int nlm_block) const
{
	if (irs > ire) return;		// reject processes not involved.

	v2d** vx = (v2d**) x;
	if (irs > ir_bci) {		// we are not the first block
		#pragma omp master
		{
			int j=irs;
			MPI_Recv(x[j-1]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);	// blocking receive
		}
		#pragma omp barrier
	}
// forward
	double* Lj = L;
	for(int j=irs; j<=ire; j++) {
		LM_L_LOOP2( lmstart, lmend,  vx[j][lm] = vdup(Lj[2*l]) * vx[j][lm] - vdup(Lj[2*l+1]) * vx[j-1][lm];  )
		Lj += nelem_L;
	}
	if (ire < ir_bco) {
		#pragma omp barrier
		#pragma omp master
		{
			int j=ire;
			MPI_Isend(x[j]+lms_block,   2*nlm_block, MPI_DOUBLE, i_mpi+1, tag, MPI_COMM_WORLD, *req);	// non-blocking send
			*req += 1;
		}
	}
}

/// x MUST have elements istart-2 and iend+2 defined ! (boundary conditions).
void LU5l::solve_up(cplx **x, int lmstart, int lmend, int tag, MPI_Request **req, int lms_block, int nlm_block) const
{
	if (irs > ire) return;		// reject processes not involved.

	v2d** vx = (v2d**) x;
	if (irs > ir_bci) {		// we are not the first block
		#pragma omp master
		{
			int j=irs;
			MPI_Recv(x[j-2]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag,   MPI_COMM_WORLD, MPI_STATUS_IGNORE);	// blocking receive
			MPI_Recv(x[j-1]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag+1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);	// blocking receive
		}
		#pragma omp barrier
	}
// forward
	double* Lj = L;
	for(int j=irs; j<=ire; j++) {
		LM_L_LOOP2( lmstart, lmend,  vx[j][lm] = vdup(Lj[3*l]) * vx[j][lm] - vdup(Lj[3*l+1]) * vx[j-1][lm] - vdup(Lj[3*l+2]) * vx[j-2][lm];  )
		Lj += nelem_L;
	}
	if (ire < ir_bco) {
		#pragma omp barrier
		#pragma omp master
		{
			int j=ire;
			MPI_Isend(x[j-1]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag,   MPI_COMM_WORLD, *req);		// non-blocking send
			MPI_Isend(x[j]+lms_block,   2*nlm_block, MPI_DOUBLE, i_mpi+1, tag+1, MPI_COMM_WORLD, *req +1);	// non-blocking send
			*req += 2;
		}
	}
}

/// x MUST have elements istart-1 and iend+1 defined ! (boundary conditions).
void LU3l::solve_dn(cplx **x, int lmstart, int lmend, int tag, MPI_Request **req, int lms_block, int nlm_block) const
{
	if (irs > ire) return;		// reject processes not involved.

	v2d** vx = (v2d**) x;
	if (ire < ir_bco) {		// we are not the last block.
		#pragma omp master
		{
			MPI_Recv (x[ire+1]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag,   MPI_COMM_WORLD, MPI_STATUS_IGNORE);		// blocking receive
		}
		#pragma omp barrier
	}
// backward
	double* Uj = U;
	for(int j=ire; j>=irs; j--) {
		LM_L_LOOP2( lmstart, lmend,  vx[j][lm] -= vdup(Uj[l]) * vx[j+1][lm];  )
		Uj += nelem_U;
	}
	#pragma omp barrier
	#pragma omp master
	{
		if (irs > ir_bci) {
			MPI_Isend(x[irs]+lms_block,   2*nlm_block, MPI_DOUBLE, i_mpi-1, tag,   MPI_COMM_WORLD, *req);		// for solve to go on
			*req += 1;
		}
	}
}

/// x MUST have elements istart-2 and iend+2 defined ! (boundary conditions).
void LU5l::solve_dn(cplx **x, int lmstart, int lmend, int tag, MPI_Request **req, int lms_block, int nlm_block) const
{
	if (irs > ire) return;		// reject processes not involved.

	v2d** vx = (v2d**) x;
	if (ire < ir_bco) {		// we are not the last block.
		#pragma omp master
		{
			MPI_Recv (x[ire+1]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag,   MPI_COMM_WORLD, MPI_STATUS_IGNORE);		// blocking receive
			MPI_Recv (x[ire+2]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag+1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);		// blocking receive
		}
		#pragma omp barrier
	}
// backward
	double* Uj = U;
	for(int j=ire; j>=irs; j--) {
		LM_L_LOOP2( lmstart, lmend,  vx[j][lm] -= vdup(Uj[2*l]) * vx[j+1][lm] + vdup(Uj[2*l+1]) * vx[j+2][lm];  )
		Uj += nelem_U;
	}

	#pragma omp barrier
	#pragma omp master
	{
		if (irs > ir_bci) {
			MPI_Isend(x[irs]+lms_block,   2*nlm_block, MPI_DOUBLE, i_mpi-1, tag,   MPI_COMM_WORLD, *req);		// for solve to go on
			MPI_Isend(x[irs+1]+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag+1, MPI_COMM_WORLD, *req +1);	// for solve to go on
			*req += 2;
		}
	}
}

/// synchronizing halo after solve (to allow 1 shell per mpi process)
void LU5l::solve_finish(Spectral& X, int icomp, int tag, MPI_Request **req, int lms_block, int nlm_block) const
{
	int send_up = 0;
	int send_dn = 0;
	int istart = ir_bci;
	int iend = ir_bco;
	int ir0 = X.ir_bci;
	int ir1 = X.ir_bco;
	if ((ir1 < irs_mpi)||(ir0 > ire_mpi)) return;		// reject processes not involved.
	#pragma omp master
	{
		iend = ir1;				// this fixes the last shell.
		if (istart != ir0) {		// fixes the first shell.
			if (irs_mpi == ir0+1) {		// send down
				MPI_Isend(X.get_data(icomp,irs_mpi)+lms_block,   2*nlm_block, MPI_DOUBLE, i_mpi-1, tag,   MPI_COMM_WORLD, *req);	// for boundary to be up to date !
				MPI_Isend(X.get_data(icomp,irs_mpi+1)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag+1, MPI_COMM_WORLD, *req+1);	// for boundary to be up to date !
				*req += 2;
			}
		 	if (ire_mpi == ir0) {		// receive up
				MPI_Irecv(X.get_data(icomp,ire_mpi+1)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag,   MPI_COMM_WORLD, *req);	// for boundary to be up to date !
				MPI_Irecv(X.get_data(icomp,ire_mpi+2)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag+1, MPI_COMM_WORLD, *req+1);	// for boundary to be up to date !
				*req += 2;
			}
		}
		if (irs_mpi > istart) {		// we are not the first block
			istart=irs_mpi;		send_dn=1;
		}
		if ((ire_mpi < iend)&&(ire_mpi >= istart)) {		// we are not the last block (of the solve range)
			iend=ire_mpi;		send_up=1;
		}
		if (send_up) {
			MPI_Isend(X.get_data(icomp,iend)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag, MPI_COMM_WORLD, *req);	// update halo
			*req += 1;
		}
		if (send_dn) {
			MPI_Irecv(X.get_data(icomp,istart-2)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag+1, MPI_COMM_WORLD, *req);		// update halo
			*req += 1;
			if ((iend > istart)||(send_up==0)) {
				MPI_Irecv(X.get_data(icomp,istart-1)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag, MPI_COMM_WORLD, *req);		// update halo
				*req += 1;
			} else {
				MPI_Recv (X.get_data(icomp,istart-1)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi-1, tag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);		// blocking update halo
			}
		}
		if (send_up) {
			MPI_Isend(X.get_data(icomp,iend-1)+lms_block, 2*nlm_block, MPI_DOUBLE, i_mpi+1, tag+1, MPI_COMM_WORLD, *req);	// update halo
			*req += 1;
		}
	}
}
#endif

template <class T>
void _LinOp3l<T>::set_Laplace(int ir, const double* d1r, const double* d2r, const double s)
{
	double r_1 = 1.0/r[ir];

	set_lo(ir, s*(d2r[0] + 2.*r_1*d1r[0]) );
	set_up(ir, s*(d2r[2] + 2.*r_1*d1r[2]) );
	double d = s*(d2r[1] + 2.*r_1*d1r[1]);
	double sr_2 = s*r_1*r_1;
	for (int l=0; l<=lmax; l++)
		set_di(ir,l,  d - sr_2*(l*(l+1)) );
}

template <class T>
void _LinOp3l<T>::set_Laplace(int ir, const double s)
{
	double gr[3], d2r[3];

	fd_deriv_o2(r,ir, gr, d2r);	
	set_Laplace(ir, gr, d2r, s);
}

/// Laplace operator considering the boundary condition a0*f + a1*f' = ghost
template <class T>
void _LinOp3l<T>::set_Laplace_bc(int ir, double a0, double a1, const double s)
{
	double gr[3], d2r[3];
	int ii;

	if ((ir!=ir_bci)&&(ir!=ir_bco)) {
		runerr("[set_Laplace] cannot set boundary condition outside boundaries");
	}
	if (r[ir] == 0.0) {			// special boundary condition for r=0 (scalar)
		double dx_2 = 1.0/(r[ir+1]*r[ir+1]);
		set_lo(ir,    0.0 );
		set_up(ir,    6.*s * dx_2 );
		set_di(ir,0, -6.*s * dx_2 );		// only for l=0
		for (int l=3; l<nelem; l++)  Mr(ir)[l] = 0.0;		// l>0 (for LinOp3l and LinOp3)
		return;
	}

	if (ir==ir_bci)	 ii = +1;
	if (ir==ir_bco)  ii = -1;
	fd_deriv_o2_bc(r[ir+ii]-r[ir], a0, a1, 0.0, gr, d2r);
	set_Laplace(ir, gr, d2r, s);
}

void LinOp5l::set_BiLaplace4(int ir, const double* d1r, const double* d2r, const double* d3r, const double* d4r,
	const double s1, const double s2)
{
	double LLr[5], LLr_l2[5];
	double r_1 = 1.0/r[ir];

	for (int k=0; k<5; k++) {
		LLr[k] = s2*(d4r[k] + 4.0*r_1*d3r[k])		// bilaplace radial
		       + s1*(d2r[k] + 2.0*r_1*d1r[k]);		// laplace radial
		LLr_l2[k] = s2*(2.0*r_1*r_1*d2r[k]);			// bilaplace multiplied by l(l+1)
	}
	double s1r_2 = s1*(r_1*r_1);
	double s2r_4 = s2*(r_1*r_1)*(r_1*r_1);
	for (int l=0; l<=lmax; l++) {
		double l2 = l*(l+1);
		for (int k=0; k<5; k++) {
			M(ir,l)[k-2] = LLr[k] - l2*LLr_l2[k];
		}
		M(ir,l)[0] += l2*(s2r_4*(l2-2.) - s1r_2);
	}
}

void LinOp5l::set_Laplace4(int ir, const double* d1r, const double* d2r, const double s)
{
	double Lr[5];
	double r_1 = 1.0/r[ir];

	for (int k=0; k<5; k++) {
		Lr[k] = s*(d2r[k] + 2.0*r_1*d1r[k]);		// laplace radial
	}
	double sr_2 = s*(r_1*r_1);
	for (int l=0; l<=lmax; l++) {
		double l2 = l*(l+1);
		for (int k=0; k<5; k++) {
			M(ir,l)[k-2] = Lr[k];
		}
		M(ir,l)[0] -= l2*sr_2;
	}
}

void LinOp5l::set_Laplace2(int ir, const double* Lr, const double s)
{
	double r_2 = 1.0/(r[ir]*r[ir]);
	for (int l=0; l<=lmax; l++) {
		double l2 = (l*(l+1));
		M(ir,l)[-2] = 0.0;
		M(ir,l)[-1] = s*Lr[0];
		M(ir,l)[0]  = s*(Lr[1] - l2*r_2);
		M(ir,l)[1]  = s*Lr[2];
		M(ir,l)[2]  = 0.0;
	}
}

void LinOp5l::set_BiLaplace2(int ir, const double* Lrl, const double* Lrd, const double* Lru, const double s)
{
	double r_2 = 1.0/(r[ir]*r[ir]);
	double rl_2 = 1.0/(r[ir-1]*r[ir-1]);
	double ru_2 = 1.0/(r[ir+1]*r[ir+1]);
	if (r[ir-1] == 0.0) 	rl_2 = 0.0;		// Laplace(r=0) should be treated separately.
	for (int l=0; l<=lmax; l++) {
		double l2 = l*(l+1);
		double l2_r2 = l2 * r_2;
		M(ir,l)[-2] = Lrd[0]*Lrl[0];
		M(ir,l)[-1] = Lrd[0]*(Lrl[1] - l2*rl_2) + (Lrd[1] - l2_r2)*Lrd[0];
		M(ir,l)[0]  = Lrd[0]*Lrl[2]             + (Lrd[1] - l2_r2)*(Lrd[1] - l2_r2) + Lrd[2]*Lru[0];
		M(ir,l)[1]  =                             (Lrd[1] - l2_r2)*Lrd[2]           + Lrd[2]*(Lru[1] - l2*ru_2);
		M(ir,l)[2]  =                                                                 Lrd[2]*Lru[2];
	}
	LinOpR::scale(ir, s);
}
