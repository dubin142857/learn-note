/*
 * Copyright (c) 2010-2017 Centre National de la Recherche Scientifique.
 * written by Nathanael Schaeffer (CNRS, ISTerre, Grenoble, France).
 * 
 * nathanael.schaeffer@univ-grenoble-alpes.fr
 * 
 * This software is governed by the CeCILL license under French law and
 * abiding by the rules of distribution of free software. You can use,
 * modify and/or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info".
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */

/// \file xshells_physics.cpp main program for
/// XSHELLS (eXtendable Spherical Harmonic Earth-Like Liquid Simulator).

#include "xshells_linop.cpp"

/*! \name Matrices */
//@{
LinOp5l MUp, MU_LLr;
LU5l MUp_1;
#ifndef XS_O4
#ifndef XS_HYPER_DIFF
typedef LinOp3ld LOp3l;
typedef LinOp3ld LOp3l_LU;
#else
typedef LinOp3l LOp3l;
typedef LU3l LOp3l_LU;
#endif
LOp3l MBp, MBt, MUt, MT, MC;
LOp3l_LU MBp_1, MBt_1, MUt_1, MT_1, MC_1;
LinOp3ld MU_Lr;
#else
LinOp5l MBp, MBt, MUt, MT, MC;
LU5l MBp_1, MBt_1, MUt_1, MT_1, MC_1;
LinOp5l MU_Lr;
#endif

double *__restrict Mcor;		///< Special Coriolis Matrix.
double *__restrict Mm_l2;		///< Special Coriolis Matrix.
//@}

#ifdef XS_ETA_VAR
double* etar = NULL;	/// conductivity as a function of r
void calc_eta(double eta0);
#endif
#ifdef XS_HYPER_DIFF
	double h_nu = 1.0;
	double h_kappa = 1.0;
#endif
	double hyper_diff_l0 = 0;	/// controls the start of hyper-diff in l-spectrum.


struct spat_vect {
	double *r, *t, *p;

	void* alloc(size_t nspat_alloc, void* mem);
};

struct dual_vect : spat_vect {
	cplx *Q, *S, *T;

	void* alloc(size_t nspat_alloc, size_t nspec, void* mem, int nc=3);
};

void* spat_vect::alloc(size_t nspat_alloc, void* mem)
{
	r = (double*) mem;
	t = r + nspat_alloc;		p = r + 2*nspat_alloc;
	return (r + 3*nspat_alloc);
}

void* dual_vect::alloc(size_t nspat_alloc, size_t nspec, void* mem, int nc)
{
	mem = spat_vect::alloc(nspat_alloc, mem);
	Q = (cplx*) mem;
	S = Q + nspec;		T = Q + 2*nspec;
	return (Q + nc*nspec);
}

/// compute cross product: (xr,xt,xp) = (vr,vt,vp) X (wr,wt,wp)
void cross_prod(spat_vect& x, spat_vect& v, spat_vect& w, size_t nspat0, size_t nspat1)
{
	for (size_t k=nspat0/VSIZE; k<nspat1/VSIZE; k++) {
		rnd vvt = vread(v.t,k);		rnd vwt = vread(w.t,k);
		rnd vvp = vread(v.p,k);		rnd vwp = vread(w.p,k);
		rnd rr = vvt*vwp - vvp*vwt;	// AxB
		rnd vvr = vread(v.r,k);		rnd vwr = vread(w.r,k);
		rnd rt = vvp*vwr - vvr*vwp;
		rnd rp = vvr*vwt - vvt*vwr;
		vstore(x.r,k, rr);	vstore(x.t,k, rt);	vstore(x.p,k, rp);
	}
}

/// compute cross product and add: (xr,xt,xp) += (vr,vt,vp) X (wr,wt,wp)
void cross_prod_add(spat_vect& x, spat_vect& v, spat_vect& w, size_t nspat0, size_t nspat1)
{
	for (size_t k=nspat0/VSIZE; k<nspat1/VSIZE; k++) {
		rnd vvt = vread(v.t,k);		rnd vwt = vread(w.t,k);
		rnd vvp = vread(v.p,k);		rnd vwp = vread(w.p,k);
		rnd rr = vvt*vwp - vvp*vwt;	// AxB
		rnd vvr = vread(v.r,k);		rnd vwr = vread(w.r,k);
		rnd rt = vvp*vwr - vvr*vwp;
		rnd rp = vvr*vwt - vvt*vwr;
		vmemadd(x.r,k, rr);		vmemadd(x.t,k, rt);		vmemadd(x.p,k, rp);
	}
}

void cross_prod_condadd(spat_vect& x, spat_vect& v, spat_vect& w, size_t nspat0, size_t nspat1, const int add=0)
{
	for (size_t k=nspat0/VSIZE; k<nspat1/VSIZE; k++) {
		rnd vvt = vread(v.t,k);		rnd vwt = vread(w.t,k);
		rnd vvp = vread(v.p,k);		rnd vwp = vread(w.p,k);
		rnd rr = vvt*vwp - vvp*vwt;	// AxB
		rnd vvr = vread(v.r,k);		rnd vwr = vread(w.r,k);
		rnd rt = vvp*vwr - vvr*vwp;
		rnd rp = vvr*vwt - vvt*vwr;
		if (add) {
			vmemadd(x.r,k, rr);		vmemadd(x.t,k, rt);		vmemadd(x.p,k, rp);
		} else {
			vstore(x.r,k, rr);	vstore(x.t,k, rt);	vstore(x.p,k, rp);
		}
	}
}

void scal_vect(spat_vect& x, double* a, spat_vect& g,  size_t nspat0, size_t nspat1)
{
	for (size_t k=nspat0/VSIZE; k<nspat1/VSIZE; k++) {
		rnd va = vread(a,k);		rnd gr = vread(g.r,k);
		rnd gt = vread(g.t,k);		rnd gp = vread(g.p,k);
		gr *= va;		gt *= va;		gp *= va;
		vstore(x.r,k, gr);	vstore(x.t,k, gt);	vstore(x.p,k, gp);
	}
}

void scal_vect_add(spat_vect& x, double* a, spat_vect& g,  size_t nspat0, size_t nspat1)
{
	for (size_t k=nspat0/VSIZE; k<nspat1/VSIZE; k++) {
		rnd va = vread(a,k);		rnd gr = vread(g.r,k);
		rnd gt = vread(g.t,k);		rnd gp = vread(g.p,k);
		gr *= va;		gt *= va;		gp *= va;
		vmemadd(x.r,k, gr);		vmemadd(x.t,k, gt);		vmemadd(x.p,k, gp);
	}
}


	/* MATRIX INITIALIZATION */

/*
// an accurate alternate way to build the matrix corresponding to multiplication by cos(theta).
// tested => ok
void mul_ct_matrix_alt(double *mx2)
{
	cplx *qlm0, *qlm2;
	double *sp0, *sp2;

	qlm0 = (cplx*) fftw_malloc(sizeof(double)*(4*NLM + 2*shtns->nspat));
	qlm2 = qlm0 + NLM;
	sp0 = (double*) (qlm2 + NLM);
	sp2 = sp0 + shtns->nspat;

	memset(qlm0, 0, sizeof(double)*4*NLM);
	for (int im=0; im<=MMAX; im++) {
		int l=im*MRES;
		int lm=LiM(l,im);
		while (l<=LMAX-3) {
			qlm0[lm] = 1.0;
			qlm0[lm+1] = 1.0;
			qlm2[lm+2] = 1.0;
			qlm2[lm+3] = 1.0;
			l+=4;	lm+=4;
		}
		if (l<=LMAX) qlm0[lm] = 1.0;
		if (l+1 <= LMAX) qlm0[lm+1] = 1.0;
		if (l+2 <= LMAX) qlm2[lm+2] = 1.0;
		if (l+3 <= LMAX) qlm2[lm+3] = 1.0;
	}
	SH_SPAT(qlm0, sp0);
	SH_SPAT(qlm2, sp2);
	for (size_t k=0; k<shtns->nspat; k++) {
		sp0[k] *= ct[k%NLAT];		sp2[k] *= ct[k%NLAT];
	}
	SPAT_SH(sp0, qlm0);
	SPAT_SH(sp2, qlm2);
	for (int im=0; im<=MMAX; im++) {
		int m = im*MRES;
		for (int l=m; l<=LMAX; l++) {
			int lm = LiM(l,im);
			int shift = ((l+3-m) & 2)>>1;		// shift = 0 qlm0 is a contribution from -1, shift =1 qlm0 is a contribution from +1
			mx2[2*lm + shift] 	  = real(qlm0[lm]);
			mx2[2*lm + (1-shift)] = real(qlm2[lm]);
		}
		mx2[2*LiM(im*MRES,im)] = 0.0;		// these two are exactly zero.
		mx2[2*LiM(LMAX,im)+1] = 0.0;
	}
	fftw_free(qlm0);
	
	{	// Test matrix:
		double *M0;
		M0 = (double*) malloc(2*NLM*sizeof(double));
		mul_ct_matrix(shtns, M0);
		double max = 0;
		int k0 = -1;
		for (int k=0; k<2*NLM; k++) {
			if (M0[k] != 0.0) {
				double diff = fabs((mx2[k] - M0[k])/M0[k]);
				if (diff > max) {
					max = diff;
					k0 = k;
				}
			}
		}
		printf("max error = %g (k=%d)\n", max, k0);
		free(M0);
	}
}

// UNTESTED
void mul_st2_matrix(double *mx3)
{
	cplx *qlm0, *qlm2, *qlm4;
	double *sp0, *sp2, *sp4;

	qlm0 = (cplx*) fftw_malloc(sizeof(double)*(6*NLM + 3*shtns->nspat));
	qlm2 = qlm0 + NLM;		qlm4 = qlm0 + 2*NLM;
	sp0 = (double*) (qlm4 + NLM);
	sp2 = sp0 + shtns->nspat;		sp4 = sp0 + 2*shtns->nspat;

	memset(qlm0, 0, sizeof(double)*6*NLM);
	for (int im=0; im<=MMAX; im++) {
		for (int l=im*MRES; l<=LMAX; l+=6) {
			int lm=LiM(l,im);
			qlm0[lm] = 1.0;
			if (l+1 <= LMAX) qlm0[lm+1] = 1.0;
			if (l+2 <= LMAX) qlm2[lm+2] = 1.0;
			if (l+3 <= LMAX) qlm2[lm+3] = 1.0;
			if (l+4 <= LMAX) qlm4[lm+4] = 1.0;
			if (l+5 <= LMAX) qlm4[lm+5] = 1.0;
		}
	}
	SH_SPAT(qlm0, sp0);
	SH_SPAT(qlm2, sp2);
	SH_SPAT(qlm4, sp4);
	for (size_t k=0; k<shtns->nspat; k++) {
		double st2 = st[k%NLAT];	st2 *= st2;
		sp0[k] *= st2;		sp2[k] *= st2;		sp4[k] *= st2;
	}
	SPAT_SH(sp0, qlm0);
	SPAT_SH(sp2, qlm2);
	SPAT_SH(sp4, qlm4);
	for (int im=0; im<=MMAX; im++) {
		int m = im*MRES;
		for (int l=m; l<=LMAX; l++) {
			int lm = LiM(l,im);
			int k = (l-m)>>1;
			int shift0 = 2 - (k+1)%3;		// qlm0 is a contribution from l-2 if shif0=0, l if shift0=1, l+1 if shift0=2
			int shift2 = 2 - k%3;
			int shift4 = 2 - (k+2)%3;
			mx3[3*lm + shift0] = real(qlm0[lm]);
			mx3[3*lm + shift2] = real(qlm2[lm]);
			mx3[3*lm + shift4] = real(qlm4[lm]);
		}
		mx3[2*LiM(im*MRES,im)] = 0.0;		// these four are exactly zero.
		mx3[2*LiM(LMAX,im)+1] = 0.0;
		if (im*MRES+1<=LMAX) {
			mx3[2*LiM(im*MRES+1,im)] = 0.0;
			mx3[2*LiM(LMAX-1,im)+1] = 0.0;
		}
	}
	fftw_free(qlm0);
}
*/


#ifdef XS_HYPER_DIFF
int calc_hyper_diff(double* diff_el, double factor)
{
	int l0 = LMAX+1;
	for (int l=0; l<=LMAX; l++) diff_el[l] = 1.0;
	if ((hyper_diff_l0 > 0.0) && (factor > 1.0)) {
		l0 = LMAX - hyper_diff_l0;
		if (hyper_diff_l0 < 1)  l0 = hyper_diff_l0 * (LMAX+1);
		double q = pow(factor, 1.0/(LMAX-l0));
		for (int l=l0+1; l<=LMAX; l++) diff_el[l] = diff_el[l-1] * q;
	}
	return l0;
}
#endif

namespace xs_sparse {		// forward declaration of prepare_solve
	void prepare_solve(double dt, double theta);
}

/// Initialize semi-implicit part of Induction equation.
///      matrix   MB = (1/dt + 0.5*eta*Lap)
/// and  matrix MB{p,t}_1 = (1/dt - 0.5*eta*Lap)^(-1)
/// Same matrix MB may be used for Poloidal and Toroidal components. Reverse is MBp_1 and MBt_1 (Polidal up to NR-1, Toroidal up to NR-2)
void init_Bmatrix(PolTor &Blm, double eta)
{
	const int irs = Blm.ir_bci;		// magnetic field limits.
	const int ire = Blm.ir_bco;
	long int i,l;
	double dx_1, dx_2;

	if (eta <= 0.) runerr("diffusivity should be strictly positive.");

#ifdef XS_ETA_VAR
	if (etar == NULL) {
		etar = (double*) fftw_malloc(NR * sizeof(double));
		if (etar==0) runerr("[init_Bmatrix] allocation error");
		for (i=0; i<NR; i++) etar[i] = eta;		// constant conductivity as default value.
		#ifdef XS_ETA_PROFILE
			calc_eta(eta);		// profile defined in xshells.hpp
			double dx_1=eta;	double dx_2=eta;
			for (i=irs; i<=ire; i++) {
				if (etar[i] < dx_1) dx_1 = etar[i];
				if (etar[i] > dx_2) dx_2 = etar[i];
			}
			PRINTF0("=> Variable conductivity profile eta(r) : %lg <= eta <= %lg\n", dx_1, dx_2);
		#endif
		if (i_mpi==0) write_vect("etar", etar, NR, "eta(r) : magnetic diffusivity as a function of r");
	}
	for (i=NG; i<=NM; i+=(NM-NG)) {		// look for discontinuities at the interfaces.
		if ((i-2 >= irs) && (i+2 <= ire)) {
			if ( (etar[i-1] != etar[i+1]) && (etar[i-2] == etar[i-1]) && (etar[i+1] == etar[i+2]) ) {
				#ifdef XS_DEBUG
					PRINTF0(" + discontinuity found at r=%f (ir=%d)\n", r[i], i);
				#endif
				etar[i] = 2.*etar[i-1]*etar[i+1]/(etar[i-1] + etar[i+2]);	// ETA is the harmonic mean (for poloidal)
			}
		}
	}
	#define ETA etar[i]
#else
	#define ETA eta
#endif

/* POLOIDAL MATRIX */
/// Boundary conditions
///	r[ire] : T=0, dP/dr= -(l+1)/r P  (outer insulator) => only P is computed.
///	r[irs]==0 : T=0, P=0  => not computed at i=0.
/// r[irs]!=0 : T=0, dP/dr= l/r P  (inner insulator)
	int i0 = Blm.ir_bci;
	if (r[i0] == 0.0) i0 += 1;
	MBp.alloc(i0, Blm.ir_bco, LMAX);
	MBp_1.alloc(i0, Blm.ir_bco, LMAX);

	for(i=i0; i<=Blm.ir_bco; i++) {
		if ((i==Blm.ir_bci) || (i==Blm.ir_bco)) {
			if (i==Blm.ir_bci) {	// poloidal BC : dP/dr = l/r P  - (2l+1)/r Pin => allows to aproximate d2P/dr2 with only 2 points. (Pin is imposed from inside)
				MBp.set_Laplace_bc(i, 0.0, -r[i], 0.5*ETA);		// ghost point : imposed field Pin * (2l+1).
				double f = (0.5*ETA)*2*(r_2[i] - 1.0/(r[i]*(r[i+1]-r[i])));		// only diagonal depends on l
				for (int l=0; l<=LMAX; l++)	MBp.add_di(i,l, l*f );
			} else {	// poloidal BC : dP/dr = -(l+1)/r P  + (2l+1)/r Pout => allows to aproximate d2P/dr2 with only 2 points (Pout is imposed from outside)
				MBp.set_Laplace_bc(i, 0.0, r[i], 0.5*ETA);		// ghost point = imposed field Pout * (2l+1).
				double f = (0.5*ETA)*2*(r_2[i] - 1.0/(r[i]*(r[i-1]-r[i])));		// only diagonal depends on l
				for (int l=0; l<=LMAX; l++)	MBp.add_di(i,l, -(l+1)*f );
			}
		} else
			MBp.set_Laplace(i, 0.5*ETA);
	}

/* TOROIDAL MATRIX */
	MBt.alloc(Blm.ir_bci+1, Blm.ir_bco-1, LMAX);
	MBt_1.alloc(Blm.ir_bci+1, Blm.ir_bco-1, LMAX);
	for(i=Blm.ir_bci+1; i<Blm.ir_bco; i++) {
		MBt.set_Laplace(i, 0.5*ETA);
	}

#ifdef XS_ETA_VAR
	for(i=irs+1; i<ire; i++) {
		double deta = Gr[i].l*etar[i-1] + Gr[i].d*etar[i] + Gr[i].u*etar[i+1];
								MBt.add_lo(i,   0.5*deta*Wr[i].l );
		for (l=0; l<=LMAX; l++) MBt.add_di(i,l, 0.5*deta*Wr[i].d );
								MBt.add_up(i,   0.5*deta*Wr[i].u );
	}
	for (i=NG; i<=NM; i+=(NM-NG)) {		// look for discontinuities at the interfaces.
		if ((i-2 >= irs) && (i+2 <= ire)) {
			if ( (etar[i-1] != etar[i+1]) && (etar[i-2] == etar[i-1]) && (etar[i+1] == etar[i+2]) ) {
				double eta_m = 0.5*(etar[i-1] + etar[i+1]);		// mean
				dx_2 = r[i+1]-r[i-1];		dx_2 = 4.0/(dx_2 * dx_2);
										MBt.set_lo(i,    0.5*etar[i-1]*(r[i-1]*r_1[i])*dx_2 );
				for (l=0; l<=LMAX; l++)	MBt.set_di(i,l, -0.5*eta_m*(dx_2+dx_2 + r_2[i]*(l*(l+1))) );
										MBt.set_up(i,    0.5*etar[i+1]*(r[i+1]*r_1[i])*dx_2 );

				MBt.copy_r(i+1, MBp);		// deta is zero before and after the interface
				MBt.copy_r(i-1, MBp);
			}
		}
	}
#endif
#undef ETA
}

void init_Coriolis_matrix()
{
	// SH matrices required for Coriolis force.
	Mcor = (double*) malloc(sizeof(double)*5*NLM);
	if (Mcor==0) runerr("[init_Coriolis_matrix] allocation error 1");
	Mm_l2 = Mcor + 4*NLM;
	mul_ct_matrix(shtns, Mcor + 2*NLM);
	if (Mcor[4*NLM-1] != 0.0) runerr("ERROR: mul_ct_matrix returns wrong result. Consider using shtns 2.8.1+");
	for (long i=0; i<NLM; i++) {
		long l = shtns->li[i];
		Mcor[4*i+2] = l_2[l]*Mcor[2*(i+NLM)]   * (1-l*l);		// for dP/dr
		Mcor[4*i+3] = l_2[l]*Mcor[2*(i+NLM)+1] * (-l*(l+2));
		Mcor[4*i]   = Mcor[4*i+2] * (1-l);		// for P/r
		Mcor[4*i+1] = Mcor[4*i+3] * (l+2);
	}
	for (long m=0, i=0; m<=MMAX*MRES; m+=MRES) {
		for (long l=m; l<=LMAX; l++, i++) {
			Mm_l2[i] = l_2[l] * m;		// m/(l*(l+1))
		}
	}
}


/// Initialize semi-implicit part of Velocity equation.
///      matrix   MUt = (1/dt + 0.5*nu*Lap)	  	MUp = -(1/dt + 0.5*nu*Lap)*Lap
/// and  matrix MUt_1 = (1/dt - 0.5*nu*Lap)^(-1)	MUp_1 = -((1/dt - 0.5*nu*Lap)*Lap)^(-1)
/// BC : boundary condition, can be BC_NO_SLIP or BC_FREE_SLIP
/// \todo FIXME : bc for r[NG] = 0 (no inner-core) !!!
void init_Umatrix(PolTor &Ulm, double nu)
{

	init_Coriolis_matrix();

	if (nu <= 0.) runerr("diffusivity should be strictly positive.");

	MU_Lr.alloc(NG, NM, LMAX);		// allocate the full range of r to avoid array overflows with free-slip.
	MU_LLr.alloc(NG, NM, LMAX);		// boundary conditions should be taken care of below (MUt).
#ifdef XS_O4
	for (int i=NG+1; i<=NM-1; i++) {
		double d1r[5], d2r[5], d3r[5], d4r[5];
		if (i==NG+1) {
			fd_deriv_o4_bc(r, i, i-1, (Ulm.bci > BC_NO_SLIP) ? 2 : 1, d1r, d2r, d3r, d4r);
		} else
		if (i==NM-1) {
			fd_deriv_o4_bc(r, i, i+1, (Ulm.bco > BC_NO_SLIP) ? 2 : 1, d1r, d2r, d3r, d4r);
		} else {
			fd_deriv_o4(r, i, d1r, d2r, d3r, d4r);
		}
		MU_Lr.set_Laplace4(i, d1r, d2r);
		MU_LLr.set_BiLaplace4(i, d1r, d2r, d3r, d4r, 0.0, 0.5*nu);
	}
#else
	for (int i=NG+1; i<=NM-1; i++) {
		double gr[9], Lr[9];
		if (i==NG+1) {
			fd_deriv_o2_bc(r[i]-r[i-1], (Ulm.bci > BC_NO_SLIP) ? 2 : 1, gr, Lr);
		} else {
			fd_deriv_o2(r, i-1, gr, Lr);
		}
		fd_deriv_o2(r, i, gr+3, Lr+3);
		if (i==NM-1) {
			fd_deriv_o2_bc(r[i]-r[i+1], (Ulm.bco > BC_NO_SLIP) ? 2 : 1, gr+6, Lr+6);
		} else {
			fd_deriv_o2(r, i+1, gr+6, Lr+6);
		}
		for (int k=0; k<9; k++) Lr[k] += 2.0*gr[k]*r_1[i-1+(k/3)];	// radial Laplace operator
		if (r[i-1] == 0.0) 	for (int k=0; k<3; k++) Lr[k] = 0.0;	// r=0 : Laplace(l=1) is zero, others are not allowed anyway.

		MU_Lr.set_Laplace(i);
		MU_LLr.set_BiLaplace2(i, Lr, Lr+3, Lr+6, 0.5*nu);
	}
#endif

/// r=0 constraint :
///	T=0, P=0  => not computed at i=0.
///	for l=1 : d2/dr2 P = 0
///	for l>1 : dP/dr = 0
/// Boundary conditions (NO SLIP)
///	P=0, T=0, dP/dr = 0  => not computed at boundary
///	with DeltaOmega (couette), at inner core : T(l=1,m=0) = r.DeltaOmega*Y10_ct
/// Boundary conditions (FREE SLIP)
///	P=0, d2/dr2 P = 0, d(T/r)/dr = 0  => only T computed at boundary


/// TOROIDAL
/// (d/dt - NU.Lap) Ut = Poloidal(curl_NL)
	int irs=NG+1;
	int ire=NM-1;
	if ( (Ulm.bci > BC_NO_SLIP) && (r[NG] != 0.0) ) irs--;
	if (Ulm.bco > BC_NO_SLIP) ire++;
	MUt.alloc(irs, ire, LMAX);
	MUt_1.alloc(irs, ire, LMAX);

	MUt.set_op(0.0, 0.5*nu, MU_Lr);		// Laplace radial (bulk)
	for (int i=irs; i<=ire; i+=ire-irs) {
		if ((i==NG) || (i==NM)) {
			MUt.set_Laplace_bc(i,  -1.0/r[i], 1.0,  0.5*nu);		// BC toroidal (free-slip) : d(T/r)/dr = 0 =>  dT/dr = T/r
		}
	}
#ifdef XS_O4
	for(int i=irs; i<=ire; i++) {
		double d1r[5], d2r[5], d3r[5], d4r[5];
		if ((i==NG) || (i==NM)) {
			MUt.set_Laplace_bc(i,  -1.0/r[i], 1.0,  0.5*nu);		// BC toroidal (free-slip) : d(T/r)/dr = 0 =>  dT/dr = T/r
		} else {
			fd_deriv_o4(r, i, d1r, d2r, d3r, d4r);
			MUt.set_Laplace4(i, d1r, d2r, 0.5*nu);
		}
	}
#else
	for(int i=irs; i<=ire; i++) {
		if ((i==NG) || (i==NM)) {
			MUt.set_Laplace_bc(i,  -1.0/r[i], 1.0,  0.5*nu);		// BC toroidal (free-slip) : d(T/r)/dr = 0 =>  dT/dr = T/r
		} else {
			MUt.set_Laplace(i, 0.5*nu);
		}
	}
#endif

/// POLOIDAL
/// (d/dt.Lap - NU.Lap.Lap) Up = Toroidal(curl_NL)
	MUp.alloc(NG+1, NM-1, LMAX);
	MUp_1.alloc(NG+1, NM-1, LMAX);

	#ifdef XS_HYPER_DIFF
		double* nu_el;
		nu_el = (double*) malloc((LMAX+1) * sizeof(double));
		if (nu_el==0) runerr("[init_Umatrix] allocation error 0");
		int l0 = calc_hyper_diff(nu_el, h_nu);
		if (l0 < LMAX) {
			PRINTF0("=> Hyper-viscosity: starting at l=%d, max viscosity factor=%lg\n", l0, nu_el[LMAX]);
			if (i_mpi==0) write_vect("nu_el", nu_el, LMAX+1, "nu(l) : viscosity factor as a function of l");
			for (int i=irs; i<=ire; i++)	MUt.scale(i, nu_el);
			for (int i=NG+1; i<=NM-1; i++)	MU_LLr.scale(i, nu_el);
		}
		free(nu_el);
	#endif

/*
	Ulm.WrP = (struct TriDiag *) malloc(4*nru * sizeof(struct TriDiag))  - NG;		// shift to access with ir
	Ulm.WrT = Ulm.WrP + nru;		Ulm.LrP = Ulm.WrP + 2*nru;		Ulm.LrT = Ulm.WrP + 3*nru;
	memcpy(&(Ulm.WrP[NG].l), &(Wr[NG].l), nru*sizeof(struct TriDiag));		// copy generic operators
	memcpy(&(Ulm.WrT[NG].l), &(Wr[NG].l), nru*sizeof(struct TriDiag));
	memcpy(&(Ulm.LrP[NG].l), &(Lr[NG].l), nru*sizeof(struct TriDiag));
	memcpy(&(Ulm.LrT[NG].l), &(Lr[NG].l), nru*sizeof(struct TriDiag));


// use boundary conditions to customize operators:
	int ir = NG;
	for (int ir=NG; ir<=NM; ir+=NM-NG) {
		int BC, ii, ig;
		BC = bco;	ii = -1;	ig = 1;		// values if ir==ir_bco
		if (ir==ir_bci) {
			BC = bci;	ii = +1;	ig = -1;
		}
		double* WP = &(Ulm.WrP[ir].d);
		double* WT = &(Ulm.WrT[ir].d);
		double* LP = &(Ulm.LrP[ir].d);
		double* LT = &(Ulm.LrT[ir].d);
		double dr_1 = 1.0/(r[ir+ii]-r[ir]);
		double r_1 = 1.0/r[ir];
		double dr_2 = dr_1*dr_1;
		switch(BC) {
			case BC_ZERO :
			case BC_NO_SLIP :	// Velocity field (no slip => Pol,Tor,dP/dr prescribed)
				WP[ig] = 1.0;			WP[0] = r_1;			WP[ii] = 0.0;		// Pol/r + dP/dr  [dP/dr stored at ig]
				WT[ig] = 0.0;			WT[0] = (r_1 - dr_1);	WT[ii] = dr_1;		// order 1 approx
				LP[ig] = 2*(r_1-dr_1);	LP[0] = -2*dr_2; 		LP[ii] = 2*dr_2;
				break;
			case BC_FREE_SLIP :	// Velocity field (free slip BC) : Pol = 0, dT/dr = Tor/r, S = dP/dr
				WP[ig] = 0.0;	WP[0] = 0.0;		WP[ii] = dr_1;
				WT[ig] = 0.0;	WT[0] = 2.0*r_1;	WP[ii] = 0.0;		// dT/dr = Tor/r
				LP[ig] = 0.0;	LP[0] = 0.0;		LP[ii] = 2*ri_1*dr_1;
				LT[ig] = 0.0;	LT[0] = 2*(r_1*(r_1-dr_1)-dr_2);	LT[ii] = 2*dr_2;
				break;
		}
	}
*/
}

void init_Tmatrix(ScalarSH &Tlm, LOp3l &M, LOp3l_LU &M_1, double kappa)
{
/// Boundary conditions
///	r[ire] : FIXED_TEMP: T=0, FIXED_FLUX: dT/dr = 0.
///	r[irs]==0 : T=0 (for l>0) => not computed at i=0.
/// r[irs]!=0 : FIXED_TEMP: T=0, FIXED_FLUX: dT/dr = 0.
		// central condition : T=0 (l>0); dT/dr = 0 (even for l=1)
		// should be T=0 (don't compute) but for l=0... => requires 2 separate matrices ?
		// at r=0, the temperature equation reduces to dT/dt = S + k.Lap(T)
		// if you use a developement around the conductive profile, we have dT/dt = 0

	int irs = Tlm.ir_bci+1;		// temperature field limits.
	int ire = Tlm.ir_bco-1;
	if ((r[Tlm.ir_bci] == 0.0) || (Tlm.bci != BC_FIXED_TEMPERATURE)) irs = Tlm.ir_bci;
	if (Tlm.bco != BC_FIXED_TEMPERATURE) ire = Tlm.ir_bco;
	if (kappa <= 0.) runerr("diffusivity should be strictly positive.");

	M.alloc(irs, ire, LMAX);
	M_1.alloc(irs, ire, LMAX);

	for(int i=irs; i<=ire; i++) {
		if ((i==Tlm.ir_bci) || (i==Tlm.ir_bco)) {
			M.set_Laplace_bc(i,  0.0, 1.0,  0.5*kappa);		// ghost point = imposed flux dT/dr (may be zero).
		} else {
			M.set_Laplace(i, 0.5*kappa);
		}
	}

	#ifdef XS_HYPER_DIFF
		double* kappa_el;	/// thermal diff as a function of l (for hyperdiffusivity).
		kappa_el = (double*) malloc((LMAX+1) * sizeof(double));
		if (kappa_el==0) runerr("[init_Tmatrix] allocation error");
		int l0 = calc_hyper_diff(kappa_el, h_kappa);
		if (l0 < LMAX) {
			PRINTF0("=> Hyper-thermal-diff: starting at l=%d, max diff factor=%lg\n", l0, kappa_el[LMAX]);
			#ifdef XS_DEBUG
				if (i_mpi==0) write_vect("kappa_el", kappa_el, LMAX+1, "kappa(l) : thermal diff factor as a function of l");
			#endif
			for(int i=irs; i<=ire; i++)		M.scale(i, kappa_el);
		}
		free(kappa_el);
	#endif
}

	/* Special Terms */
/*
void axial_rot_advection(int ir, double Omega_z, cplx* Alm, cplx* NLlm)
{
	int lm=0; 	do {
		NLlm[lm] = 0.0;
	} while(++lm <= LMAX);
	for (int im=1; im<=MMAX; im++) {
		double mOm = -Omega_z * im*MRES;
		for (int l=im*MRES; l<=LMAX; l++) {
			NLlm[lm] = cplx(0,mOm)* Alm[lm];
			lm++;
		}
	}
}
*/
/// As the induction of an axial rotation does not require SH transforms,
/// we compute it lately.
void Axial_rot_induction(PolTor &NL, SolidBody& sb, const PolTor &Blm, StatSpecVect *B0lm = NULL)
{
	double Omega_z;
	cplx *QST;
	unsigned short *mis;
	unsigned *lms;
	int nj = 0;
	int irs = sb.irs;
	int ire = sb.ire;
	if (irs > ire) return;		// no solid body (boundary only).

	Omega_z = sb.Omega_z;
	if ((Omega_z == 0.0) || (sb.Omega_x != 0.0) || (sb.Omega_y != 0.0)) return;	// zero or already computed.	

	if ((B0lm) && (B0lm->mmax > 0)) {		// we must advect the base field.
		nj = B0lm->nlm;
		QST = B0lm->QST;
		mis = B0lm->mi;
		lms = B0lm->lm;
	}

	if (irs < NL.irs) irs = NL.irs;
	if (ire > NL.ire) ire = NL.ire;

	#pragma omp for schedule(static) nowait
	for (int ir=irs; ir<=ire; ir++) {
		cplx* Bpr = Blm.Pol[ir];		cplx* NLpr = NL.Pol[ir];
		cplx* Btr = Blm.Tor[ir];		cplx* NLtr = NL.Tor[ir];
		int lm=0; 	do {
			NLpr[lm] = 0.0;		NLtr[lm] = 0.0;		// m=0
		} while(++lm <= LMAX);
		for (int im=1; im<=MMAX; im++) {
			double mOm = -Omega_z * im*MRES;
			for (int l=im*MRES; l<=LMAX; l++) {
				NLpr[lm] = cplx(0,mOm)* Bpr[lm];
				NLtr[lm] = cplx(0,mOm)* Btr[lm];
				lm++;
			}
		}
		for (int j=0; j<nj; j++) {
			double mOm = -Omega_z * mis[j];
			int lm = lms[j];
			NLpr[lm] += cplx(0,mOm) * QST[(ir*nj +j)*3] * r[ir]*l_2[lm];
			NLtr[lm] += cplx(0,mOm) * QST[(ir*nj +j)*3 + 2];
		}
	}
}

/// As the advection by an axial rotation does not require SH transforms,
/// we compute it lately.
void Axial_rot_advection(ScalarSH& NL, SolidBody& sb, const ScalarSH& Tlm, StatSpecScal *S0lm = NULL)
{
	double Omega_z;
	cplx *S;
	unsigned short *mis;
	unsigned *lms;
	int nj = 0;
	int irs = sb.irs;
	int ire = sb.ire;
	if (irs > ire) return;		// no solid body (boundary only).

	Omega_z = sb.Omega_z;
	if ((Omega_z == 0.0) || (sb.Omega_x != 0.0) || (sb.Omega_y != 0.0)) return;	// zero or already computed.

	if ((S0lm) && (S0lm->mmax > 0)) {		// we must advect the base field.
		nj = S0lm->nlm;
		S = S0lm->TdT;
		mis = S0lm->mi;
		lms = S0lm->lm;
	}

	if (irs < NL.irs) irs = NL.irs;
	if (ire > NL.ire) ire = NL.ire;

	#pragma omp for schedule(static) nowait
	for (int ir=irs; ir<=ire; ir++) {
		cplx* Tr = Tlm[ir];		cplx* NLr = NL[ir];
		int lm=0; 	do {
			NLr[lm] = 0.0;		// m=0
		} while(++lm <= LMAX);
		for (int im=1; im<=MMAX; im++) {
			double mOm = -Omega_z * im*MRES;
			for (int l=im*MRES; l<=LMAX; l++) {
				NLr[lm] = cplx(0,mOm)* Tr[lm];
				lm++;
			}
		}
		for (int j=0; j<nj; j++) {
			double mOm = -Omega_z * mis[j];
			int lm = lms[j];
			NLr[lm] += cplx(0,mOm) * S[(ir*nj +j)*2];
		}
	}
}


/// As the buoyancy from a radial gravity field does not require SH transforms,
/// we compute it lately.
void Radial_gravity_buoyancy(PolTor &NL, const ScalarSH &Tlm, const double* Grav0_r, const double factor = 1.0)
{
	int irs = Tlm.irs;
	int ire = Tlm.ire;
	int lm0 = 0;
	int lm1 = NLM-1;

	thread_interval_lm(lm0, lm1);
	if (lm0 == 0) lm0=1;					// no l=0 contribution.

	if (irs < NL.irs) irs = NL.irs;
	if (ire > NL.ire) ire = NL.ire;
	thread_interval_rad(irs, ire);

	for (int ir=irs; ir<=ire; ir++) {
		v2d* Tr = (v2d*) Tlm[ir];		v2d* NLp = (v2d*) NL.Tor[ir];		// pol & tor are exchanged !
		s2d galpha = vdup(factor * Grav0_r[ir]);		// here we assume only l=0 is present.
		LM_LOOP2( lm0, lm1,  NLp[lm] += galpha * Tr[lm];  )			// no l=0 contribution.
		// TODO: add T0lm
	}
	#pragma omp barrier
}

/// As the buoyancy from a radial gravity field does not require SH transforms,
/// we compute it lately.
void Radial_gravity_buoyancy(PolTor &NL, const ScalarSH &Tlm, const ScalarSH &Clm, const double* Grav0_r)
{
	int irs = Tlm.irs;
	int ire = Tlm.ire;
	int lm0 = 0;
	int lm1 = NLM-1;

	thread_interval_lm(lm0, lm1);
	if (lm0 == 0) lm0=1;					// no l=0 contribution.

	if (irs < NL.irs) irs = NL.irs;
	if (ire > NL.ire) ire = NL.ire;
	thread_interval_rad(irs, ire);

	if (evol_ubt & EVOL_C) {
		for (int ir=irs; ir<=ire; ir++) {
			v2d* Tr = (v2d*) Tlm[ir];		v2d* NLp = (v2d*) NL.Tor[ir];		// pol & tor are exchanged !
			s2d galpha = vdup(Grav0_r[ir]);		// here we assume only l=0 is present.
			v2d* Cr = (v2d*) Clm[ir];
			LM_LOOP2( lm0, lm1,  NLp[lm] += galpha * (Tr[lm] + Cr[lm]);  )			// no l=0 contribution.
			// TODO: add T0lm, C0lm
		}
	} else {
		for (int ir=irs; ir<=ire; ir++) {
			v2d* Tr = (v2d*) Tlm[ir];		v2d* NLp = (v2d*) NL.Tor[ir];		// pol & tor are exchanged !
			s2d galpha = vdup(Grav0_r[ir]);		// here we assume only l=0 is present.
			LM_LOOP2( lm0, lm1,  NLp[lm] += galpha * Tr[lm];  )			// no l=0 contribution.
			// TODO: add T0lm
		}
	}
	#pragma omp barrier
}


/// If we have free-slip boundaries everywhere, we must ensure angular momentum conservation !
/// So we simply remove the angular momentum.
void conserve_momentum(PolTor& Ulm, int kill_sbr)
{
	static int subtract = 0;
	static cplx Wxy0 = 0;
	static double Wz0 = 0;
	static double n;

	cplx Wxy;		// -Wx + I Wy
	double Wz;
	int ir, irs, ire;

	Wxy = 0;		Wz = 0;
	irs = Ulm.irs;		ire = Ulm.ire;
	for (ir=irs; ir<=ire; ir++) {
		double dV = r[ir]*r[ir]*r[ir] * Ulm.delta_r(ir);
		Wz += dV* Ulm.Tor[ir][LiM(1,0)].real();
		if ((MRES == 1)&&(MMAX > 0))
			Wxy += dV * Ulm.Tor[ir][LiM(1,1)];
	}
	#ifdef XS_MPI
		cplx tmp[4];
		tmp[0] = Wxy;		tmp[1] = Wz;
		MPI_Allreduce(tmp, tmp+2, 3, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
		Wxy = tmp[2];		Wz = tmp[3].real();
		if (Ulm.share_dn) irs--;	// also update halo.
		if (Ulm.share_up) ire++;
	#endif

	if (subtract == 0) {
		double ri = r[Ulm.ir_bci];		double ro = r[Ulm.ir_bco];
		n = 5.0/(ro*ro*ro*ro*ro - ri*ri*ri*ri*ri);		// normalization
		if (kill_sbr > 1) {
			Wxy0 = Wxy;			Wz0 = Wz;		// keep initial angular momentum (otherwise it is set to zero).
		}
		double c = (8.*M_PI)/3.;
		subtract = 1;
		PRINTF0("   + conserve angular momentum of (%g,%g,%g)\n", real(Wxy0)*c/Y11_st, -imag(Wxy0)*c/Y11_st, Wz0*c/Y10_ct);
	} else {
		Wxy = (Wxy-Wxy0)*n;		Wz = (Wz-Wz0)*n;
		// subtract solid body rotation from field.
		for (ir=irs; ir<=ire; ir++) {
			Ulm.Tor[ir][LiM(1,0)] -= Wz*r[ir];
			if ((MRES == 1)&&(MMAX > 0))
				Ulm.Tor[ir][LiM(1,1)] -= Wxy*r[ir];
		}
	}
}

/// Magnetic torque computed using surface expression.
double calc_TorqueMag_surf(PolTor &Blm, StatSpecVect *B0lm, int ir)
{
	cplx *Q;
	cplx *S;
	cplx *T;
	double *br, *bt, *bp;
	double torque;

	Q = (cplx *) fftw_malloc( sizeof(double) * (6*NLM + 3*shtns->nspat) );
	if (Q==0) runerr("[calc_TorqueMag_surf] allocation error");
	S = Q +NLM;		T = Q +2*NLM;
	br = (double*)(T + NLM);
	bt = br + shtns->nspat;			bp = br + 2*shtns->nspat;

	Blm.RadSph(ir, Q, S);
	LM_LOOP(  T[lm] = Blm.Tor[ir][lm];  )		// we need a copy here.
	if (B0lm) {
		int nj = B0lm->nlm;
		unsigned* lma = B0lm->lm;
		cplx* QST = B0lm->QST + ir*nj*3;	//QST[ir*nlm*3 + 3*j]
		for (int j=0; j<nj; j++) {		// Add Background Spectral
			int lm = lma[j];
			Q[lm] += QST[j*3];
			S[lm] += QST[j*3+1];
			T[lm] += QST[j*3+2];
		}
	}
	SHqst_to_spat(shtns, Q, S, T, br, bt, bp);

	for(int j=0; j<NLAT*NPHI; j++)
		bt[j] = bp[j]*br[j]*st[j%NLAT];

	spat_to_SH_l(shtns, bt, Q, 0);
	torque = Q[0].real() * 4*M_PI/Y00_1  * r[ir]*r[ir]*r[ir];
	fftw_free(Q);
	return(torque);
}

// TODO: check this function !
double calc_TorqueVisc(PolTor & Ulm, int outer=0)
{
	double torque = 0.0;
	double T0, T1;
	double dx_1, r2;
	const int lm = LM(1,0);
	int ir,ir1;

	if (outer) {
		if (Ulm.bco == BC_FREE_SLIP) return 0.0;
		ir = Ulm.ir_bco;
		ir1 = ir-1;
	} else {
		if (Ulm.bci == BC_FREE_SLIP) return 0.0;
		ir = Ulm.ir_bci;
		ir1 = ir+1;
	}
	// Gamma_z = mu * 8*pi/3 * r^3 * (dT/dr-T/r) / Y10_ct
	//         = mu * 8*pi/3 * r^2 * (r*dT/dr - T) / Y10_ct
	T0 = Ulm.Tor[ir][lm].real();
	T1 = Ulm.Tor[ir1][lm].real();
	dx_1 = r[ir]/(r[ir1]-r[ir]);
	r2 = r[ir]*r[ir];
	torque = ((T1-T0)*dx_1 - T0)*r2 * (8*M_PI/3)/Y10_ct;		// first order approx.

	return torque;
}


/// compute the non-linear term associated with coriolis force without SH transform, and add it to NL.
/// [tested for m=0 and m=1]
void Coriolis_force_add(PolTor &NL, const PolTor &Ulm, double Omega0, void* buf=0)
{
	s2d Wz0;
	int irs, ire;
	v2d** Up = (v2d**) Ulm.Pol;
	v2d** Ut = (v2d**) Ulm.Tor;
	v2d** NLp = (v2d**) NL.Pol;
	v2d** NLt = (v2d**) NL.Tor;
	v2d *GradTP;

	int lm0 = 0;
	int lm1 = NLM-1;
	thread_interval_lm(lm0, lm1);

	if (buf) {
		GradTP = (v2d*) buf;
	} else {
		GradTP = (v2d*) fftw_malloc( (2*NLM+2)*sizeof(v2d) );
		#ifdef XS_DEBUG
		if (GradTP==0) runerr("[Coriolis_force_add] allocation error 0");
		#endif
	}

	#ifdef XS_ELLIPTIC
		#error "Linear Coriolis not supported with Elliptic BC"
		runerr("Linear Coriolis not supported with Elliptic BC");
	#endif
	Wz0 = vdup(Omega0 + Omega0);
	if (lm0 == 0) {
		lm0 = 1;		// l=0 is zero
		GradTP[0] = vdup(0.);		GradTP[1] = vdup(0.);		// allow overflow.
	}
	if (lm1 == NLM-1) {
		GradTP[2*NLM] = vdup(0.);		GradTP[2*NLM+1] = vdup(0.);		// allow overflow.
	}
	irs = Ulm.ir_bci+1;		ire = Ulm.ir_bco-1;
	if (Ulm.bci > BC_NO_SLIP) irs--;
	if (Ulm.bco > BC_NO_SLIP) ire++;
	mpi_interval(irs, ire);

	thread_interval_rad(irs, ire);
	for (int ir=irs; ir<=ire; ir++) {
		s2d vr_1 = vdup(r_1[ir]);	s2d vr_2 = vdup(r_2[ir]);
		s2d dl = vdup(Lr[ir].l);		s2d dd = vdup(Lr[ir].d);		s2d du = vdup(Lr[ir].u);
		if ((ir==Ulm.ir_bci) || (ir==Ulm.ir_bco)) {
			int BC = Ulm.bci;
			int ii = ir+1;
			int ig = ir-1;
			if (ir==Ulm.ir_bco) {
				BC = Ulm.bco;		ii = ir-1;		ig = ir+1;
			}
			s2d dr_1 = vdup(1.0/(r[ir]-r[ii]));
			s2d dr_2 = dr_1*dr_1;
			if (BC <= BC_NO_SLIP) {		// NO-SLIP
				LM_LOOP2 ( lm0, lm1,
					GradTP[2*lm]   = dr_1 * (Ut[ir][lm] - Ut[ii][lm]);		// grad(Ut) [order 1 approx]
					GradTP[2*lm+1] = Up[ig][lm];		// grad(Up) prescribed by ghost shell.
				)
				dr_2 += dr_2;
				dd = -dr_2;		dl = dr_2;		du = dr_2;
				if (ir==Ulm.ir_bci)  dl = vdup(2.)*(dr_1 + vr_1);		// [dP/dr stored at ir-1]
				else 				du = vdup(2.)*(dr_1 + vr_1);		// [dP/dr stored at ir+1]
			} else {					// FREE-SLIP
				LM_LOOP2 ( lm0, lm1,
					GradTP[2*lm]   = vr_1 * Ut[ir][lm];					// grad(Ut) : dT/dr = Tor/r
					GradTP[2*lm+1] = dr_1 * (Up[ir][lm] - Up[ii][lm]);		// grad(Up) [order 1 approx]
				)
				dr_2 = (vr_1+vr_1)*dr_1;
				dl = vdup(0.);		dd = vdup(0.);		du = vdup(0.);
				if (ir==Ulm.ir_bci)  du = -dr_2;
				else 				dl = -dr_2;
			}
		} else {
			s2d gl = vdup(Gr[ir].l);		s2d gd = vdup(Gr[ir].d);		s2d gu = vdup(Gr[ir].u);
			LM_LOOP2 ( lm0, lm1,		// precompute gradient
				GradTP[2*lm]   = gl*Ut[ir-1][lm] + gd*Ut[ir][lm] + gu*Ut[ir+1][lm];		// grad(Ut)
				GradTP[2*lm+1] = gl*Up[ir-1][lm] + gd*Up[ir][lm] + gu*Up[ir+1][lm];		// grad(Up)
			)
		}
		#if XS_OMP == 2
		#pragma omp barrier
		#warning "Linear Coriolis may not work with xsbig_hyb2"
		#endif
		for (int lm=lm0; lm<=lm1; lm++) {
			s2d Mc00 = vdup(Mcor[4*lm]);	s2d Mc01 = vdup(Mcor[4*lm+1]);		// for P/r
			s2d Mc10 = vdup(Mcor[4*lm+2]);	s2d Mc11 = vdup(Mcor[4*lm+3]);		// for dP/dr
			v2d NLtt = - vr_1*( Mc00 * Ut[ir][lm-1] + Mc01 * Ut[ir][lm+1] );
			v2d NLpp = - vr_1*( Mc00 * Up[ir][lm-1] + Mc01 * Up[ir][lm+1] );
			NLtt -= (Mc10 * GradTP[2*(lm-1)]   + Mc11 * GradTP[2*(lm+1)]);
			NLpp -= (Mc10 * GradTP[2*(lm-1)+1] + Mc11 * GradTP[2*(lm+1)+1]);
			if (lm > LMAX) {		// m>0
				NLpp = ADDI( NLpp, vdup(Mm_l2[lm]) * Ut[ir][lm] );
				NLtt = ADDI( NLtt, vdup(-Mm_l2[lm]) * (dl*Up[ir-1][lm] + (dd - vdup(l2[lm])*vr_2)*Up[ir][lm] + du*Up[ir+1][lm]) );
			}
			NLp[ir][lm] += Wz0 * NLpp;
			NLt[ir][lm] += Wz0 * NLtt;
		}
	}
	if (buf==0)	fftw_free(GradTP);
}

#ifdef XS_LEGACY
/// Compute the electric potential field from U, B and eta.
void calc_Electric_Potential(ScalarSH& Vlm, const PolTor& Ulm, const PolTor& Blm)
{
	#ifdef XS_LINEAR
		if ((spat_need & NEED_J) == 0)
			J.alloc(B.irs, B.ire);			// in some cases, allocation is needed here.
	#endif
	Blm.cte_to_curl_spat(J0lm, &J, B.irs, B.ire);		// J+J0 on the whole domain
	Blm.cte_to_spat(B0lm, &B);			// B+B0
	if (evol_ubt & EVOL_U) Ulm.cte_to_spat(U0lm, &U);			// U+U0
	#ifndef XS_LINEAR
		B.NL_Magnetic(&U, &InnerCore, &Mantle, &B);		// B destroyed.
	#else
		B.NL_vect(U0, &B);		// U0 x B
		B.NL_vect_add(&U, B0);	// U x B0
	#endif
	#pragma omp for schedule(static)
	for (int ir=B.irs; ir<=B.ire; ir++) {
		#ifdef XS_ETA_VAR
			double eta = etar[ir];		// variable eta
		#endif
		for (int lm=0; lm < NLAT*NPHI; lm++) {
			B.vr[ir][lm] -= eta * J.vr[ir][lm];
			B.vt[ir][lm] -= eta * J.vt[ir][lm];
			B.vp[ir][lm] -= eta * J.vp[ir][lm];
		}
	}
	Vlm.from_grad_spat(B);				// this is the electric potential.
}
#else
#ifndef XS_LINEAR
/// Compute Electric potential at a given radius r.
void Electric_Potential_shell(const int ir, cplx* Vlm)
{
	spat_vect u,b;
	cplx *Q, *S, *T;
	const size_t nspat = shtns->nspat;
  #ifdef XS_ETA_VAR
	const double eta = etar[ir];		// variable eta
  #else
	const double eta = Xlm.diff[::B];
  #endif
	int uzero = 0;		// flag

	Q = (cplx*) fftw_malloc(sizeof(double)*(6*NLM + 6*nspat));		// alloc aligned memory
	S = Q + NLM;		T = Q + 2*NLM;
	void* mem = u.alloc(nspat, Q + 3*NLM);
	b.alloc(nspat, mem);

	if ((ir >= Ulm.ir_bci) && (ir <= Ulm.ir_bco)) {		// fluid shell
		Ulm.RadSph(ir, Q, S);
		SHV3_SPAT(Q, S, Ulm.Tor[ir], u.r, u.t, u.p);
	} else {	// solid shell
		SolidBody& solid = Mantle;
		if (ir < Ulm.ir_bci) solid = InnerCore;		// solid inner shell
		if ((solid.Omega_x == 0) && (solid.Omega_y == 0) && (solid.Omega_z == 0)) {		// u = 0
			uzero = 1;		// zero velocity field
		} else {
			solid.calc_spatial();
			for (size_t k=0; k<NPHI*NLAT; k++) {		// cross product (theta and phi components only)
				u.r[k] = 0.0;
				u.t[k] = solid.vt_r[k] * r[ir];
				u.p[k] = solid.vp_r[k] * r[ir];
			}
		}
	}
	if (uzero) {
		Blm.curl_QST(ir, Q, S, T);		// J, but only S is needed here
		Vlm[0] = 0.0;
		double mreta = -eta*r[ir];
		for (int lm=1; lm<NLM; lm++)	// l > 0
			Vlm[lm] = mreta*S[lm];
	} else {
		Blm.RadSph(ir, Q, S);
		SHV3_SPAT(Q, S, Blm.Tor[ir], b.r, b.t, b.p);
		Blm.curl_QST(ir, Q, S, T);		// J, but only S is needed here
		cross_prod(u, u, b, 0, NPHI*NLAT);		// u cross b
		SPAT_SHV(u.t, u.p, Q, T);		// keep only Q here
		spat_to_SH_l( shtns, u.r, Vlm, 0 );		// we only need l=0 here, for further integration in radius.
		for (int lm=1; lm<NLM; lm++)	// l > 0
			Vlm[lm] = (Q[lm] - eta*S[lm]) * r[ir];
	}
	fftw_free(Q);
}


/// Compute Electric potential everywhere. Perform radial integration of Electric_potential_shell()
void calc_Electric_Potential(ScalarSH& Vlm, const StateVector& Xlm)
{
	#pragma omp for
	for (int ir=Vlm.irs; ir<Vlm.ire; ir++) {
		Electric_Potential_shell(ir, Vlm[ir]);
	}

	// radial integration of l=0 component.
	#pragma omp barrier
	#pragma omp master
	{
		double sum[2] = {0, 0};		// sum and value at previous point. (start with 0)
		int ir = Vlm.irs;
	    #ifdef XS_MPI
		if (Vlm.share_dn) {
			MPI_Recv(&sum, 2, MPI_DOUBLE, i_mpi-1, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		} else
		#endif
		{
			sum[1] = real(Vlm[ir][0]);		// keep value for next step.
			Vlm[ir][0] = sum[0];
			ir++;
		}
		for (; ir<=Vlm.ire; ir++) {
			double p1 = real(Vlm[ir][0]);
			sum[0] += (sum[1] + p1)*0.5*(r[ir]-r[ir-1]);	// Trapezoidal rule
			Vlm[ir][0] = sum[0];
			sum[1] = p1;
		}
		#ifdef XS_MPI
		if (Vlm.share_up) {
			MPI_Send(&sum, 2, MPI_DOUBLE, i_mpi+1, 0, MPI_COMM_WORLD);
		}
		#endif
	}
	#pragma omp barrier
}
#endif
#endif

/* REFERENCE FRAME */

/// The reference frame, including global rotation, precession, etc...
class RefFrame {
	double Omega0_z;	///< keep track of rotation rate.
	cplx Omega0_xy;
	double eps_xy, eps_z, freq;
	double eps_poincare;
	int flags;
	int lm_forcing;

  public:
	double Omega_z;
	cplx Omega_xy;
	cplx poincare;

    void update(const double t);
	void add_Poincare_force(PolTor& NLu);

	void set_rotation(double Omega0, double angle = 0.0);
	void set_libration(double Omega0, double amplitude, double frequency, char axis = 'z');
	void set_precession(double Omega0, double Omega_P, double angle = M_PI_2);
	void set_nutation(double Omega0, double amplitude, double frequency);
	int check_non_axial();
	int check_inertial();
	int check_time_dep() { return (lm_forcing > 0); }
};

int RefFrame::check_inertial()
{
	if (check_non_axial()) return 0;		// not inertial
	if ((Omega0_z == 0) && (eps_z == 0)) return 1;		// inertial
	return 0;	// not inertial
}

int RefFrame::check_non_axial()
{
	if (flags & 1) {		// non-axial rotation ?
		if ((MRES != 1)||(MMAX <= 0))
			runerr("non-axial rotation requires Mres=1 and Mmax>0");
	}
	return (flags & 1);
}

void RefFrame::update(const double t)
{
	if (lm_forcing) {
		double sin_wt = sin(freq*t);
		double cos_wt = cos(freq*t);
		if (flags & 2) {		// rotating
			poincare = eps_poincare * cplx( sin_wt, -cos_wt );
			Omega_xy = Omega0_xy + eps_xy * cplx( cos_wt, sin_wt );
		} else {		// oscillating
			poincare = eps_poincare * sin_wt;
			Omega_xy = Omega0_xy + eps_xy * cos_wt;
		}
		Omega_z = Omega0_z + eps_z * cos_wt;
	}
}

void RefFrame::set_rotation(double Omega0, double angle)
{
	eps_z = 0.0;	eps_xy = 0.0;	freq = 0;
	flags = 0;		// axial
	PRINTF0("[RefFrame] Global rotation rate %g, angle %.3f deg\n", Omega0, angle*180./M_PI);
	if (angle == 0.0) {
		Omega0_z = Omega0;
		Omega0_xy = 0.0;
	} else {
		Omega0_z = Omega0 * cos(angle);
		Omega0_xy = cplx( Omega0 * sin(angle) , 0.0 );
		flags = 1;		// mark as non-axial.
	}
	lm_forcing = 0;		// no inertial forcing (time independent).
	Omega_z = Omega0_z;
	Omega_xy = Omega0_xy;
	check_non_axial();
}

void RefFrame::set_libration(double Omega0, double amplitude, double frequency, char axis)
{
	set_rotation(Omega0);
	if ((frequency != 0.0) || (amplitude != 0.0)) {
		eps_poincare = amplitude*frequency;
		freq = frequency;
		if (axis == 'z') {
			PRINTF0("[RefFrame] Longitudinal libration with frequency %g, and amplitude %g\n", frequency, amplitude);
			eps_z = amplitude;
			flags = 0;		// axial, oscillating
			lm_forcing = LiM(1,0);		// time-dependent
			eps_poincare *= Y10_ct;		// sh-normalization
		} else {
			PRINTF0("[RefFrame] Latitudinal libration with frequency %g, and amplitude %g\n", frequency, amplitude);
			eps_xy = amplitude;
			flags = 1;		// non-axial, oscillating
			lm_forcing = LiM(1,1);
			eps_poincare *= Y11_st;		// sh-normalization
		}
		check_non_axial();
	}
}

void RefFrame::set_precession(double Omega0, double Omega_P, double angle)
{
	double cos_angle = cos(angle);
	if (fabs(angle-M_PI_2) < 1e-15) cos_angle = 0.0;
	set_rotation(Omega0 + Omega_P*cos_angle);
	PRINTF0("[RefFrame] Precessing at rate %g, angle %.3f deg\n", Omega_P, angle*180./M_PI);
	eps_xy = Omega_P*sin(angle);
	eps_poincare = Omega0*eps_xy;
	freq = Omega0;
	flags = 3;			// mark as non-axial, precessing.
	lm_forcing = LiM(1,1);
	eps_poincare *= Y11_st;		// sh-normalization
	check_non_axial();
}

void RefFrame::set_nutation(double Omega0, double amplitude, double frequency)
{
	set_rotation(Omega0);
	PRINTF0("[RefFrame] Nutation at rate %g, amplitude %g\n", frequency, amplitude);
	eps_xy = amplitude;
	freq = frequency;
	eps_poincare = frequency*eps_xy;
	flags = 3;			// mark as non-axial, precessing.
	lm_forcing = LiM(1,1);
	eps_poincare *= Y11_st;		// sh-normalization
	check_non_axial();
}

void RefFrame::add_Poincare_force(PolTor& NLu)
{
	int lm = lm_forcing;
	if (lm) {
		cplx a = poincare;
		#pragma omp for schedule(static) nowait
		for (int ir=NLu.irs; ir<=NLu.ire; ir++) {
			NLu.Pol[ir][lm] += a*r[ir];
		}
		#pragma omp barrier
	}
}

