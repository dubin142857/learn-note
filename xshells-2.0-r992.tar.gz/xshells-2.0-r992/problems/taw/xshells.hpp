/** \file xshells.hpp
Compile-time parmeters and customizable functions for XSHELLS.
*/

#ifndef XS_H
	/* DO NOT COMMENT */
	#define XS_H

///  EXECUTION CONTROL  ///
/// 1. stable and tested features ///

/* call custom_diagnostic() (defined below) from main loop to perform and store custom diagnostics */
#define XS_CUSTOM_DIAGNOSTICS

/* enable variable time-step adjusted automatically */
#define XS_ADJUST_DT

/* XS_LINEAR use LINEAR computation : no u.grad(u), no J0xB0  */
#define XS_LINEAR

/* Impose arbitrary stationary flow at the boundaries (for Diapir/Monteux) */
//#define XS_SET_BC

/* use variable conductivity profile eta(r) [see definition of profile in calc_eta() below */
#define XS_ETA_PROFILE

/* Variable L-truncation : l(r) = LMAX * sqrt(r/(rmax*VAR_LTR))  +1 */
//#define VAR_LTR 0.5

///  EXECUTION CONTROL  ///
/// 2. unstable and beta features ///

/* Hyperdiffusion : enable enhanced diffusion constants (see xshells.par)*/
//#define XS_HYPER_DIFF

/* enable output magnetic field surface secular variation up to lmax=lmax_out_sv (set in xshells.par) */
//#define XS_WRITE_SV


#ifdef XS_ETA_PROFILE
	// variable magnetic diffusivity is used :
	#define XS_ETA_VAR
#endif

#else

/* TIME-DEPENDANT BOUNDARY FORCING */
/// This function is called before every time-step, and allows you to modify
/// the Pol/Tor components of the velocity field.
/**  Useful global variables are :
 *  a_forcing : the amplitude set in the .par file
 *  w_forcing : the frequency (pulsation) set in the .par file
 *  \param[in] t is the current time.
 *  \param Bi is the inner SolidBody, whose angular velocity can be modified.
 *  \param Bo is the outer SolidBody, whose angular velocity can be modified.
 */
inline void calc_Uforcing(double t, double a_forcing, double w_forcing, struct SolidBody *Bi, struct SolidBody *Bo)
{
	double DeltaOm = a_forcing;

	/*	add // at the begining of this line to uncomment the following bloc.
		#define FORCING_M 1
		DeltaOm = a_forcing;
		t = - w_forcing*t;		// rotation of equatorial spin-axis.
	#define U_FORCING "Inner-core 'spin-over' forcing (l=1, m=1)"
		Bi->Omega_x = DeltaOm * cos(t); 	Bi->Omega_y = -DeltaOm * sin(t);
//	#define U_FORCING "Mantle 'spin-over' forcing (l=1, m=1)"
//		Bo->Omega_x = DeltaOm * cos(t); 	Bo->Omega_y = -DeltaOm * sin(t);
/*  ________
*/

	/*	add // at the begining of this line to uncomment the following bloc.
		#define FORCING_M 0
		if (w_forcing < 0.0)		// Periodic forcing on frequency |w_forcing|
		{
			DeltaOm *= sin(-w_forcing*t);
		}
		else if (w_forcing > 0.0)	// Impulsive forcing on time-scale 2.*pi/w_forcing.
		{
			if (t*w_forcing > 63.) {		// t > 10*2*pi/w_forcing
				DeltaOm = 0.0;
			} else {
				t = (t*w_forcing/(2.*M_PI) - 3.);	//t = (t - 3.*t_forcing)/t_forcing;
				DeltaOm *= exp(-t*t);	//   /(t_forcing*sqrt(pi)); //constant energy forcing.
			}
		}
	#define U_FORCING "Inner-core differential rotation (l=1, m=0)"
		Bi->Omega_z = DeltaOm;		// set differential rotation of inner core.
//	#define U_FORCING "Inner-core equatorial differential rotation (l=1, m=1)"
//		Bi->Omega_x = DeltaOm;		// set differential rotation of inner core.
//	#define U_FORCING "Mantle differential rotation (l=1, m=0)"
//		Bo->Omega_z = DeltaOm;		// set differential rotation of mantle.
//	#define U_FORCING "Mantle differential rotation (l=1, m=1)"
//		Bo->Omega_x = DeltaOm;		// set differential rotation of mantle.
/*  ________
*/

}

#ifdef XS_SET_BC
void set_U_bc(double ampl)
{
	int l,m;

//	/*	add // at the begining of this line to uncomment the following bloc.
	// sinking diapir
//	l=1;	m=0;	set_Ylm(Ulm.Pol[NM+1], l, m, -ampl);		// set u_theta "polar bubble sinking" at the outer boundary.
	l=1;	m=1;	set_Ylm(Ulm.Pol[NM+1], l, m, -ampl);		// set u_theta "equatorial bubble sinking" at the outer boundary.
/*  ________
*/

	/* add // at the begining of this line to uncomment the following bloc.
	// Jupiter

	double *Uth, *Uph;
	double njets = 6.0;		// default number of jets.
	int im,it,ir;

	Uph = fftw_malloc(sizeof(double) * NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	Uth = fftw_malloc(sizeof(double) * NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	ir = NM;	// boundary condition.
		for (im=0; im<NPHI; im++) {
			for (it=0; it<NLAT; it++) {
				Uph[im*NLAT + it] = ampl * r[ir]*st[it] * cos(njets * M_PI*(r[ir]*st[it]-1.));
				Uth[im*NLAT + it] = 0.0;
			}
		}
		spat_to_SHsphtor( shtns, Uth, Uph, Ulm.Pol[ir], Ulm.Tor[ir] );	// go to spectral space.
		for (im=0; im<NLM; im++) Ulm.Pol[ir][im] = 0.0;
	free(Uth);	free(Uph);

/*  ________
*/

}
#endif


#ifdef XS_CUSTOM_DIAGNOSTICS
/// compute custom diagnostics. They can be stored in the diags array (up to ndiags elements), which is written to the energy file.
/// own(ir) is a macro that returns true if the shell is owned by the process (useful for MPI).
/// i_mpi is the rank of the mpi process (0 is the root).
/// This function is called outside a parallel region, so it is safe to use openmp parallel constructs inside.
/// After this function returns, the diags array is summed accross processes and written in the energy.job file.
/// XS_NDIAGS must be set to the number of recorded custom diagnostics.
void custom_diagnostic(diagnostics& all_diags)
{
	double *diags;

//	/*	add // at the begining of this line to uncomment the following bloc.
	if (evol_ubt & EVOL_B) {
		diags = all_diags.append(3, "Eb10, Eb20, Eb_other\t ");		// append array for 2 diagnostics
		double b1 = Blm.energy_lm(1,0);		// get magnetic energy of l=1
		double b2 = Blm.energy_lm(2,0);		// get magnetic energy of l=2
		diags[0] = b1;
		diags[1] = b2;
		diags[2] = all_diags[1] - (b1+b2);		// magnetic energy of everything except l=1 and l=2.
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// energy of Alfvén modes h+ and h-
	if (evol_ubt & (EVOL_U | EVOL_B) == (EVOL_U | EVOL_B)) {
		diags = all_diags.append(2, "Eh+, Eh-\t ");		// append array for 2 diagnostics
		cplx* Qp = (cplx*) malloc(6*NLM*sizeof(cplx));
		cplx* Sp = Qp + NLM;		cplx* Tp = Qp + 2*NLM;
		cplx* Qm = Qp + 3*NLM;
		cplx* Sm = Qm + NLM;		cplx* Tm = Qm + 2*NLM;
		double Ep = 0.0;		double Em = 0.0;
		for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {
			Ulm.RadSph(ir, Qp, Sp);
			Blm.RadSph(ir, Qm, Sm);
			for (int lm=0; lm<NLM; lm++) {
				cplx qp = Qp[lm];		cplx sp = Sp[lm];
				Qp[lm] += Qm[lm];		Sp[lm] += Sm[lm];
				Qm[lm] = qp - Qm[lm];	Sm[lm] = sp - Sm[lm];
				Tp[lm] = Ulm.Tor[ir][lm] + Blm.Tor[ir][lm];
				Tm[lm] = Ulm.Tor[ir][lm] - Blm.Tor[ir][lm];
			}
			double r2dr = r[ir]*r[ir]*Ulm.delta_r(ir);
			double dV = 1.0 * r2dr;
			int lm=0;
			for (int im=0; im<=MMAX; im++) {
				double ep = 0.0;		double em = 0.0;
				for (int l=im*MRES; l<=LMAX; l++, lm++) {
					ep += norm(Qp[lm]) + l2[l]*(norm(Sp[lm]) + norm(Tp[lm]));
					em += norm(Qm[lm]) + l2[l]*(norm(Sm[lm]) + norm(Tm[lm]));
				}
				Ep += ep * dV;		Em += em * dV;
				dV = 2.0 * r2dr;		// count twice (+m and -m)
			}
		}
		diags[0] = Ep;		diags[1] = Em;
		free(Qp);
	}
/*  ________
*/


//	/*	add // at the begining of this line to uncomment the following bloc.
	// mean rotation vector (based on angular momentum, See PhD thesis of J. Noir, page 60-61.)
	if (evol_ubt & EVOL_U) {
		cplx Wxy;
		double Wz, dV;
		double r0 = mp.var["L_rmin"];
		double r1 = mp.var["L_rmax"];
		int ir0, ir1;
		int m1ok = ((MMAX>0)&&(MRES==1));
		diags = all_diags.append(3, "Wx, Wy, Wz\t ");		// append array for 3 diagnostics
		ir0 = r_to_idx(r0);		ir1 = r_to_idx(r1);
		if (Ulm.irs > ir0) ir0 = Ulm.irs;
		if ((ir1 == 0) || (Ulm.ire < ir1)) ir1 = Ulm.ire;
		Wxy=0;	Wz=0;
		for (int ir=ir0; ir<=ir1; ir++) {
			dV = r[ir]*r[ir]*r[ir] * Ulm.delta_r(ir);
			Wz += dV*real(Ulm.Tor[ir][LiM(1,0)]);
			if (m1ok) Wxy += dV*Ulm.Tor[ir][LiM(1,1)];
		}
		double n = (pow(r[Ulm.ir_bco],5)-pow(r[Ulm.ir_bci],5))/5.;	// [r^5/5]
		Wxy /= n*Y11_st;		Wz /= n*Y10_ct;			// spherical harmonic normalization
		diags[0] = real(Wxy);
		diags[1] = -imag(Wxy);
		diags[2] = Wz;
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// Dissipation rates (kinetic and magnetic) : integral of entropy^2 if u=0 at the boundaries.
	if (evol_ubt & EVOL_U) {
		diags = all_diags.append(1, "D_nu\t ");		// append array for 1 diagnostic
		cplx* Q = (cplx*) malloc(3*NLM*sizeof(cplx));
		cplx* S = Q + NLM;		cplx* T = Q + 2*NLM;
		double Dnu = 0.0;
		for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {
			Ulm.curl_QST(ir, Q, S, T);
			double r2dr = r[ir]*r[ir]*Ulm.delta_r(ir);
			double dV = 1.0 * r2dr;
			int lm=0;
			for (int im=0; im<=MMAX; im++) {
				double Dm = 0.0;
				for (int l=im*MRES; l<=LMAX; l++, lm++) {
					Dm += norm(Q[lm]) + l2[l]*(norm(S[lm]) + norm(T[lm]));
				}
				Dnu += Dm * dV;
				dV = 2.0 * r2dr;		// count twice (+m and -m)
			}
		}
		diags[0] = Dnu * jpar.nu;
		free(Q);
	}
	if (evol_ubt & EVOL_B) {
		diags = all_diags.append(3, "D_eta_c, D_eta_m, D_eta_cmb\t ");		// append array for 3 diagnostics
		cplx* Q = (cplx*) malloc(3*NLM*sizeof(cplx));
		cplx* S = Q + NLM;		cplx* T = Q + 2*NLM;
		double Deta[3] = {0.0, 0.0, 0.0};
		for (int ir=Blm.irs; ir<=Blm.ire; ir++) {
			Blm.curl_QST(ir, Q, S, T);
			double r2dr = r[ir]*r[ir]*Blm.delta_r(ir);
			double dV = 1.0 * r2dr;
			double Deta_r = 0.0;
			int lm=0;
			for (int im=0; im<=MMAX; im++) {
				double Dm = 0.0;
				for (int l=im*MRES; l<=LMAX; l++, lm++) {
					Dm += norm(Q[lm]) + l2[l]*(norm(S[lm]) + norm(T[lm]));
				}
				Deta_r += Dm * dV;
				dV = 2.0 * r2dr;		// count twice (+m and -m)
			}
			#ifdef XS_ETA_VAR
			if (ir==NM) {
				Deta_r *= (etar[ir-1]+etar[ir+1])*0.5;
			} else Deta_r *= etar[ir];
			#else
			Deta_r *= eta;
			#endif
			if (ir<NM) Deta[0] += Deta_r;			// split core and mantle dissipations.
			if (ir>NM) Deta[1] += Deta_r;
			if (ir==NM) Deta[2] += Deta_r;
		}
		diags[0] = Deta[0];		diags[1] = Deta[1];		diags[2] = Deta[2];
		free(Q);
	}
/*  ________
*/


}
#endif


#ifdef XS_ETA_PROFILE

/// define magnetic diffusivity eta as a function of r
/// discontinuous profiles supported.
void calc_eta(double eta0)
{
	double etam = mp.var["etam"];		// get parameter "etam" set in xshells.par (zero if not set)

	if (etam > 0) printf("=> Magnetic diffusivity in the mantle set to etam = %g\n",etam);

	for (int i=0; i<NR; i++) {
		etar[i] = eta0;			// eta0 by default.

		// Earth Mantle
		if ((i > NM)&&(etam > 0))		etar[i] = etam; 	// mantle almost insulating
	}
}
#endif


#ifdef XS_WRITE_SV
void write_SV(char *fname, int lmax_out) {
	FILE *fp;
	double d1 = 0.5/dt;
	double d2 = 1.0/(dt*dt);
	double dx = 1.0/(r[NM-1]-r[NM]);
	int im, l, lm;
	int mmax_out = MMAX;

	if (lmax_out > LMAX) lmax_out = LMAX;
	if (MMAX*MRES > lmax_out) mmax_out = lmax_out/MRES;
	fp = fopen(fname, "w");
	fprintf(fp,"%% [XSHELLS] Bpol, dBpol/dt, d2Bpol/dt2, Su, Tu, dSu/dt, dTu/dt spherical Harmonics coefficients.\n%% LMAX=%d, MMAX=%d, MRES=%d", lmax_out, mmax_out, MRES);
	for (im=0; im<=mmax_out; ++im) {
		fprintf(fp,"\n%%  m=%d",im*MRES);
		for (l=im*MRES; l<=lmax_out; ++l) {
			lm = LiM(l,im);
			cplx Bp = Blm.Pol[Bp_i1][lm];
			cplx Bp_dt1 = (Bp - Bp2[lm]) * d1;
			cplx Bp_dt2 = ((Bp + Bp2[lm]) - (Bp1[lm]+Bp1[lm])) * d2;
			fprintf(fp,"\n%.10g %.10g \t%.10g %.10g \t%.10g %.10g",Bp.real(),Bp.imag(), Bp_dt1.real(),Bp_dt1.imag(), Bp_dt2.real(),Bp_dt2.imag());
			if (Ulm.bco == BC_FREE_SLIP) {
				cplx S = Ulm.Pol[Ulm.ire-1][lm] * dx;
				cplx T = Ulm.Tor[Ulm.ire][lm];
				cplx S_dt = (S - Up1[lm]*dx) * d1;
				cplx T_dt = (T - Ut1[lm]) * d1;
				fprintf(fp," \t%.10g %.10g \t%.10g %.10g \t%.10g %.10g \t%.10g %.10g",S.real(),S.imag(), T.real(),T.imag(), S_dt.real(),S_dt.imag(), T_dt.real(),T_dt.imag());
			}
		}
	}
	fclose(fp);
}
#endif

/* DO NOT REMOVE */
#endif
