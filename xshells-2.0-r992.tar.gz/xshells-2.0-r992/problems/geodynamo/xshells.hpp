/** \file xshells.hpp
Compile-time parmeters and customizable functions for XSHELLS.
*/

#ifndef XS_H
	/* DO NOT COMMENT */
	#define XS_H

///  EXECUTION CONTROL  ///
/// 1. stable and tested features ///

/* call custom_diagnostic() (defined below) from main loop to perform and store custom diagnostics */
#define XS_CUSTOM_DIAGNOSTICS

/* enable variable time-step adjusted automatically */
#define XS_ADJUST_DT

/* XS_LINEAR use LINEAR computation : no u.grad(u), no J0xB0  */
//#define XS_LINEAR

/* Impose arbitrary stationary flow at the boundaries (for Diapir/Monteux) */
//#define XS_SET_BC

/* use variable conductivity profile eta(r) [see definition of profile in calc_eta() below */
//#define XS_ETA_PROFILE

/* Variable L-truncation : l(r) = LMAX * sqrt(r/(rmax*VAR_LTR))  +1 */
//#define VAR_LTR 0.5

///  EXECUTION CONTROL  ///
/// 2. unstable and beta features ///

/* Hyperdiffusion : enable enhanced diffusion constants (see xshells.par)*/
//#define XS_HYPER_DIFF



#ifdef XS_ETA_PROFILE
	// variable magnetic diffusivity is used :
	#define XS_ETA_VAR
#endif

#else


#ifdef XS_CUSTOM_DIAGNOSTICS
/// compute custom diagnostics. They can be stored in the all_diags array , which is written to the energy.jobname file.
/// own(ir) is a macro that returns true if the shell is owned by the process (useful for MPI).
/// i_mpi is the rank of the mpi process (0 is the root).
/// This function is called outside an OpenMP parallel region, and it is permitted to use openmp parallel constructs inside.
/// After this function returns, the all_diags array is summed accross processes and written in the energy.jobname file.
void custom_diagnostic(diagnostics& all_diags)
{
	double *diags;

//	/*	add // at the begining of this line to uncomment the following bloc.
	// split energies (in symmetric, anti-symmetric, poloidal, toroidal, ...)
	if (evol_ubt & EVOL_U) {
		diags = all_diags.append(8,		// append array for 8 diagnostics
			"EZu_ps, EZu_pa, EZu_ts, EZu_ta, ENZu_ps, ENZu_pa, ENZu_ts, ENZu_ta\t ");
		Ulm.energy_split(diags);		// store 8 components of the kinetic energy (see energy_split in xshells_spectral.cpp)
	}
	if (evol_ubt & EVOL_B) {
		diags = all_diags.append(8,		// append array for 8 diagnostics
			"EZb_ps, EZb_pa, EZb_ts, EZb_ta, ENZb_ps, ENZb_pa, ENZb_ts, ENZb_ta\t ");
		Blm.energy_split(diags);		// store 8 components of the magnetic energy (see energy_split in xshells_spectral.cpp)
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// for the Nusselt number: record dT/dr[l=0] or T[l=0] at inner/outer radii.
	if (evol_ubt & EVOL_T) {
		int ir = Tlm.ir_bci;	// inner boundary
		if (Tlm.bci == BC_FIXED_TEMPERATURE) {
			diags = all_diags.append(1, "dT/dr(ri) ");
			if (own(ir))  *diags = (real(Tlm[ir+1][0])-real(Tlm[ir][0]))/((r[ir+1]-r[ir])*Y00_1);
		} else {
			diags = all_diags.append(1, "T(ri) ");
			if (own(ir))  *diags = real(Tlm[ir][0]) / Y00_1;
		}
		ir = Tlm.ir_bco;		// outer boundary
		if (Tlm.bco == BC_FIXED_TEMPERATURE) {
			diags = all_diags.append(1, "dT/dr(ro) ");
			if (own(ir))  *diags = (real(Tlm[ir][0])-real(Tlm[ir-1][0]))/((r[ir]-r[ir-1])*Y00_1);
		} else {
			diags = all_diags.append(1, "T(ro) ");
			if (own(ir))  *diags = real(Tlm[ir][0]) / Y00_1;
		}
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// geodynamo benchmark: measure drift rate of l=m=4 mode (on temperature field)
	const int m_probe = 4;
	static cplx tlm = 0;
	if ((evol_ubt & EVOL_T) && (MMAX*MRES >= m_probe) && (m_probe % MRES == 0)) {
		diags = all_diags.append(2, "w_drift, tp44\t ");		// append array for 2 diagnostics
		int ir = r_to_idx((r[NM]+r[NG])/2);
		if (own(ir)) {
			cplx tlmo = tlm;
			tlm = Tlm[ir][LM(m_probe,m_probe)];
			diags[0] = -arg(tlm/tlmo)/(dt_log*m_probe);		// omega_drift
			diags[1] = abs(tlm);
			printf(" wdrift(l=m=%d) = %g  (amplitude=%g)\n",m_probe, diags[0], diags[1]);
		}
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// dipolar magnetic field at the surface (3 components) + fraction of dipole field
	if (evol_ubt & EVOL_B) {
		diags = all_diags.append(4, "Bx, By, Bz, f_dip\t ");		// append array for 4 diagnostics
		if (Blm.ire == Blm.ir_bco) {		// if this process has the last shell:
			int ir = Blm.ir_bco;
			if ((MMAX > 0) && (MRES == 1)) {
				diags[0] = real(Blm.Pol[ir][LiM(1,1)])/Y11_st;		// Equatorial dipole, x
				diags[1] = imag(Blm.Pol[ir][LiM(1,1)])/Y11_st;		// Equatorial dipole, y
			}
			diags[2] = real(Blm.Pol[ir][LiM(1,0)])/Y10_ct;		// Axial dipole
			// compute Br2 for l=1..12, needed to compute fdip (see Christensen & Aubert 2006, end of section 2)
			int llim = 12;		// maximum degree taken into account here.
			if (llim < LMAX) llim = LMAX;	// avoid array overflows !!!
			double Br2dip = 0.0;
			double Br2all = 0.0;
			double pre = 1.0;
			double r_1 = 1.0/r[ir];
			for (int im=0; im<=MMAX; im++) {
				for (int l=im*MRES; l<=llim; l++) {
					cplx Br = l2[l] * Blm.Pol[ir][LiM(l,im)] * r_1;
					double Br2 = pre * norm(Br);
					Br2all += Br2;
					if (l==1) Br2dip += Br2;
				}
				pre = 2.0;		// count twice for m>0
			}
			diags[3] = sqrt( Br2dip / Br2all );		// f_dip
		}
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// Dissipation rates (kinetic and magnetic) : integral of entropy^2 if u=0 at the boundaries.
	if (evol_ubt & EVOL_U) {
		diags = all_diags.append(1, "D_nu\t ");		// append array for 1 diagnostic
		cplx* Q = (cplx*) malloc(3*NLM*sizeof(cplx));
		cplx* S = Q + NLM;		cplx* T = Q + 2*NLM;
		double Dnu = 0.0;
		for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {
			double r2dr = r[ir]*r[ir]*Ulm.delta_r(ir);
			Ulm.curl_QST(ir, Q, S, T);
			double Dnu_r = energy(Q,S,T) * r2dr;
			#ifdef XS_NU_VAR
			Dnu += Dnu_r * nur[ir];
			#else
			Dnu += Dnu_r * jpar.nu;
			#endif
		}
		diags[0] = 2.0*Dnu;
		free(Q);
	}
	if (evol_ubt & EVOL_B) {
		diags = all_diags.append(1, "D_eta\t ");		// append array for 1 diagnostic
		cplx* Q = (cplx*) malloc(3*NLM*sizeof(cplx));
		cplx* S = Q + NLM;		cplx* T = Q + 2*NLM;
		double Deta = 0.0;
		for (int ir=Blm.irs; ir<=Blm.ire; ir++) {
			double r2dr = r[ir]*r[ir]*Blm.delta_r(ir);
			Blm.curl_QST(ir, Q, S, T);
			double Deta_r = energy(Q,S,T) * r2dr;
			#ifdef XS_ETA_VAR
			Deta += Deta_r * etar[ir];
			#else
			Deta += Deta_r * jpar.eta;
			#endif
		}
		diags[0] = 2.0*Deta;
		free(Q);
	}
	if (((evol_ubt & (EVOL_T|EVOL_U)) == (EVOL_T|EVOL_U)) && (Grav0_r)) {		// convective power
		diags = all_diags.append(1, "Pconv\t ");		// append array for 1 diagnostic
		cplx* Q = (cplx*) malloc(2*NLM*sizeof(cplx));
		cplx* T = Q + NLM;
		double Pconv = 0.0;
		for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {
			for (int lm=0; lm<NLM; lm++) {
				Q[lm] = l2[lm]*Ulm.Pol[ir][lm] /r[ir];
				T[lm] = Tlm[ir][lm];
			}
			if (T0lm) {		// Add Background Temprature
				int nj = T0lm->nlm;
				unsigned* lma = T0lm->lm;
				cplx* TdT = T0lm->TdT + ir*nj*2;
				for (int j=0; j<nj; j++) {
					int lm = lma[j];
					T[lm] += TdT[j*2];
				}
			}
			double Pr = 2.0*coenergy(Q, T);
			Pconv += Pr*Grav0_r[ir]*r[ir] *r[ir]*r[ir]* Ulm.delta_r(ir);
		}
		diags[0] = Pconv;
		free(Q);
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// z-averaging: stores z-average of fields.
	static int out_zavg = -1;
	static int ns;
	static double *s;
	static double *vs;
	char fname[80];
	if (out_zavg == -1) {
		out_zavg = mp.var["zavg"];		// get value from variable "zavg" in xshells.par file
		PRINTF0(" zavg = %d\n",out_zavg);
		if (out_zavg) {
			ns = NLAT/4;
	 		s = (double*) malloc(sizeof(double)*ns);
			for (int j=0; j<ns; j++) s[j] = (j+1)*r[Ulm.ir_bco]/ns;
			vs = (double*) malloc(sizeof(double)*NPHI*ns*5);
		}
	}
	if (out_zavg) {
		if (evol_ubt & EVOL_B) {
			#pragma omp parallel
			Blm.special_z_avg(ns, s, vs, 1);
			if (i_mpi==0) {
				sprintf(fname,"zavgB_%05d.%s",iter,job);	write_disc_data(fname, s, ns, NPHI, vs, vs+NPHI*ns, 0);
				sprintf(fname,"zavgB2_%05d.%s",iter,job);	write_disc_data(fname, s, ns, NPHI, vs+NPHI*ns*2, vs+NPHI*ns*3, vs+NPHI*ns*4);
			}
		}
		if (evol_ubt & EVOL_U) {
			#pragma omp parallel
			Ulm.special_z_avg(ns, s, vs, 1);
			if (i_mpi==0) {
				sprintf(fname,"zavgU_%05d.%s",iter,job);	write_disc_data(fname, s, ns, NPHI, vs, vs+NPHI*ns, 0);
				sprintf(fname,"zavgU2_%05d.%s",iter,job);	write_disc_data(fname, s, ns, NPHI, vs+NPHI*ns*2, vs+NPHI*ns*3, vs+NPHI*ns*4);
			}
		}
	}
/*  ________
*/

}
#endif


#ifdef XS_ETA_PROFILE

/// define magnetic diffusivity eta as a function of r
/// discontinuous profiles supported.
void calc_eta(double eta0)
{
	static double etam = 0;
	
	if (etam==0) {
		etam = mp.var["etam"];		// value read from xshells.par file.
	}

	for (int i=0; i<NR; i++) {
		etar[i] = eta0;				// eta0 by default.
		if ((i > NM) && (etam))		etar[i] = eta0 * etam; 		// mantle almost insulating
	}
}
#endif


/* DO NOT REMOVE AND DO NOT ADD ANYTHING BEYOND THIS LINE */
#endif

