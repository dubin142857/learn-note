/** \file xshells.hpp
Compile-time parmeters and customizable functions for XSHELLS.
*/

#ifndef XS_H
	/* DO NOT COMMENT */
	#define XS_H

///  EXECUTION CONTROL  ///
/// 1. stable and tested features ///

/* call custom_diagnostic() (defined below) from main loop to perform and store custom diagnostics */
#define XS_CUSTOM_DIAGNOSTICS

/* enable variable time-step adjusted automatically */
#define XS_ADJUST_DT

/* XS_LINEAR use LINEAR computation : no u.grad(u), no J0xB0  */
//#define XS_LINEAR

/* Impose arbitrary stationary flow at the boundaries (for Diapir/Monteux) */
//#define XS_SET_BC

/* use variable conductivity profile eta(r) [see definition of profile in calc_eta() below */
//#define XS_ETA_PROFILE

/* Variable L-truncation : l(r) = LMAX * sqrt(r/(rmax*VAR_LTR))  +1 */
//#define VAR_LTR 0.5

///  EXECUTION CONTROL  ///
/// 2. unstable and beta features ///

/* Hyperdiffusion : enable enhanced diffusion constants (see xshells.par)*/
//#define XS_HYPER_DIFF



#ifdef XS_ETA_PROFILE
	// variable magnetic diffusivity is used :
	#define XS_ETA_VAR
#endif

#else


/* TIME-DEPENDANT BOUNDARY FORCING */
/// This function is called before every time-step, and allows you to modify
/// the Pol/Tor components of the velocity field.
/**  Useful global variables are :
 *  a_forcing : the amplitude set in the .par file
 *  w_forcing : the frequency (pulsation) set in the .par file
 *  \param[in] t is the current time.
 *  \param Bi is the inner SolidBody, whose angular velocity can be modified.
 *  \param Bo is the outer SolidBody, whose angular velocity can be modified.
 */
inline void calc_Uforcing(double t, double a_forcing, double w_forcing, struct SolidBody *Bi, struct SolidBody *Bo)
{
	double DeltaOm = a_forcing;

	/*	add // at the begining of this line to uncomment the following bloc.
		#define FORCING_M 1
		DeltaOm = a_forcing;
		t = - w_forcing*t;		// rotation of equatorial spin-axis.
	#define U_FORCING "Inner-core 'spin-over' forcing (l=1, m=1)"
		Bi->Omega_x = DeltaOm * cos(t); 	Bi->Omega_y = -DeltaOm * sin(t);
//	#define U_FORCING "Mantle 'spin-over' forcing (l=1, m=1)"
//		Bo->Omega_x = DeltaOm * cos(t); 	Bo->Omega_y = -DeltaOm * sin(t);
/*  ________
*/

	/*	add // at the begining of this line to uncomment the following bloc.
		#define FORCING_M 0
		if (w_forcing < 0.0)		// Periodic forcing on frequency |w_forcing|
		{
			DeltaOm *= sin(-w_forcing*t);
		}
		else if (w_forcing > 0.0)	// Impulsive forcing on time-scale 2.*pi/w_forcing.
		{
			if (t*w_forcing > 63.) {		// t > 10*2*pi/w_forcing
				DeltaOm = 0.0;
			} else {
				t = (t*w_forcing/(2.*M_PI) - 3.);	//t = (t - 3.*t_forcing)/t_forcing;
				DeltaOm *= exp(-t*t);	//   /(t_forcing*sqrt(pi)); //constant energy forcing.
			}
		}
	#define U_FORCING "Inner-core differential rotation (l=1, m=0)"
		Bi->Omega_z = DeltaOm;		// set differential rotation of inner core.
//	#define U_FORCING "Inner-core equatorial differential rotation (l=1, m=1)"
//		Bi->Omega_x = DeltaOm;		// set differential rotation of inner core.
//	#define U_FORCING "Mantle differential rotation (l=1, m=0)"
//		Bo->Omega_z = DeltaOm;		// set differential rotation of mantle.
//	#define U_FORCING "Mantle differential rotation (l=1, m=1)"
//		Bo->Omega_x = DeltaOm;		// set differential rotation of mantle.
/*  ________
*/

}


#ifdef XS_CUSTOM_DIAGNOSTICS
/// compute custom diagnostics. They can be stored in the all_diags array , which is written to the energy.jobname file.
/// own(ir) is a macro that returns true if the shell is owned by the process (useful for MPI).
/// i_mpi is the rank of the mpi process (0 is the root).
/// This function is called outside an OpenMP parallel region, and it is permitted to use openmp parallel constructs inside.
/// After this function returns, the all_diags array is summed accross processes and written in the energy.jobname file.
void custom_diagnostic(diagnostics& all_diags)
{
	double *diags;

	int sb_removed = 0;
//	/*	add // at the begining of this line to uncomment the following bloc.
	// removes axial solid-body rotation before the diagnostics (amplitude = 1).
	if ((evol_ubt & EVOL_U) && (!frame.check_time_dep())) {
		for (int ir=Ulm.irs-1; ir<=Ulm.ire+1; ir++) {		// include ghost shells.
			Ulm.Tor[ir][1] -= Ulm.radius(ir)*Y10_ct;
		}
		sb_removed = 1;
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// split energies (in symmetric, anti-symmetric, poloidal, toroidal, ...)
	if (evol_ubt & EVOL_U) {
		diags = all_diags.append(8,		// append array for 8 diagnostics
			"EZu_ps, EZu_pa, EZu_ts, EZu_ta, ENZu_ps, ENZu_pa, ENZu_ts, ENZu_ta\t ");
		Ulm.energy_split(diags);		// store 8 components of the kinetic energy (see energy_split in xshells_spectral.cpp)
	}
	if (evol_ubt & EVOL_B) {
		diags = all_diags.append(8,		// append array for 8 diagnostics
			"EZb_ps, EZb_pa, EZb_ts, EZb_ta, ENZb_ps, ENZb_pa, ENZb_ts, ENZb_ta\t ");
		Blm.energy_split(diags);		// store 8 components of the magnetic energy (see energy_split in xshells_spectral.cpp)
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// mean rotation vector (based on angular momentum, See PhD thesis of J. Noir, page 60-61.)
	if (evol_ubt & EVOL_U) {
		cplx Wxy;
		double Wz, dV;
		double r0 = mp.var["L_rmin"];
		double r1 = mp.var["L_rmax"];
		int ir0, ir1;
		int m1ok = ((MMAX>0)&&(MRES==1));
		diags = all_diags.append(3, "Wx, Wy, Wz\t ");		// append array for 3 diagnostics
		ir0 = r_to_idx(r0);		ir1 = r_to_idx(r1);
		if (Ulm.irs > ir0) ir0 = Ulm.irs;
		if ((ir1 == 0) || (Ulm.ire < ir1)) ir1 = Ulm.ire;
		Wxy=0;	Wz=0;
		for (int ir=ir0; ir<=ir1; ir++) {
			dV = r[ir]*r[ir]*r[ir] * Ulm.delta_r(ir);
			Wz += dV*real(Ulm.Tor[ir][LiM(1,0)]);
			if (m1ok) Wxy += dV*Ulm.Tor[ir][LiM(1,1)];
		}
		double n = (pow(r[Ulm.ir_bco],5)-pow(r[Ulm.ir_bci],5))/5.;	// [r^5/5]
		Wxy /= n*Y11_st;		Wz /= n*Y10_ct;			// spherical harmonic normalization
		diags[0] = real(Wxy);
		diags[1] = -imag(Wxy);
		diags[2] = Wz;
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// dipolar magnetic field at the surface (3 components) + fraction of dipole field
	if (evol_ubt & EVOL_B) {
		diags = all_diags.append(4, "Bx, By, Bz, f_dip\t ");		// append array for 4 diagnostics
		if (Blm.ire == Blm.ir_bco) {		// if this process has the last shell:
			int ir = Blm.ir_bco;
			if ((MMAX > 0) && (MRES == 1)) {
				diags[0] = real(Blm.Pol[ir][LiM(1,1)])/Y11_st;		// Equatorial dipole, x
				diags[1] = imag(Blm.Pol[ir][LiM(1,1)])/Y11_st;		// Equatorial dipole, y
			}
			diags[2] = real(Blm.Pol[ir][LiM(1,0)])/Y10_ct;		// Axial dipole
			// compute Br2 for l=1..12, needed to compute fdip (see Christensen & Aubert 2006, end of section 2)
			int llim = 12;		// maximum degree taken into account here.
			if (llim < LMAX) llim = LMAX;	// avoid array overflows !!!
			double Br2dip = 0.0;
			double Br2all = 0.0;
			double pre = 1.0;
			double r_1 = 1.0/r[ir];
			for (int im=0; im<=MMAX; im++) {
				for (int l=im*MRES; l<=llim; l++) {
					cplx Br = l2[l] * Blm.Pol[ir][LiM(l,im)] * r_1;
					double Br2 = pre * norm(Br);
					Br2all += Br2;
					if (l==1) Br2dip += Br2;
				}
				pre = 2.0;		// count twice for m>0
			}
			diags[3] = sqrt( Br2dip / Br2all );		// f_dip
		}
	}
/*  ________
*/


//	/*	add // at the begining of this line to uncomment the following bloc.
	// other spectrum based diagnostics
	if (evol_ubt & EVOL_U) {
		diags = all_diags.append(4, "Epol_sym, Epol_asym, Etor_sym, Etor_asym\t ");		// append array for 4 diagnostics
		cplx* Q = (cplx*) malloc(2*NLM*sizeof(cplx) + 2*NLM*sizeof(double));
		cplx* S = Q + NLM;
		double* Pspec = (double*)(S + NLM);
		double* Tspec = Pspec + NLM;
		memset(Pspec, 0, 2*NLM*sizeof(double));		// zero out spectrum.
		for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {
			Ulm.RadSph(ir, Q, S);
			double r2dr = r[ir]*r[ir]*Ulm.delta_r(ir);
			double dV = 0.5 * r2dr;
			double Esym  = 0.0; 	double Easym = 0.0;
			int lm=0;
			for (int im=0; im<=MMAX; im++) {
				// can we remove the SB rotation ?
				for (int l=im*MRES; l<=LMAX; l++, lm++) {
					double Plm = (norm(Q[lm]) + l2[l]*norm(S[lm])) * dV;
					double Tlm = 	l2[l]*norm(Ulm.Tor[ir][lm]) * dV;
					Pspec[lm] += Plm;
					Tspec[lm] += Tlm;
					diags[l&1] += Plm;
					diags[2+1-(l&1)] += Tlm;
				}
				dV = 1.0 * r2dr;		// count twice (+m and -m)
			}
		}
		free(Q);
	}
/*  ________
*/

//	/*	add // at the begining of this line to uncomment the following bloc.
	// Dissipation rates (kinetic and magnetic) : integral of entropy^2 if u=0 at the boundaries.
	if (evol_ubt & EVOL_U) {
		diags = all_diags.append(1, "D_nu\t ");		// append array for 1 diagnostic
		cplx* Q = (cplx*) malloc(3*NLM*sizeof(cplx));
		cplx* S = Q + NLM;		cplx* T = Q + 2*NLM;
		double Dnu = 0.0;
		for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {
			Ulm.curl_QST(ir, Q, S, T);
			double r2dr = r[ir]*r[ir]*Ulm.delta_r(ir);
			double dV = 1.0 * r2dr;
			int lm=0;
			for (int im=0; im<=MMAX; im++) {
				double Dm = 0.0;
				for (int l=im*MRES; l<=LMAX; l++, lm++) {
					Dm += norm(Q[lm]) + l2[l]*(norm(S[lm]) + norm(T[lm]));
				}
				Dnu += Dm * dV;
				dV = 2.0 * r2dr;		// count twice (+m and -m)
			}
		}
		diags[0] = Dnu * jpar.nu;
		free(Q);
	}
	if (evol_ubt & EVOL_B) {
		diags = all_diags.append(1, "D_eta\t ");		// append array for 1 diagnostic
		cplx* Q = (cplx*) malloc(3*NLM*sizeof(cplx));
		cplx* S = Q + NLM;		cplx* T = Q + 2*NLM;
		double Deta = 0.0;
		for (int ir=Blm.irs; ir<=Blm.ire; ir++) {
			Blm.curl_QST(ir, Q, S, T);
			double r2dr = r[ir]*r[ir]*Blm.delta_r(ir);
			double dV = 1.0 * r2dr;
			double Deta_r = 0.0;
			int lm=0;
			for (int im=0; im<=MMAX; im++) {
				double Dm = 0.0;
				for (int l=im*MRES; l<=LMAX; l++, lm++) {
					Dm += norm(Q[lm]) + l2[l]*(norm(S[lm]) + norm(T[lm]));
				}
				Deta_r += Dm * dV;
				dV = 2.0 * r2dr;		// count twice (+m and -m)
			}
			#ifdef XS_ETA_VAR
			Deta += Deta_r * etar[ir];
			#else
			Deta += Deta_r * jpar.eta;
			#endif
		}
		diags[0] = Deta;
		free(Q);
	}
/*  ________
*/

	if (sb_removed) {		// put axial solid-body rotation back in.
		for (int ir=Ulm.irs-1; ir<=Ulm.ire+1; ir++) {		// include ghost shells.
			Ulm.Tor[ir][1] += Ulm.radius(ir)*Y10_ct;
		}
	}
}
#endif


#ifdef XS_ETA_PROFILE

/// define magnetic diffusivity eta as a function of r
/// discontinuous profiles supported.
void calc_eta(double eta0)
{
	static double etam = 0;
	
	if (etam==0) {
		etam = mp.var["etam"];		// value read from xshells.par file.
	}

	for (int i=0; i<NR; i++) {
		etar[i] = eta0;				// eta0 by default.
		if ((i > NM) && (etam))		etar[i] = eta0 * etam; 		// mantle almost insulating
	}
}
#endif


/* DO NOT REMOVE AND DO NOT ADD ANYTHING BEYOND THIS LINE */
#endif

