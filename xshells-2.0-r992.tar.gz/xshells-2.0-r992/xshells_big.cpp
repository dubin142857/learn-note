/*
 * Copyright (c) 2010-2017 Centre National de la Recherche Scientifique.
 * written by Nathanael Schaeffer (CNRS, ISTerre, Grenoble, France).
 * 
 * nathanael.schaeffer@univ-grenoble-alpes.fr
 * 
 * This software is governed by the CeCILL license under French law and
 * abiding by the rules of distribution of free software. You can use,
 * modify and/or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info".
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */

/// \file xshells_big.cpp main program for
/// XSHELLS (eXtendable Spherical Harmonic Earth-Like Liquid Simulator).

#ifdef XS_MPI
  #include <mpi.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string>
#include <string.h>
#include <math.h>

//#define _GNU_SOURCE
//#include <fenv.h>

// Use real-time clock library to measure performance
#define XS_RTC_TIMINGS 1
#ifdef XS_RTC_TIMINGS
#include <sys/time.h>
#endif

// FFTW header required for memory allocation by fftw_malloc.
#include <fftw3.h>
#include <shtns.h>
#if defined(XS_MKL) && defined(_OPENMP)
	#include <fftw3_mkl.h>
#endif

#ifndef M_PI
#define M_PI 3.1415926535897932384626433832795
#endif

#define XS_PURE_SPECTRAL	// no spatial fields (mandatory for xshells_big.cpp).

#ifndef _HGID_
  #define _HGID_ "unknown"
#endif

#ifndef XS_NOPLOT
#include "gnuplot_pipes.hpp"
#endif

enum field_id { U, B, T, C, MAXFIELD };				///< field enumeration.
const char symbol[MAXFIELD] = { 'U', 'B', 'T', 'C' };	///< symbols for these fields.
#define EVOL(f) (1U<<f)

double dt,dto;		///< time step, previous time step
double Omega0;		///< global rotation rate (of outer boundary) => Coriolis force .
double Omega0_angle = 0.0;	///< angle of global rotation with z-axis.

int dt_adjust = 0;			///< variable time-step turned off by default.
int iter = 0;				///< current iteration.
double dt_log;				///< time between logs
double ftime = 0.0;			///< current fluid time.
double w_forcing = 0.0;		///< forcing frequency (pulsation).
double a_forcing = 0.0;		///< forcing amplitude.

enum need { NEED_U=1, NEED_W=2, NEED_B=4, NEED_J=8, 
	NEED_T=16, NEED_GT=32, NEED_C=64, NEED_GC=128, 
	NEED_UXW=1024, NEED_UXB=2048, NEED_JXB=4096, NEED_UGT=8192, NEED_UGC=16384, NEED_COR=32768 };				///< field enumeration.

/*
#define NEED_U 1
#define NEED_W 2
#define NEED_B 4
#define NEED_J 8
#define NEED_T 16
#define NEED_GT 32
#define NEED_C 64
#define NEED_GC 128
*/
int spat_need = 0;		///< flags for required computations of spatial fields.

#define EVOL_U EVOL(::U)
#define EVOL_B EVOL(::B)
#define EVOL_T EVOL(::T)
#define EVOL_C EVOL(::C)
int evol_ubt = 0;		///< flags for evolution of fields.

int kill_sbr = 2;		///< if (kill_sbr) solid body rotation is kept constant.

const double pi = M_PI;			///< pi = 3.14...

#include "xshells.hpp"
#if defined(XS_ELLIPTIC) || defined(XS_MASK) || defined(XS_JxB_M0) || defined(XS_SURF_PAIS) || defined(XS_DTS_POTENTIAL) || defined(XS_LIBRATION)
	#error "unsupported feature enabled in xshells.hpp"
#endif
#include "grid.cpp"

// spatial buffer (one for each thread)
static double* spat_mem = 0;
#if XS_OMP == 1
#pragma omp threadprivate(spat_mem)
#endif

#ifdef _OPENMP
	int nthreads;
	#include <omp.h>
	#define DEB printf("process %d, thread %d :: %s:%u pass\n",i_mpi, omp_get_thread_num(), __FILE__, __LINE__)
#else
	#define nthreads 1
	#define DEB printf("process %d, %s:%u pass\n", i_mpi, __FILE__, __LINE__); MPI_Barrier(MPI_COMM_WORLD)
#endif

#ifndef XS_DEBUG
	#undef DEB
	#define DEB (0)
#endif

/// for real-time performance measurements, returns time in seconds.
double tdiff(struct timeval *start, struct timeval *end)
{
	double sec = ((long) end->tv_sec - (long) start->tv_sec);
	sec += 1.e-6*((long) end->tv_usec - (long) start->tv_usec);
	return sec;	// time in s.
}

#include "xshells_spectral.cpp"
#include "xshells_io.cpp"

class StateVector {
  public:
	PolTor U, B;
	ScalarSH T,C;
	Spectral *Su, *Sb;					// temporary storage for spheroidal part of non-linear terms (before curl)

  private:
	Spectral* field[MAXFIELD];			// access as generic fields
	static int ir_bc[MAXFIELD*2];		// radial limits

  public:
	static double diff[MAXFIELD];		// diffusivity for each field

	void commit();
	void clone(const StateVector &X);
	inline static int ir_bci(int f) { return ir_bc[f*2]; }
	inline static int ir_bco(int f) { return ir_bc[f*2+1]; }
	inline Spectral& operator[](int f) { return *(field[f]); }

	void shell_gradT(int ir, cplx *Q, cplx *S, const int lms, const int lme) const;
	void shell_r_gradT(int ir, cplx *S, double *gt, double *gp) const;
};

double StateVector::diff[MAXFIELD];
int StateVector::ir_bc[MAXFIELD*2];

void StateVector::commit()
{
	for (int f=0; f<MAXFIELD; f++)  field[f] = 0;
	if (evol_ubt & EVOL(::U)) field[::U] = &U;
	if (evol_ubt & EVOL(::B)) field[::B] = &B;
	if (evol_ubt & EVOL(::T)) field[::T] = &T;
	if (evol_ubt & EVOL(::C)) field[::C] = &C;
	for (int f=0; f<MAXFIELD; f++) {
		if (field[f])  {
			ir_bc[f*2]   = field[f]->ir_bci;
			ir_bc[f*2+1] = field[f]->ir_bco;
		}
	}
}

void StateVector::clone(const StateVector &X)
{
	if (evol_ubt & EVOL(::U)) U.clone(X.U);		// non-linear terms require additional stroage.
	if (evol_ubt & EVOL(::B)) B.clone(X.B);
	if (evol_ubt & EVOL(::T)) T.clone(X.T);
	if (evol_ubt & EVOL(::C)) C.clone(X.C);
	Su = X.Su;		Sb = X.Sb;
	commit();
}

SolidBody InnerCore, Mantle;		// Solid boundaries.

StateVector Xlm, Ylm, Zlm, Xavg;
StateVector NL[4];
PolTor& Ulm = Xlm.U;		// aliases for easy access of fields in StateVector Xlm
PolTor& Blm = Xlm.B;
ScalarSH& Tlm = Xlm.T;
ScalarSH& Clm = Xlm.C;

StatSpecScal *T0lm = NULL;	///< Imposed background temperature.
StatSpecScal *C0lm = NULL;	///< Imposed background composition.
double* Grav0_r = NULL;		///< central gravity divided by r (l=0 only).
#define NL_ORDER 2
#ifdef XS_WRITE_SV
	cplx *Bp1, *Bp2;		// for time derivative of surface field
	cplx *Up1, *Ut1;
#endif
int MAKE_MOVIE = 0;			// no output by default.
volatile char SAVE_QUIT = 0;	// for signal catching.
char* job = NULL;
int lmax_out_sv = 0;		// no sv output by default.
double tsave_limit = 240;		// time-limit before backup to disk in minutes.

#ifdef XS_LINEAR
// base fields for linear stability.
SpatVect *U0 = 0;
SpatVect *W0 = 0;
SpatVect *B0 = 0;
SpatVect *J0 = 0;
SpatVect *gradT0 = 0;		// gradient of T0
SpatVect *gradPhi0 = 0;		///< general gravity field (non-central).
SpatVect *gradC0 = 0;		// gradient of C0
#endif


#include "xshells_physics.cpp"
#ifdef XS_SPARSE
#include "xshells_sparse.cpp"
#endif

#include "xshells_init.cpp"

RefFrame frame;		// the reference frame (with possibly variable rotation)

#include "xshells.hpp"
#ifndef U_FORCING
	#define FORCING_M 0
#endif

/// saves snapshot in a secure way (never overwrite data, avoid data corruption).
void save_snapshot()
{
	static double last_ftime = 0;
	if (last_ftime == ftime) return;			// do nothing if snapshot already saved at this time.

	static char fnew[MAXFIELD][100];
	static char fbak[MAXFIELD][100];
	static char ftmp[MAXFIELD][100];
	for (int f=0; f<MAXFIELD; f++) {
		if (evol_ubt & EVOL(f)) {
			// generate filenames
			sprintf(ftmp[f],"field%c_tmp.%s",symbol[f],job);
			sprintf(fbak[f],"field%c_back.%s",symbol[f],job);
			sprintf(fnew[f],"field%c.%s",symbol[f],job);	
			// remove old backup files
			if (i_mpi==0) remove(fbak[f]);
		}
	}
#ifdef XS_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif
	// write new snapshots in temp files
	for (int f=0; f<MAXFIELD; f++) {
		if (evol_ubt & EVOL(f))	Xlm[f].save(ftmp[f], ftime, iter);
	}
	// backup previous snapshot if it exists and rename new snapshots
	if (i_mpi==0) {
		for (int f=0; f<MAXFIELD; f++) {
			if (evol_ubt & EVOL(f)) {
				rename(fnew[f], fbak[f]);		rename(ftmp[f], fnew[f]);
			}
		}
	}
#ifdef XS_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif
	last_ftime = ftime;		// remember the ftime of this snapshot dump.
	if (i_mpi==0) {
		printf(" > snapshot dumped.\n");	fflush(stdout);
	}
}


/// saves fields and exit.
void save_quit() {
	char fname[100];
	for (int f=0; f<MAXFIELD; f++) {
		if (evol_ubt & EVOL(f)) {
			sprintf(fname,"field%c_kill.%s",symbol[f],job);
			Xlm[f].save(fname, ftime, iter);
		}
	}
	PRINTF0("=> terminated by signal, snapshot dumped (t=%g)\n", ftime);
#ifdef XS_MPI
	MPI_Abort(MPI_COMM_WORLD,2);
#endif
	exit(2);		// exit code 2 => restart is possible.
}


long n_stack = 0;		// number of fields that have been stacked.

/// accumulate solution (time-averaging).
void stack_fields() {
	#if XS_OMP == 2
	#pragma omp parallel
	#endif
	for (int f=0; f<MAXFIELD; f++) {
		if (evol_ubt & EVOL(f)) {
			int ir0 = Xlm[f].irs-1;
			int ir1 = Xlm[f].ire+1;
			int lm0 = 0;
			int lm1 = NLM * Xlm[f].get_ncomp() - 1;
			thread_interval_rad(ir0, ir1);
			thread_interval_lm(lm0, lm1);
			for (int ir=ir0; ir<=ir1; ir++) {
				v2d* acc = (v2d*) Xavg[f].get_data(0, ir);
				v2d* cur = (v2d*) Xlm[f].get_data(0, ir);
				for (size_t lm=lm0; lm <= lm1; lm++)		// assumes components stored together.
					acc[lm] += cur[lm];
			}
		}
	}
	#pragma omp master
	{
		n_stack ++;
	}
	#pragma omp barrier
}


// **************************
// ***** TIME STEPPING ******
// **************************

//#define LM_LOOP( action ) for (lm=0; lm<NLM; lm++) { action }
#ifdef VAR_LTR
  #define LTR ltr[ir]
#endif

enum cfl_id { cfl_ur, cfl_uh, cfl_br, cfl_bh, cfl_w, cfl_j, MAX_CFL };		///< cfl enumeration.
double dt_cfl[MAX_CFL];	///< dt required by CFL condition (radial and horizontal directions)
double C_cfl[MAX_CFL];	///< variable time-step CFL safety factors.
double dt_tol_lo, dt_tol_hi;	///< variable time-step tolerance range.

void calc_Matrices(double dt)
{
	const double dt_1 = 1.0/dt;

	#pragma omp parallel
	{
		#ifdef XS_SPARSE
		xs_sparse::prepare_solve(dt, 0.5);
		#else
		if (evol_ubt & EVOL_U) {
			#pragma omp single nowait
			{
				// (d/dt - NU.Lap)(-Lap.Up) = Toroidal[curl_NL]
				MUp.set_op(-dt_1, MU_Lr, -1.0, MU_LLr);
				MUp_1.set_op(-dt_1, MU_Lr, 1.0, MU_LLr);
				MUp_1.precalc_solve();
			}
			#pragma omp single nowait
			{
				// (d/dt - NU.Lap) Ut = Poloidal(curl_NL)
				MUt_1.set_op(dt_1, -1.0, MUt);
				MUt_1.precalc_solve();
			}
		}
		if (evol_ubt & EVOL_T) {
			#pragma omp single nowait
			{
				MT_1.set_op(dt_1, -1.0, MT);
				MT_1.precalc_solve();
			}
			if (evol_ubt & EVOL_C) {
				#pragma omp single nowait
				{
					MC_1.set_op(dt_1, -1.0, MC);
					MC_1.precalc_solve();
				}
			}
		}
		#endif
		if (evol_ubt & EVOL_B) {
			#pragma omp single nowait
			{
				MBp_1.set_op(dt_1, -1.0, MBp);
				MBp_1.precalc_solve();
			}
			#pragma omp single nowait
			{
				MBt_1.set_op(dt_1, -1.0, MBt);
				MBt_1.precalc_solve();
			}
		}
	}
}

void set_dt(double dt_new, double delta_t, int& istep)
{
	istep = ceil(delta_t/dt_new - 1./64.);	// this is my remaing steps... (1/64 prevents some unwanted changes du to finite precision).
	double dt_new2 = delta_t/istep;		// ... with my new time-step.
	if (fabs(dt-dt_new2) > 1e-12*(dt+dt_new2)) {
		struct timeval time1, time2;
		gettimeofday(&time1, NULL);
		dt = dt_new2;
		calc_Matrices(dt);
		gettimeofday(&time2, NULL);
		PRINTF0("	=> new time-step dt=%g  (dt_target=%g) (remaining substeps=%d)  [istep=ceil(%.15g)] [matrix recomputed in %gs]\n", dt, dt_new, istep, delta_t/dt_new, tdiff(&time1, &time2));
		if (dt < 0.0) runerr("ooops !");
	}
}

void adjust_dt(const double delta_t, int& istep)
{
	double dt_target, dt_cori;
	double dt_new = dt;

	#ifndef XS_ADJUST_DT
	runerr("[adjust_dt]: variable time-step not compiled.\n");
	#endif

	dto = dt;		// keep previous time-step

	#ifdef XS_MPI
		MPI_Allreduce( MPI_IN_PLACE, dt_cfl, MAX_CFL, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD );
	#endif
	dt_cori = fabs(jpar.C_cori/frame.Omega_z);
	#ifndef XS_SPARSE
	dt_target = dt_cori;
	#else
	dt_target = 1e200;
	#endif
	for (int k=0; k<MAX_CFL; k++) {
		dt_cfl[k] = C_cfl[k]/sqrt(dt_cfl[k]);
		if ((dt_cfl[k] < dt_target) && (k < cfl_w)) dt_target = dt_cfl[k];		// use only ur,uh, br,bh
	}

	if ((dt_adjust) && ((dt < dt_target*dt_tol_lo) || (dt > dt_target*dt_tol_hi))) {
		dt_new = dt_target;
	}
	set_dt(dt_new, delta_t, istep);
	if (istep == 1) {
		#ifdef XS_DEBUG
		PRINTF0("    dt=%g, dt_target=%g (dt_cori=%g, dt_ur=%g, dt_uh=%g, dt_br=%g, dt_bh=%g, dt_w=%g, dt_j=%g)\n",dt, dt_target, 
			dt_cori, dt_cfl[cfl_ur], dt_cfl[cfl_uh], dt_cfl[cfl_br], dt_cfl[cfl_bh], dt_cfl[cfl_w], dt_cfl[cfl_j]);
		#endif
	}
}

void compute_local_cfl(int ir, double* vcfl)
{
	double dr_2 = 1.0/Ulm.delta_r(ir);
	#ifdef VAR_LTR
	double dh_2 = ltr[ir];
	dh_2 = (r[ir] == 0.0) ? dh_2/(M_PI*r[ir+1]) : dh_2/(M_PI*r[ir]);
	#else
	double dh_2 = ((double) LMAX)/(M_PI*r[ir]);
	#endif
	dr_2 *= dr_2;		dh_2 *= dh_2;
	vcfl[cfl_ur] *= dr_2;		vcfl[cfl_uh] *= dh_2;		// standard CFL
	if (((evol_ubt & (EVOL_B | EVOL_U)) == (EVOL_B | EVOL_U)) && (spat_need & NEED_J)) {		// if u and b are coupled:
		// we must resolve the shortest period of Alfven waves (see also Christensen et. al GJI 1999, section 2.2)
		#ifdef XS_ETA_VAR
		double eta_nu = (etar[ir]+jpar.nu)*0.5;
		#else
		double eta_nu = (jpar.eta+jpar.nu)*0.5;
		#endif
		double dx_2 = (vcfl[cfl_br] + vcfl[cfl_bh])/(eta_nu*eta_nu);		// no Alfven waves below this length.
		if (dx_2 < dr_2) dr_2 = dx_2;
		if (dx_2 < dh_2) dh_2 = dx_2;
		vcfl[cfl_br] *= dr_2;		vcfl[cfl_bh] *= dh_2;
	}
	#pragma omp critical
	{
		for (int k=0; k<MAX_CFL; k++) {
			if (vcfl[k] > dt_cfl[k]) dt_cfl[k] = vcfl[k];		// NaN should be eliminated here
		}
	}
}


/// Update the imposed potential field associated to a solid body.
void update_BC_Mag(SolidBody *SB, cplx *P)
{
	cplx* P0 = SB->PB0lm;
	if (P0 != NULL) {
		if ((SB->Omega_x != 0.0)||(SB->Omega_y != 0.0)) runerr("Equatorial rotation not allowed with imposed potential field.");
		//for (int l=0; l <= SB->lmax; l++)	P[l] = P0[l];	// m=0 does not change.
		P0 += SB->lmax +1;
		for (int im=1; im <= SB->mmax; im++) {
			cplx a = cplx( cos(im*MRES * SB->phi0) , -sin(im*MRES * SB->phi0) );
			for (int l=im*MRES; l<=SB->lmax; l++)
				P[LiM(l,im)] = (*P0++) * a;
				// the externally imposed field has been multiplied by 2*(l+1) in load_init().
		}
	}
}

/// Update the velocity field at the boundary of a solid body.
inline void update_BC_U(SolidBody *SB, cplx *T, double rr)
{
	if ((MRES==1)&&(MMAX>0)) T[LiM(1,1)] = Y11_st * rr * cplx(SB->Omega_x, - SB->Omega_y);
	T[LiM(1,0)] = Y10_ct * rr * SB->Omega_z;
}

/// Computes the velocity of solid boundaries, and set boundary conditions of fluid if required.
void calc_U_solid()
{
	double om0i = InnerCore.Omega_z;	double om0o = Mantle.Omega_z;		// save axial rotation at time t.
	#ifdef U_FORCING
		InnerCore.invalidate_spatial();		// mark the spatial field as invalid (must be recomputed if needed)
		Mantle.invalidate_spatial();		//
		calc_Uforcing(ftime, a_forcing, w_forcing, &InnerCore, &Mantle);	// update axial rotation (time t+dt).
		if ((Ulm.bci == BC_NO_SLIP)&&(own(NG) || own(NG+1)))	update_BC_U(&InnerCore, Ulm.Tor[NG], r[NG]);
		if ((Ulm.bco == BC_NO_SLIP)&&(own(NM) || own(NM-1)))	update_BC_U(&Mantle, Ulm.Tor[NM], r[NM]);
	#endif

	om0i += InnerCore.Omega_z;		om0o += Mantle.Omega_z;
	InnerCore.phi0 += (0.5*dt) * om0i;		// follow angular position (phi, trapeze integration of OmegaZ)
	Mantle.phi0    += (0.5*dt) * om0o;

	if (evol_ubt & EVOL_B) {
		if ((om0i != 0.0)&&(own(Blm.ir_bci)))	update_BC_Mag(&InnerCore, Blm.Pol[Blm.ir_bci-1]);	// the inner-core has rotated, update magnetic BC
		if ((om0o != 0.0)&&(own(Blm.ir_bco)))	update_BC_Mag(&Mantle, Blm.Pol[Blm.ir_bco+1]);		// the mantle has rotated, update magnetic BC
		#ifdef XS_B_FORCING
		calc_Bforcing(ftime);
		#endif
	}
}


void vec_cpy(cplx* x, cplx*x0, int lms, int lme)
{
	memcpy(x+lms, x0+lms, (lme-lms+1)*sizeof(cplx));
}

void vec_sum(cplx* x, cplx* x0, cplx* a, cplx* b,
			double alpha, double beta,
			int lms, int lme)
{
	for (size_t k=lms; k<=lme; k++)
		((v2d*)x)[k] = ((v2d*)x0)[k] + vdup(alpha)*((v2d*)a)[k] + vdup(beta)*((v2d*)b)[k];
}

void vec_sum(cplx* x, cplx* x0, cplx* a, cplx* b, cplx* c, 
			double alpha, double beta, double gamma,
			int lms, int lme)
{
	if (gamma == 0.0) {
		vec_sum(x, x0,a,b, alpha, beta, lms, lme);
		return;
	}
	for (size_t k=lms; k<=lme; k++)
		((v2d*)x)[k] = ((v2d*)x0)[k] + vdup(alpha)*((v2d*)a)[k] + vdup(beta)*((v2d*)b)[k]
						+ vdup(gamma)*((v2d*)c)[k];
}

void vec_sum(cplx* x, cplx* x0, cplx* a, cplx* b, cplx* c, cplx* d,
			double alpha, double beta, double gamma, double delta,
			int lms, int lme)
{
	if (delta == 0.0) {
		vec_sum(x, x0,a,b,c, alpha, beta, gamma, lms, lme);
		return;
	}
	for (size_t k=lms; k<=lme; k++)
		((v2d*)x)[k] = ((v2d*)x0)[k] + vdup(alpha)*((v2d*)a)[k] + vdup(beta)*((v2d*)b)[k]
						+ vdup(gamma)*((v2d*)c)[k] + vdup(delta)*((v2d*)d)[k];
}

// TODO: for XS_SPARSE, Xlin.U and Xlin.T are zero, and some operations could be saved here.
void build_rhs(StateVector& Xrhs, StateVector& Xlin, StateVector* Xnl, int nl_0, int nnl, 
	double alpha=1.5, double beta=-0.5, double gamma=0, double delta=0)
{
	int i0, i1, lm0, lm1;

	int nlid[4];
	for (int k=0; k<4; k++)
		nlid[k] = (nl_0 + k) % nnl;

	lm0 = 0;		lm1 = NLM-1;
	thread_interval_lm(lm0, lm1);

	if (evol_ubt & EVOL_U) {
		i0 = MUt.irs;	i1 = MUt.ire;
		thread_interval_rad(i0, i1);
		for (int ir=i0; ir<=i1; ir++) {
			vec_sum(Xrhs.U.Tor[ir], Xlin.U.Tor[ir], 
					Xnl[nlid[0]].U.Pol[ir], Xnl[nlid[1]].U.Pol[ir], Xnl[nlid[2]].U.Pol[ir], Xnl[nlid[3]].U.Pol[ir], 
					alpha, beta, gamma, delta, lm0, lm1);		// Pol and Tor are exchanged in NL.
		}
		i0 = NG+1;		i1 = NM-1;
		mpi_interval(i0, i1);
		thread_interval_rad(i0, i1);
		for (int ir=i0; ir<=i1; ir++) {
			vec_sum(Xrhs.U.Pol[ir], Xlin.U.Pol[ir], 
					Xnl[nlid[0]].U.Tor[ir], Xnl[nlid[1]].U.Tor[ir], Xnl[nlid[2]].U.Tor[ir], Xnl[nlid[3]].U.Tor[ir],
					alpha, beta, gamma, delta, lm0, lm1);		// Pol and Tor are exchanged in NL.
		}
	}
	if (evol_ubt & EVOL_B) {
		/* POLOIDAL */
		i0 = MBp.irs;		i1 = MBp.ire;
		thread_interval_rad(i0, i1);
		for (int ir=i0; ir<=i1; ir++) {
			vec_sum(Xrhs.B.Pol[ir], Xlin.B.Pol[ir],
				Xnl[nlid[0]].B.Pol[ir], Xnl[nlid[1]].B.Pol[ir], Xnl[nlid[2]].B.Pol[ir], Xnl[nlid[3]].B.Pol[ir],
				alpha, beta, gamma, delta, lm0, lm1);
		}

		/* TOROIDAL */
		i0 = MBt.irs;		i1 = MBt.ire;
		thread_interval_rad(i0, i1);
		for (int ir=i0; ir<=i1; ir++) {
			vec_sum(Xrhs.B.Tor[ir], Xlin.B.Tor[ir],
				Xnl[nlid[0]].B.Tor[ir], Xnl[nlid[1]].B.Tor[ir], Xnl[nlid[2]].B.Tor[ir], Xnl[nlid[3]].B.Tor[ir],
				alpha, beta, gamma, delta, lm0, lm1);
		}
	}
	if (evol_ubt & EVOL_T) {
		i0 = MT.irs;		i1 = MT.ire;
		thread_interval_rad(i0, i1);
		for (int ir=i0; ir<=i1; ir++) {
			vec_sum(Xrhs.T.Sca[ir], Xlin.T.Sca[ir],
				Xnl[nlid[0]].T.Sca[ir], Xnl[nlid[1]].T.Sca[ir], Xnl[nlid[2]].T.Sca[ir], Xnl[nlid[3]].T.Sca[ir],
				-alpha, -beta, -gamma, -delta, lm0, lm1);
				// note that NL and NLo are defined as u.grad(T), that's why there is a minus in front of alpha and beta above.
		}
		if (evol_ubt & EVOL_C) {
			i0 = MC.irs;		i1 = MC.ire;
			thread_interval_rad(i0, i1);
			for (int ir=i0; ir<=i1; ir++) {
				vec_sum(Xrhs.C.Sca[ir], Xlin.C.Sca[ir],
					Xnl[nlid[0]].C.Sca[ir], Xnl[nlid[1]].C.Sca[ir], Xnl[nlid[2]].C.Sca[ir], Xnl[nlid[3]].C.Sca[ir],
					-alpha, -beta, -gamma, -delta, lm0, lm1);
					// note that NL and NLo are defined as u.grad(T), that's why there is a minus in front of alpha and beta above.
			}
		}
	}
}

/// this will also advance time step by 1.
void update_all_BC()
{
	#pragma omp barrier
	#pragma omp single
	{
		ftime += dt;			// update time
		frame.update(ftime);	// update rotation rates
		calc_U_solid();			// update boundary conditions (for U and B)
	}	// implicit barrier
}


#ifdef XS_MPI
int block_sze = 0;
#endif

/// solve in-place left-hand side of equation (semi-implicit at t+dt).
/// - right-hand side has to be computed with rhs_U, rhs_B, and rhs_T
/// - boundary conditions should have been updated to t+dt with update_all_BC()
void solve_state(StateVector& Xrhs)
{
#ifndef XS_MPI
	int lms = 0;		int lme = NLM -1;
	thread_interval_any(lms, lme);
	#pragma omp barrier
	if (evol_ubt & EVOL_B) {
		MBp_1.solve(Xrhs.B.Pol, lms, lme);		// B poloidal
		MBt_1.solve(Xrhs.B.Tor, lms, lme);		// B toroidal
	}
  #ifndef XS_SPARSE
	if (evol_ubt & EVOL_T) {		// temperature
		MT_1.solve(Xrhs.T.Sca, lms, lme);		// temperature, include central value for l=0, (l>0 tricked to zero)
		if (evol_ubt & EVOL_C) {
			MC_1.solve(Xrhs.C.Sca, lms, lme);		// composition, include central value for l=0, (l>0 tricked to zero)
		}
	}
	if (evol_ubt & EVOL_U) {
		MUt_1.solve(Xrhs.U.Tor, lms, lme);		// U toroidal
		MUp_1.solve(Xrhs.U.Pol, lms, lme);		// U poloidal
		if ((lms==0)&&(kill_sbr)) conserve_momentum(Xrhs.U, kill_sbr);
	}
  #else
	xs_sparse::solve_state(Xrhs);
  #endif
#else
	int nblocks = (NLM+block_sze-1)/block_sze;
	MPI_Request req[24*nblocks];		// up to 24 requests per block.
	MPI_Request *req_ptr = req;
	int k=0;
	const int ntags = 32;		// number of tags per block (power of two is better).
	for (long lms_block=0; lms_block<NLM; lms_block+=block_sze) {		// BLOCKED UP SOLVE
		long nlm_block = NLM-lms_block;
		if (nlm_block > block_sze) nlm_block = block_sze;

		int lms = lms_block;		int lme = lms_block + nlm_block -1;
		thread_interval_any(lms, lme);
		#pragma omp barrier

		if (evol_ubt & EVOL_B) {
			MBp_1.solve_up(Xrhs.B.Pol, lms, lme, k*ntags, &req_ptr, lms_block, nlm_block);		// B poloidal
			MBt_1.solve_up(Xrhs.B.Tor, lms, lme, k*ntags+1, &req_ptr, lms_block, nlm_block);	// B Toroidal : outer boundaries are zero.
		}
		if (evol_ubt & EVOL_T) {		// temperature
			MT_1.solve_up(Xrhs.T.Sca, lms, lme, k*ntags+2, &req_ptr, lms_block, nlm_block);		// temperature
			if (evol_ubt & EVOL_C) {
				MC_1.solve_up(Xrhs.C.Sca, lms, lme, k*ntags+3, &req_ptr, lms_block, nlm_block);		// composition
			}
		}
		if (evol_ubt & EVOL_U) {
			MUt_1.solve_up(Xrhs.U.Tor, lms, lme, k*ntags+4, &req_ptr, lms_block, nlm_block);		// U toroidal
			MUp_1.solve_up(Xrhs.U.Pol, lms, lme, k*ntags+5, &req_ptr, lms_block, nlm_block);		// U poloidal
		}
		k++;
	}
	k=0;
	for (long lms_block=0; lms_block<NLM; lms_block+=block_sze) {		// BLOCKED DOWN SOLVE
		long nlm_block = NLM-lms_block;
		if (nlm_block > block_sze) nlm_block = block_sze;

		int lms = lms_block;		int lme = lms_block + nlm_block -1;
		thread_interval_any(lms, lme);
		#pragma omp barrier

		if (evol_ubt & EVOL_B) {
			MBp_1.solve_dn(Xrhs.B.Pol, lms, lme, k*ntags+8, &req_ptr, lms_block, nlm_block);		// B poloidal
			MBt_1.solve_dn(Xrhs.B.Tor, lms, lme, k*ntags+9, &req_ptr, lms_block, nlm_block);	// B Toroidal : outer boundaries are zero.
		}
		if (evol_ubt & EVOL_T) {		// temperature
			MT_1.solve_dn(Xrhs.T.Sca, lms, lme, k*ntags+10, &req_ptr, lms_block, nlm_block);		// temperature
			if (evol_ubt & EVOL_C) {
				MC_1.solve_dn(Xrhs.C.Sca, lms, lme, k*ntags+11, &req_ptr, lms_block, nlm_block);		// composition
			}
		}
		if (evol_ubt & EVOL_U) {
			MUt_1.solve_dn(Xrhs.U.Tor, lms, lme, k*ntags+12, &req_ptr, lms_block, nlm_block);		// U toroidal
			MUp_1.solve_dn(Xrhs.U.Pol, lms, lme, k*ntags+13, &req_ptr, lms_block, nlm_block);		// U poloidal
		}
		k++;
	}
	#pragma omp master
	{
		k=0;
		for (long lms_block=0; lms_block<NLM; lms_block+=block_sze) {		// SYNC HALOS
			long nlm_block = NLM-lms_block;
			if (nlm_block > block_sze) nlm_block = block_sze;

			if (evol_ubt & EVOL_B) {
				MBp_1.solve_finish(Xrhs.B, 0, k*ntags+16, &req_ptr, lms_block, nlm_block);		// B poloidal
				MBt_1.solve_finish(Xrhs.B, 1, k*ntags+17, &req_ptr, lms_block, nlm_block);		// B Toroidal : outer boundaries are zero.
			}
			if (evol_ubt & EVOL_T) {		// temperature
				MT_1.solve_finish(Xrhs.T, 0, k*ntags+18, &req_ptr, lms_block, nlm_block);
				if (evol_ubt & EVOL_C) {
					MC_1.solve_finish(Xrhs.C, 0, k*ntags+19, &req_ptr, lms_block, nlm_block);
				}
			}
			if (evol_ubt & EVOL_U) {
				MUt_1.solve_finish(Xrhs.U, 1, k*ntags+20, &req_ptr, lms_block, nlm_block);				// U toroidal
				MUp_1.solve_finish(Xrhs.U, 0, k*ntags+21, &req_ptr, lms_block, nlm_block);				// U poloidal
			}
			k++;
		}

		if (req_ptr-req > 0) {
			int ierr = MPI_Waitall(req_ptr-req, req, MPI_STATUSES_IGNORE);
			if (ierr != MPI_SUCCESS) runerr("[solve_state] MPI_Waitall failed.\n");
		}
		if ((kill_sbr)&&(evol_ubt & EVOL_U)) conserve_momentum(Xrhs.U, kill_sbr);
		MPI_Barrier(MPI_COMM_WORLD);
	}
#endif
	#pragma omp barrier
}

int set_block_nbr_linsolve(int nb)		// returns the actual number of blocks
{
#ifdef XS_MPI
	if (nb < 1) nb = 1;							// at least one block !
	if ((NLM+nb-1)/nb < 64) nb = (NLM+63)/64;	// size not less than 1kb (64 cplx)
	if (nb > 2048) nb = 2048;					// no more than 2048 blocks.
	block_sze = (NLM+nb-1)/nb;			// corresponding block size (round up).
	return nb;
#else
	return 1;
#endif
}

#ifdef XS_RTC_TIMINGS
/// returns time in seconds for nloops linear solve with a nblk blocks
/// WARNING: after this function, the number of blocks is changed.
double time_linear_solver(int nblk, int nloops, int clear_cache=0)
{
	static std::map<int,double> cache;		// cache timings.
	double t = 0.0;
	struct timeval time1, time2;

	nblk = set_block_nbr_linsolve(nblk);		// set the block size (global variable)

	if (clear_cache) cache.clear();		// clear cache if requested.
	t = cache[nblk];		// get cached value if nloops did not change.
	if (t == 0.0) {		// value not cached
		#ifdef XS_MPI
		MPI_Barrier(MPI_COMM_WORLD);
		#endif
		gettimeofday(&time1, NULL);
		#pragma omp parallel
		{
			for (int j=0; j<nloops; j++) solve_state(Xlm);
		}
		gettimeofday(&time2, NULL);
		t = tdiff(&time1, &time2)/nloops;
		#ifdef XS_MPI
		MPI_Bcast((void*) &t, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);	// Broadcast time information.
		#endif
		cache[nblk] = t;
		#ifdef XS_DEBUG
			if (i_mpi==0) printf("\n   %d blocks : t=%g  (nloops=%d)",nblk, t, nloops);
		#else
			if (i_mpi==0) {	printf(".");	fflush(stdout);	}
		#endif
	} else {
		#ifdef XS_DEBUG
			if (i_mpi==0) printf("[time_linear_solver] cache hit for block number %d\n",nblk);
		#endif
	}
	return t;
}
#endif


/// find the best block size for MPI communication in the linear solver.
void optimize_linear_solver()		// TODO : do this in terms of number of blocks instead of block size.
{
	const double alpha = 0.61803;
	const double beta = 1. - alpha;
	const double t_accuracy = 1.02;			// we are happy if within 2% of best performance.
	int bmin = 1;		// minimum number of blocks.
	int bmax = set_block_nbr_linsolve( NLM );		// maximum number of blocks.

	// start with a default block number.
	int nblk = set_block_nbr_linsolve( (n_mpi+1)/2 );

#ifdef XS_RTC_TIMINGS
	int b[3];
	double t[3];
	int nloops = 1;
	int increasing = 0;
	int kill_sbr_back = kill_sbr;		// backup angular momentum conservation switch

	kill_sbr = 0;	// don't save angular momentum during these timings !!!
	if (i_mpi==0) printf("[Linear Solver] timing");
	if (n_mpi > 1) {
		nblk = set_block_nbr_linsolve( pow(bmin,beta)*pow(bmax,alpha) );	// go for some golden section in log-space.
	}
	b[1] = set_block_nbr_linsolve(nblk);
	do {	// first adjust the number of solves to get accurate timing.
		t[1] = time_linear_solver(b[1], nloops, 1);
		nloops *= 2;
	} while (t[1]*(nloops/2) < 0.03);
	nloops /= 2;
	if (nloops == 1)	t[1] = time_linear_solver(b[1], nloops, 1);	// time again to prevent cache effects.

#ifdef XS_MPI
	if (n_mpi > 1) {
		double mul;
		if ( bmax*bmin > b[1]*b[1]) {		// choose a value in the largest interval (log-scale).
			mul = bmax;
		} else {
			mul = bmin;
		}
		mul = pow(mul/b[1], beta);
		b[0] = set_block_nbr_linsolve( b[1]*mul );
		t[0] = time_linear_solver( b[0], nloops);
		if (t[0] < t[1]) {		// swap values to have t[1] < t[0]
			int bb = b[0];		b[0] = b[1];	b[1] = bb;
			double tt = t[0];	t[0] = t[1];	t[1] = tt;
		}
		//PRINTF0("\nbracketing interval : b = [%d %d ?] (mul=%g)", b[0], b[1], mul);
		if (b[1] > b[0]) {
			mul = bmax;
		} else {
			mul = bmin;
		}
		mul = pow(mul/b[1], beta);
		b[2] = b[1];		// base for next try.
		// t[1] is the smallest
		do {		// until we hit the wall !
			b[2] = set_block_nbr_linsolve( b[2]*mul );		// next try
			//PRINTF0("\nbracketing interval : b = [%d %d %d] (mul=%g)", b[0], b[1], b[2], mul);
			t[2] = time_linear_solver( b[2] , nloops);
			if (t[2] < t[1]) {		// new minimum
				if (t[1] > t[2]*t_accuracy) {		// change the interval limit
					t[0] = t[1];
					b[0] = b[1];
				}
				t[1] = t[2];
				b[1] = b[2];
			}
			if ((b[2] == bmin) || (b[2] == bmax) || (t[2] > t[1]*t_accuracy)) {		// if we reach the boundaries, or go really up, we stop !
				break;
			}
		} while ((b[1] > bmin) && (b[1] < bmax));
		//PRINTF0("\nbracketing done: b = [%d %d %d], t = [%g %g %g]", b[0], b[1], b[2],  t[0], t[1], t[2]);
		// now we have bracketed the minimum between t[0] and t[2]. t[1] is smaller (or equal) than t[0] and t[2]

		// golden section search.
		double tt;
		int bb;
		if (fabs(log(b[2])-log(b[0])) > fabs(log(b[0])-log(b[1]))) {		// split the largest interval in log scale
			bb = set_block_nbr_linsolve( round(pow(b[1],alpha)*pow(b[2],beta)) );
			tt = time_linear_solver( bb , nloops);
		} else {
			bb = b[1];		tt = t[1];
			b[1] = set_block_nbr_linsolve( round(pow(b[1],alpha)*pow(b[0],beta)) );
			t[1] = time_linear_solver( b[1] , nloops);
		}
		//PRINTF0("\ngolden search : b = [%d %d %d %d], t = [%g %g %g %g]", b[0], b[1], bb, b[2],  t[0], t[1], tt, t[2]);
		while ((t[2] > fmin(t[1],tt)*t_accuracy) && (t[0] > fmin(t[1],tt)*t_accuracy) && (abs(b[2]-b[0]) > 1)) {
			if (tt < t[1]) {		// this is a better candidate
				t[0] = t[1];	b[0] = b[1];
				t[1] = tt;		b[1] = bb;
				bb = set_block_nbr_linsolve( round(pow(b[1],alpha)*pow(b[2],beta)) );
				tt = time_linear_solver( bb , nloops);
			} else {
				t[2] = tt;		b[2] = bb;
				tt = t[1];		bb = b[1];
				b[1] = set_block_nbr_linsolve( round(pow(b[1],alpha)*pow(b[0],beta)) );
				t[1] = time_linear_solver( b[1] , nloops);
			}
			//PRINTF0("\ngolden search : b = [%d %d %d %d], t = [%g %g %g %g]", b[0], b[1], bb, b[2],  t[0], t[1], tt, t[2]);
		}
		if (tt < t[1]) {
			t[1] = tt;		b[1] = bb;
		}

		// we are done, b[1] is the optimal block number.
		set_block_nbr_linsolve( b[1] );
		MPI_Bcast((void*) &block_sze, 1, MPI_INT, 0, MPI_COMM_WORLD);		// Broadcast best block size information, just to be sure !
		MPI_Barrier(MPI_COMM_WORLD);
		nblk = b[1];
	}
#endif
	PRINTF0("\n   + using %d blocks (size %d), linear solve time = %g\n", nblk, (NLM+nblk-1)/nblk, t[1]);
	kill_sbr = kill_sbr_back;		// restore angular momentum conservation settings.
#endif
}


/// compute the spatial terms for a solid body (called by explicit_terms())
/// Q, S, nlr, nlt, nlp are temporary arrays.
/// Note: this does not couple different degrees l, but may couple m+1 and m-1 (if solid.Omega_x != 0 or solid.Omega_z != 0)
int spatial_terms_SolidBody(SolidBody& solid, StateVector& NL, StateVector& X, 
		cplx* Q, cplx* S, double* nlr, double* nlt, double* nlp)
{
	const size_t nspat = NLAT*NPHI;					// real physical size of spatial data
	if ((solid.Omega_x == 0) && (solid.Omega_y == 0)) {		// no SHT needed in that case.
		if (solid.Omega_z == 0) {
			#pragma omp for schedule(FOR_SCHED_SH) nowait
			for (int ir=solid.irs; ir<=solid.ire; ir++) {		// stationnary solid shell => zero forcing
				if (evol_ubt & EVOL_B) NL.B.zero_out_shell(ir);
				if (evol_ubt & EVOL_T) NL.T.zero_out_shell(ir);
				if (evol_ubt & EVOL_C) NL.C.zero_out_shell(ir);
			}
		} else {
			if (evol_ubt & EVOL_B) Axial_rot_induction(NL.B, solid, X.B);
			if (evol_ubt & EVOL_T) Axial_rot_advection(NL.T, solid, X.T);
			if (evol_ubt & EVOL_C) Axial_rot_advection(NL.C, solid, X.C);
		}
		return 0;		// curl_from_TQS should not include these solid shells
	} else {
		solid.calc_spatial();
		#pragma omp for schedule(FOR_SCHED_SH) nowait
		for (int ir=solid.irs; ir<=solid.ire; ir++) {		// rotating solid shell => advection
			if (evol_ubt & EVOL_B) {
				X.B.RadSph(ir, Q, S);
				SHV3_SPAT(Q, S, X.B.Tor[ir], nlr, nlt, nlp);
				for (size_t k=0; k<nspat; k++) {
					double rt = solid.vp_r[k]*r[ir];
					double rp = solid.vt_r[k]*r[ir];
					double rr = rp*nlp[k] - rt*nlt[k];
					nlt[k] = rt*nlr[k];		nlp[k] = -rp*nlr[k];		nlr[k] = rr;		// u x b
				}
				SPAT_SHV3(nlr, nlt, nlp, NL.B.Tor[ir], NL.Sb->get_data(0,ir), NL.B.Pol[ir]);
			}
			if (evol_ubt & EVOL_T) {
				X.T.shell_r_grad(T0lm, ir,S, nlt,nlp);
				for (size_t k=0; k<nspat; k++)
					nlr[k] = solid.vt_r[k]*nlt[k] + solid.vp_r[k]*nlp[k];		// u.grad(T)
				SPAT_SH(nlr, NL.T[ir]);
				if (evol_ubt & EVOL_C) {
					X.C.shell_r_grad(C0lm, ir,S, nlt,nlp);
					for (size_t k=0; k<nspat; k++)
						nlr[k] = solid.vt_r[k]*nlt[k] + solid.vp_r[k]*nlp[k];		// u.grad(C)
					SPAT_SH(nlr, NL.C[ir]);
				}
			}
		}
		return 1;		// curl_from_TQS needed on these solid shells (induction equation)
	}
}

#ifndef XS_LINEAR

spat_vect* gradPhi0 = 0;		///< general gravity field (non-central).

void explicit_terms(StateVector& NL, StateVector& Xlm, int calc_cfl=0)
{
//	printf("this is explicit terms, thread=%d\n", omp_get_thread_num());
	// compute spatial terms, shell by shell, without storing the full spatial fields (lower memory requirement, significantly faster).
	// TODO: support base fields.

	spat_vect v,w,nl;
	cplx *Q, *S, *T;
	#ifndef XS_SPARSE
	const double Wz0 = 2.*frame.Omega_z * Y10_ct;		// multiply by representation of cos(theta) in spherical harmonics (l=1,m=0)
	#endif
	const cplx Wxy0 = 2.*frame.Omega_xy * Y11_st;
	int NLb_istart = Ulm.ir_bci;		// a priori, non-linear terms for induction are only
	int NLb_iend   = Ulm.ir_bco;		// needed in the fluid domain.
	const size_t nspat_alloc = shtns->nspat;		// with padding for fft and alignement
	const size_t nspat = NLAT*NPHI;					// real physical size of spatial data
	const int lm10 = LiM(1,0);
	const int lm11 = LiM(1,1);

	void* mem = spat_mem;				// get thread-private spatial buffer
	mem = v.alloc(nspat_alloc, mem);
	mem = w.alloc(nspat_alloc, mem);
	mem = nl.alloc(nspat_alloc, mem);
	Q = (cplx*) mem;
	S = Q + NLM;		T = Q + 2*NLM;

	#pragma omp for schedule(FOR_SCHED_SH) nowait
	for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {		// FLUID SHELLS //
		#ifdef XS_ADJUST_DT
		double vcfl[MAX_CFL];
		for (int k=0; k<MAX_CFL; k++) vcfl[k] = 0.0;
		#endif
		int nlu_status = 0;
		if (spat_need & NEED_U) {		// spatial u
			Xlm.U.RadSph(ir, Q, S);
			SHV3_SPAT(Q, S, Xlm.U.Tor[ir], v.r, v.t, v.p);
			#ifdef XS_ADJUST_DT
			if (calc_cfl) {
				vcfl[cfl_ur] = absmax2(v.r, 0,nspat);
				vcfl[cfl_uh] = absmax2(v.t, v.p, 0,nspat);
			}
			#endif
		}
		if (spat_need & NEED_W) {		// spatial w
			Xlm.U.curl_QST(ir, Q, S, T);
			#ifndef XS_SPARSE
			Q[lm10] += Wz0; 	S[lm10] += Wz0;		// Coriolis for free.
			#endif
			Q[lm11] += Wxy0;	S[lm11] += Wxy0;
			SHV3_SPAT(Q, S, T, nl.r, nl.t, nl.p);
			#ifdef XS_ADJUST_DT
			if (calc_cfl)	vcfl[cfl_w] = absmax2(nl.r, nl.t, nl.p, 0,nspat);
			#endif
			cross_prod(nl, v, nl, 0,nspat);		// u x w
			nlu_status = 1;
		}
		if (spat_need & NEED_T) {
			spat_vect& g = gradPhi0[ir];
			cplx* a = Xlm.T[ir];
			if (spat_need & NEED_C) {
				cplx* b = Xlm.C[ir];
				for (int lm=0; lm<NLM; lm++)
					Q[lm] = a[lm] + b[lm];
				a = Q;
			}
			SH_SPAT(a, w.r);		// only one transform for both fields
			if (nlu_status) {
				scal_vect_add(nl, w.r, g, 0, nspat);
			} else {
				scal_vect(nl, w.r, g, 0, nspat);
				nlu_status = 1;
			}
		}
		if (spat_need & NEED_GT) {		// spatial grad(T)
			if ((ir>=Tlm.irs)&&(ir<=Tlm.ire)) {
				Xlm.T.shell_grad(T0lm, ir, Q,S, 0, NLM-1);
				SH_SPAT(Q, w.r);
				SHS_SPAT(S, w.t, w.p);
				for (size_t k=0; k<nspat; k++)
					w.r[k] = v.r[k]*w.r[k] + v.t[k]*w.t[k] + v.p[k]*w.p[k];		// u.grad(T)
				SPAT_SH(w.r, NL.T[ir]);
			}
		}
		if (spat_need & NEED_GC) {		// spatial grad(T)
			if ((ir>=Clm.irs)&&(ir<=Clm.ire)) {
				Xlm.C.shell_grad(C0lm, ir, Q,S, 0, NLM-1);
				SH_SPAT(Q, w.r);
				SHS_SPAT(S, w.t, w.p);
				for (size_t k=0; k<nspat; k++)
					w.r[k] = v.r[k]*w.r[k] + v.t[k]*w.t[k] + v.p[k]*w.p[k];		// u.grad(C)
				SPAT_SH(w.r, NL.C[ir]);
			}
		}
		if (spat_need & NEED_B) {		// spatial b
			Xlm.B.RadSph(ir, Q, S);
			SHV3_SPAT(Q, S, Xlm.B.Tor[ir], w.r, w.t, w.p);
			#ifdef XS_ADJUST_DT
			if (calc_cfl) {
				vcfl[cfl_bh] = absmax2(w.t, w.p, 0,nspat);
				vcfl[cfl_br] = absmax2(w.r, 0,nspat);
			}
			#endif
			if (evol_ubt & EVOL_B) {
				cross_prod(v, v, w, 0,nspat);		// u x b
				SPAT_SHV3(v.r, v.t, v.p, NL.B.Tor[ir], NL.Sb->get_data(0,ir), NL.B.Pol[ir]);
			}
		}
		if (spat_need & NEED_J) {		// spatial j
			Xlm.B.curl_QST(ir, Q, S, T);
			SHV3_SPAT(Q, S, T, v.r, v.t, v.p);
			#ifdef XS_ADJUST_DT
			if (calc_cfl)	vcfl[cfl_j] = absmax2(v.r, v.t, v.p, 0,nspat);
			#endif
			if  (nlu_status) {
				cross_prod_add(nl, v, w, 0,nspat);	// j x b
			} else {
				cross_prod(nl, v, w, 0,nspat);	// j x b
				nlu_status = 1;
			}
		}
		if (nlu_status) {
			SPAT_SHV3(nl.r, nl.t, nl.p, NL.U.Tor[ir], NL.Su->get_data(0,ir), NL.U.Pol[ir]);
		} else NL.U.zero_out_shell(ir);
		#ifdef XS_ADJUST_DT
		if (calc_cfl) compute_local_cfl(ir, vcfl);
		#endif
	}
	
	if (evol_ubt & (EVOL_B | EVOL_T | EVOL_C)) {			// SOLID SHELLS //
		if ((InnerCore.Omega_x != 0) || (InnerCore.Omega_y != 0))
			NLb_istart = NL.B.ir_bci;	// spatial terms for B span also inner-core
		if ((Mantle.Omega_x != 0) || (Mantle.Omega_y != 0))
			NLb_iend = NL.B.ir_bco;		// spatial terms for B span also mantle
		if (InnerCore.irs <= InnerCore.ire)
			spatial_terms_SolidBody(InnerCore, NL, Xlm,  Q, S, nl.r, nl.t, nl.p);
		if (Mantle.irs <= Mantle.ire)
			spatial_terms_SolidBody(Mantle, NL, Xlm,  Q, S, nl.r, nl.t, nl.p);
	}

	#ifdef XS_MPI
	#pragma omp barrier
	#pragma omp master
	{
		MPI_Request req[8];
		MPI_Request *req_ptr = req;
		if (evol_ubt & EVOL_B)	NL.Sb->sync1_mpi(0, NLb_istart, NLb_iend, 0, NLM-1, ::B, &req_ptr);
		if (evol_ubt & EVOL_U)	NL.Su->sync1_mpi(0, Ulm.ir_bci, Ulm.ir_bco, 0, NLM-1, ::U, &req_ptr);
		if (req_ptr-req > 0) {
			int ierr = MPI_Waitall(req_ptr-req, req, MPI_STATUSES_IGNORE);
			if (ierr != MPI_SUCCESS) runerr("[explicit_terms] MPI_Waitall failed.\n");
		}
	}
	#endif
	#pragma omp barrier
	if (evol_ubt & EVOL_B) NL.B.curl_from_TQS(NL.Sb, NLb_istart, NLb_iend, -1);		// no sync, it has been performed before.
	if (evol_ubt & EVOL_U) NL.U.curl_from_TQS(NL.Su, Ulm.ir_bci, Ulm.ir_bco, -1);	// no sync, it has been performed before.
	#pragma omp barrier
	if (evol_ubt & EVOL_U) {
		#ifndef XS_SPARSE
		if (((spat_need & NEED_W) == 0) && (frame.Omega_z != 0.0)) {
			Coriolis_force_add(NL.U, Xlm.U, frame.Omega_z, spat_mem);
			#pragma omp barrier
		}
		if (Grav0_r) {
			Radial_gravity_buoyancy(NL.U, Xlm.T, Xlm.C, Grav0_r);		// add buoyancy due to central gravity.
			#pragma omp barrier
		}
		#endif
		frame.add_Poincare_force(NL.U);
		#pragma omp barrier
	}
	#ifdef XS_BULK_FORCING
		bulk_forcing.add_forcing(NL, ftime);
		#pragma omp barrier
	#endif
}

namespace spatial_buffers {
	static dual_vect u,b,w,j,gt,gc;
	static double* tspat;
	static cplx* tspec;
}

void explicit_terms2(StateVector& NL, StateVector& Xlm, int calc_cfl=0)
{
	using namespace spatial_buffers;
	// compute spatial terms, shell by shell, without storing the full spatial fields (lower memory requirement, significantly faster).
	// TODO: support base fields.
	#ifndef XS_SPARSE
	const double Wz0 = 2.*frame.Omega_z * Y10_ct;		// multiply by representation of cos(theta) in spherical harmonics (l=1,m=0)
	#endif
	const cplx Wxy0 = 2.*frame.Omega_xy * Y11_st;
	int NLb_istart = Ulm.ir_bci;		// a priori, non-linear terms for induction are only
	int NLb_iend   = Ulm.ir_bco;		// needed in the fluid domain.
	const size_t nspat_alloc = shtns->nspat;		// with padding for fft and alignement
	const size_t nspat = NLAT*NPHI;					// real physical size of spatial data
	const int lm10 = LiM(1,0);
	const int lm11 = LiM(1,1);

	for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {		// FLUID SHELLS //
		/// 1) compute spectral components to transform
		#pragma omp parallel
		{
			int nlm0 = 0;		int nlm1 = NLM-1;
			thread_interval_lm(nlm0, nlm1);
			if (spat_need & NEED_U) 		// spatial u
				Xlm.U.RadSph(ir, u.Q, u.S, nlm0, nlm1);
			if (spat_need & NEED_W) {		// spatial w
				Xlm.U.curl_QST(ir, w.Q, w.S, w.T, nlm0, nlm1);
				#ifndef XS_SPARSE
				if (IN_RANGE_INCLUSIVE(lm10, nlm0, nlm1)) {
					w.Q[lm10] += Wz0; 	w.S[lm10] += Wz0;		// Coriolis for free.
				}
				#endif
				if (IN_RANGE_INCLUSIVE(lm11, nlm0, nlm1)) {
					w.Q[lm11] += Wxy0;	w.S[lm11] += Wxy0;
				}
			}
			if (spat_need & NEED_GT) {		// spatial grad(T)
				if ((ir>=Tlm.irs)&&(ir<=Tlm.ire)) {
					Xlm.T.shell_grad(T0lm, ir, gt.Q, gt.S, nlm0, nlm1);
				}
			}
			if (spat_need & NEED_GC) {		// spatial grad(T)
				if ((ir>=Clm.irs)&&(ir<=Clm.ire)) {
					Xlm.C.shell_grad(C0lm, ir, gc.Q, gc.S, nlm0, nlm1);
				}
			}
			if (spat_need & NEED_B) {		// spatial b
				Xlm.B.RadSph(ir, b.Q, b.S);
			}
			if (spat_need & NEED_J) {		// spatial j
				Xlm.B.curl_QST(ir, j.Q, j.S, j.T, nlm0, nlm1);
			}
			if ((spat_need & (NEED_T|NEED_C)) == (NEED_T|NEED_C)) {	// two buoyancy sources: add them
				for (int lm=nlm0; lm<=nlm1; lm++)	tspec[lm] = Xlm.T[ir][lm] + Xlm.C[ir][lm];
			}
		}
		/// 2) SHTs (multi-threaded)
			if (spat_need & NEED_U) 		// spatial u
				SHV3_SPAT(u.Q, u.S, Xlm.U.Tor[ir], u.r, u.t, u.p);
			if (spat_need & NEED_W)		// spatial w
				SHV3_SPAT(w.Q, w.S, w.T, w.r, w.t, w.p);
			if (spat_need & NEED_GT) {		// spatial grad(T)
				if ((ir>=Tlm.irs)&&(ir<=Tlm.ire)) {
					SH_SPAT(gt.Q, gt.r);		// not always needed.
					SHS_SPAT(gt.S, gt.t, gt.p);
				}
			}
			if (spat_need & NEED_GC) {		// spatial grad(T)
				if ((ir>=Clm.irs)&&(ir<=Clm.ire)) {
					SH_SPAT(gc.Q, gc.r);		// not always needed.
					SHS_SPAT(gc.S, gc.t, gc.p);
				}
			}
			if (spat_need & NEED_T) {
				cplx* a = Xlm.T[ir];
				if (spat_need & NEED_C) a = tspec;
				SH_SPAT(a, tspat);		// only one transform for both fields
			}
			if (spat_need & NEED_B)		// spatial b
				SHV3_SPAT(b.Q, b.S, Xlm.B.Tor[ir], b.r, b.t, b.p);
			if (spat_need & NEED_J)		// spatial j
				SHV3_SPAT(j.Q, j.S, j.T, j.r, j.t, j.p);
		/// 3) compute non-linear terms + CFL
		#pragma omp parallel
		{
			#ifdef XS_ADJUST_DT
			double vcfl[MAX_CFL];
			for (int k=0; k<MAX_CFL; k++) vcfl[k] = 0.0;
			#endif
			int nspat0 = 0;		int nspat1 = (nspat-1)/VSIZE;
			thread_interval_lm(nspat0, nspat1);
			nspat0 *= VSIZE;		nspat1 = (nspat1+1)*VSIZE;
			if (spat_need & NEED_W) {
				#ifdef XS_ADJUST_DT
				if (calc_cfl) {
					vcfl[cfl_ur] = absmax2(u.r, nspat0,nspat1);			// requires parallel absmax2
					vcfl[cfl_uh] = absmax2(u.t, u.p, nspat0,nspat1);
					vcfl[cfl_w] = absmax2(w.r, w.t, w.p, nspat0,nspat1);
				}
				#endif
				cross_prod(w, u, w, nspat0,nspat1);		// u x w
			}
			if (spat_need & NEED_J) {
				#ifdef XS_ADJUST_DT
				if (calc_cfl) {
					vcfl[cfl_bh] = absmax2(b.t, b.p, nspat0,nspat1);
					vcfl[cfl_br] = absmax2(b.r, nspat0,nspat1);
					vcfl[cfl_j] = absmax2(j.r, j.t, j.p, nspat0,nspat1);
				}
				#endif
				cross_prod_add(w, j, b, nspat0,nspat1);	// + j x b
			}
			if (evol_ubt & EVOL_B) {
				cross_prod(b, u, b, nspat0,nspat1);		// u x b
			}
			if (spat_need & NEED_GT) {
				for (size_t k=nspat0; k<nspat1; k++)
					gt.r[k] = u.r[k]*gt.r[k] + u.t[k]*gt.t[k] + u.p[k]*gt.p[k];		// u.grad(T)
			}
			if (spat_need & NEED_GC) {
				for (size_t k=nspat0; k<nspat1; k++)
					gc.r[k] = u.r[k]*gc.r[k] + u.t[k]*gc.t[k] + u.p[k]*gc.p[k];		// u.grad(T)
			}
			if (spat_need & (NEED_T | NEED_C)) {
				spat_vect& g = gradPhi0[ir];		// non-central gravity
				scal_vect_add(w, tspat, g, nspat0, nspat1);
			}
			#ifdef XS_ADJUST_DT
			if (calc_cfl) compute_local_cfl(ir, vcfl);
			#endif
		}
		/// 4) tranform back (SHT)
			if (spat_need & (NEED_W | NEED_J | NEED_T | NEED_C)) 		// spatial u
				SPAT_SHV3(w.r, w.t, w.p, NL.U.Tor[ir], NL.Su->get_data(0,ir), NL.U.Pol[ir]);
			if (spat_need & NEED_B)		// spatial b
				SPAT_SHV3(b.r, b.t, b.p, NL.B.Tor[ir], NL.Sb->get_data(0,ir), NL.B.Pol[ir]);
			if (spat_need & NEED_GT)		// spatial grad(T)
				SPAT_SH(gt.r, NL.T[ir]);
			if (spat_need & NEED_GC)		// spatial grad(T)
				SPAT_SH(gc.r, NL.C[ir]);
	}
	
	if (evol_ubt & (EVOL_B | EVOL_T | EVOL_C)) {			// SOLID SHELLS //
		if ((InnerCore.Omega_x != 0) || (InnerCore.Omega_y != 0))
			NLb_istart = NL.B.ir_bci;	// spatial terms for B span also inner-core
		if ((Mantle.Omega_x != 0) || (Mantle.Omega_y != 0))
			NLb_iend = NL.B.ir_bco;		// spatial terms for B span also mantle
		if (InnerCore.irs <= InnerCore.ire)
			runerr("no solid body support with hybrid2 mode.");
		if (Mantle.irs <= Mantle.ire)
			runerr("no solid body support with hybrid2 mode.");
	}

	#ifdef XS_MPI
	{	// we are not in a parallel region
		MPI_Request req[8];
		MPI_Request *req_ptr = req;
		if (evol_ubt & EVOL_B)	NL.Sb->sync1_mpi(0, NLb_istart, NLb_iend, 0, NLM-1, ::B, &req_ptr);
		if (evol_ubt & EVOL_U)	NL.Su->sync1_mpi(0, Ulm.ir_bci, Ulm.ir_bco, 0, NLM-1, ::U, &req_ptr);
		if (req_ptr-req > 0) {
			int ierr = MPI_Waitall(req_ptr-req, req, MPI_STATUSES_IGNORE);
			if (ierr != MPI_SUCCESS) runerr("[explicit_terms2] MPI_Waitall failed.\n");
		}
	}
	#endif

	#pragma omp parallel
	{
	if (evol_ubt & EVOL_B) NL.B.curl_from_TQS(NL.Sb, NLb_istart, NLb_iend, -1);		// no sync, already done before.
	if (evol_ubt & EVOL_U) {
		NL.U.curl_from_TQS(NL.Su, Ulm.ir_bci, Ulm.ir_bco, -1);		// no sync, already done before.

		#ifndef XS_SPARSE
		if (((spat_need & NEED_W) == 0) && (frame.Omega_z != 0.0)) Coriolis_force_add(NL.U, Xlm.U, frame.Omega_z, spat_mem);
		if (Grav0_r) Radial_gravity_buoyancy(NL.U, Xlm.T, Xlm.C, Grav0_r);		// add buoyancy due to central gravity.
		#endif
	}
	}

	if (evol_ubt & EVOL_U) {
		frame.add_Poincare_force(NL.U);
	}
	#ifdef XS_BULK_FORCING
		bulk_forcing.add_forcing(NL, ftime);
	#endif
}

#else /* XS_LINEAR */

#if XS_OMP == 2
#error "linear mode not supported with XS_OMP=2"
#endif

#ifdef XS_SPARSE
#error "We are not ready for XS_SPARSE with XS_LINEAR yet"
#endif

void explicit_terms(StateVector& NL, StateVector& Xlm, int calc_cfl=0)
{
	int NLb_istart = NG;	// a priori, non-linear terms for induction are only
	int NLb_iend = NM;		// needed in the fluid domain.
	if (U0) {
		if (U0->irs < NLb_istart)	NLb_istart = U0->irs;
		if (U0->ire > NLb_iend)		NLb_iend = U0->ire;
	}

  if (spat_need) {
	// compute spatial terms, shell by shell, without storing the full spatial fields (lower memory requirement, significantly faster).
	// TODO: support base fields.

	spat_vect v,w,nlu,nlb;
	double *nltemp;
	cplx *Q, *S, *T;
	const size_t nspat_alloc = shtns->nspat;		// with padding for fft and alignement
	const size_t nspat = NLAT*NPHI;					// real physical size of spatial data
	const int lm10 = LiM(1,0);
	const int lm11 = LiM(1,1);
	const double Wz0 = 2.*frame.Omega_z * Y10_ct;		// multiply by representation of cos(theta) in spherical harmonics (l=1,m=0)
	const cplx Wxy0 = 2.*frame.Omega_xy * Y11_st;

	void* mem = spat_mem;				// get thread-private spatial buffer
	mem = v.alloc(nspat_alloc, mem);
	mem = w.alloc(nspat_alloc, mem);
	if (evol_ubt & EVOL_U) mem = nlu.alloc(nspat_alloc, mem);
	if (evol_ubt & EVOL_B) mem = nlb.alloc(nspat_alloc, mem);
	if (evol_ubt & (EVOL_T | EVOL_C)) { nltemp = (double*) mem;		mem = nltemp + nspat_alloc; }
	Q = (cplx*) mem;		S = Q + NLM;		T = Q + 2*NLM;

	#pragma omp for schedule(FOR_SCHED_SH) nowait
	for (int ir=irs_mpi; ir<=ire_mpi; ir++) {		// ALL LOCAL SHELLS //
		#ifdef XS_ADJUST_DT
		double vcfl[MAX_CFL];
		for (int k=0; k<MAX_CFL; k++) vcfl[k] = 0.0;
		#endif
		int nl_status_U = 0;		// mark non-zero non-linear terms
		int shell_ubt = 0;
		for (int f=0; f<MAXFIELD; f++) {
			if ((evol_ubt & EVOL(f)) && (ir <= Xlm[f].ire) && (ir >= Xlm[f].irs)) shell_ubt |= EVOL(f);
		}

		// NAVIER-STOKES EQUATION (except Lorentz Force, computed later)
		if (shell_ubt & EVOL_U) {	// dynamic u domain
			if (spat_need & NEED_U) {
				Xlm.U.RadSph(ir, Q, S);
				SHV3_SPAT(Q, S, Xlm.U.Tor[ir], v.r, v.t, v.p);		// compute spatial u -> v
				if (W0) {
					nl_status_U = W0->w_cross_V0(ir, nlu.r,nlu.t,nlu.p, v.r,v.t,v.p, nl_status_U);	// nlu = u x W0
					#ifdef XS_ADJUST_DT
						if (calc_cfl) W0->absmax2(ir, vcfl[cfl_w]);
					#endif
				}
				if (spat_need & NEED_COR) {
					Q[0] = 0.0;		Q[lm10] = Wz0;			Q[lm11] = Wxy0;
					SH_to_spat_l(shtns, Q, w.r, 1);
					SHsph_to_spat_l(shtns, Q, w.t, w.p, 1);		// w = 2*Omega_coriolis
					#ifdef XS_CORIOLIS_BASE
					if (U0) {
						nl_status_U += U0->V0_cross_w(ir, nlu.r,nlu.t,nlu.p, w.r,w.t,w.p, nl_status_U);		// nlu += U0 x 2*Omega_coriolis
					}
					#endif
					cross_prod_condadd(nlu, v, w, 0,nspat, nl_status_U);		// nlu += u x 2*Omega_coriolis
					nl_status_U = 1;
				}
			}
			if (spat_need & NEED_W) {
				Xlm.U.curl_QST(ir, Q, S, T);
				SHV3_SPAT(Q, S, T, w.r, w.t, w.p);
				if (U0) {
					nl_status_U += U0->V0_cross_w(ir, nlu.r,nlu.t,nlu.p, w.r,w.t,w.p, nl_status_U);		// nlu += U0 x w
					#ifdef XS_ADJUST_DT
						if (calc_cfl) U0->absmax2(ir, vcfl[cfl_ur], vcfl[cfl_uh]);
					#endif
				}
				if (spat_need & NEED_UXW) {
					cross_prod_condadd(nlu, v, w, 0,nspat, nl_status_U);		// nlu += u x w
					nl_status_U = 1;
				}
			}
			#ifdef XS_ADJUST_DT
			if ( (calc_cfl) && (spat_need & (NEED_UGC | NEED_UGT | NEED_UXB | NEED_UXW)) ) {	// transport term => CFL condition
				double vr2 = absmax2(v.r, 0,nspat);
				double vh2 = absmax2(v.t, v.p, 0,nspat);
				if (vr2 > vcfl[cfl_ur]) vcfl[cfl_ur] = vr2;
				if (vh2 > vcfl[cfl_uh]) vcfl[cfl_uh] = vh2;
			}
			#endif
			if (shell_ubt & (EVOL_T|EVOL_C)) {		// BUOYANCY
				if ( ((shell_ubt & (EVOL_T | EVOL_C)) == (EVOL_T | EVOL_C)) 
				  && ((spat_need & (NEED_T | NEED_C)) == (NEED_T | NEED_C))) {
					const cplx* a = Xlm.T[ir];		const cplx* b = Xlm.C[ir];
					for (int lm=0; lm<NLM; lm++)
						Q[lm] = a[lm] + b[lm];
					SH_SPAT(Q, w.r);		// only one transform for both fields
					nl_status_U += gradPhi0->V0_times_s(ir, nlu.r,nlu.t,nlu.p, w.r, nl_status_U);	// nlu += (T+C).grad(Phi0)
				} else
				if ((shell_ubt & EVOL_T) && (spat_need & NEED_T)) {		// dynamic T domain
					SH_SPAT(Xlm.T[ir], w.r);
					nl_status_U += gradPhi0->V0_times_s(ir, nlu.r,nlu.t,nlu.p, w.r, nl_status_U);	// nlu += T.grad(Phi0)
				} else
				if ((shell_ubt & EVOL_C) && (spat_need & NEED_C)) {		// dynamic C domain
					SH_SPAT(Xlm.C[ir], w.r);
					nl_status_U += gradPhi0->V0_times_s(ir, nlu.r,nlu.t,nlu.p, w.r, nl_status_U);	// nlu += C.grad(Phi0)
				}
			}
		}

		// TEMPERATURE EQUATION //
		if (shell_ubt & EVOL_T) {
			int nl_status_T = 0;
			if (spat_need & NEED_GT) {		// spatial grad(T)
				Xlm.T.Gradr(ir, Q, S);
				SH_SPAT(Q, w.r);		// not always needed.
				SHS_SPAT(S, w.t, w.p);
				if (U0)
					nl_status_T = U0->V0_dot_w(ir, nltemp, w.r,w.t,w.p, nl_status_T);		// w.r = U0.grad(T)
			}
			if (shell_ubt & EVOL_U) {
				if (spat_need & NEED_UGT) {
					if (nl_status_T) {
						for (size_t k=0; k<nspat; k++)
							nltemp[k] += v.r[k]*w.r[k] + v.t[k]*w.t[k] + v.p[k]*w.p[k];		// nltemp = u.grad(T)
					} else {
						for (size_t k=0; k<nspat; k++)
							nltemp[k] = v.r[k]*w.r[k] + v.t[k]*w.t[k] + v.p[k]*w.p[k];		// nltemp = u.grad(T)
						nl_status_T = 1;
					}
				}
				if (gradT0) {	// u.grad(T0)
					nl_status_T += gradT0->V0_dot_w(ir, nltemp, v.r,v.t,v.p, nl_status_T);				// nltemp = u.grad(T0)
				}
			}
			if (nl_status_T) {
				SPAT_SH(nltemp, NL.T[ir]);
			} else NL.T.zero_out_shell(ir);
		}

		// CONCENTRATION EQUATION //
		if (shell_ubt & EVOL_C) {
			int nl_status_C = 0;
			if (spat_need & NEED_GC) {		// spatial grad(C)
				Xlm.C.Gradr(ir, Q, S);
				SH_SPAT(Q, w.r);		// not always needed.
				SHS_SPAT(S, w.t, w.p);
				if (U0)
					nl_status_C = U0->V0_dot_w(ir, nltemp, w.r,w.t,w.p, nl_status_C);		// w.r = U0.grad(C)
			}
			if (shell_ubt & EVOL_U) {
				if (spat_need & NEED_UGC) {
					if (nl_status_C) {
						for (size_t k=0; k<nspat; k++)
							nltemp[k] += v.r[k]*w.r[k] + v.t[k]*w.t[k] + v.p[k]*w.p[k];		// nltemp = u.grad(C)
					} else {
						for (size_t k=0; k<nspat; k++)
							nltemp[k] = v.r[k]*w.r[k] + v.t[k]*w.t[k] + v.p[k]*w.p[k];		// nltemp = u.grad(C)
						nl_status_C = 1;
					}
				}
				if (gradC0) {	// u.grad(C0)
					nl_status_C += gradC0->V0_dot_w(ir, nltemp, v.r,v.t,v.p, nl_status_C);				// nltemp = u.grad(C0)
				}
			}
			if (nl_status_C) {
				SPAT_SH(nltemp, NL.C[ir]);
			} else NL.C.zero_out_shell(ir);
		}

		if (shell_ubt & EVOL_B) {		// dynamic b domain
			int nl_status_B = 0;
			// INDUCTION EQUATION
			if (spat_need & NEED_B) {
				Xlm.B.RadSph(ir, Q, S);
				SHV3_SPAT(Q, S, Xlm.B.Tor[ir], w.r, w.t, w.p);		// overwrite w with spatial B
				if (U0) {
					nl_status_B = U0->V0_cross_w(ir, nlb.r,nlb.t,nlb.p, w.r,w.t,w.p, nl_status_B);		// nlb += U0 x b
				}
			}
			if (shell_ubt & EVOL_U) {
				if (spat_need & NEED_UXB)  {
					cross_prod_condadd(nlb, v, w, 0,nspat, nl_status_B);		// nlb += u x b
					nl_status_B = 1;
				}
				if (B0) {
					nl_status_B = B0->w_cross_V0(ir, nlb.r,nlb.t,nlb.p, v.r,v.t,v.p, nl_status_B);	// nlb = u x B0
				}
			}
			if (nl_status_B) {
				SPAT_SHV3(nlb.r, nlb.t, nlb.p, NL.B.Tor[ir], NL.Sb->get_data(0,ir), NL.B.Pol[ir]);
			} else {
				NL.B.zero_out_shell(ir);		NL.Sb->zero_out_shell(ir);
			}
			// LORENTZ FORCE
			if (shell_ubt & EVOL_U) {
				if (J0) {
					nl_status_U += J0->V0_cross_w(ir, nlu.r,nlu.t,nlu.p, w.r,w.t,w.p, nl_status_U);		// nlu += J0 x b
					#ifdef XS_ADJUST_DT
						if (calc_cfl) J0->absmax2(ir, vcfl[cfl_j]);
					#endif
				}
				if (spat_need & NEED_J) {		// spatial j
					Xlm.B.curl_QST(ir, Q, S, T);
					SHV3_SPAT(Q, S, T, v.r, v.t, v.p);		// overwrite v with spatial J
					if (B0) {
						nl_status_U += B0->w_cross_V0(ir, nlu.r,nlu.t,nlu.p, v.r,v.t,v.p, nl_status_U);	// nlu += j x B0
						#ifdef XS_ADJUST_DT
							if (calc_cfl) B0->absmax2(ir, vcfl[cfl_br], vcfl[cfl_bh]);
						#endif
					}
					if (spat_need & NEED_JXB) {
						cross_prod_condadd(nlu, v, w, 0,nspat, nl_status_U);		// nlu += j x b
						nl_status_U = 1;
						#ifdef XS_ADJUST_DT
						if ((calc_cfl) && (spat_need & (NEED_UXB)) ) {		// possibly dynamic Alfvén waves => CFL on B
							double b2r = absmax2(w.r, 0,nspat);
							double b2h = absmax2(w.t, w.p, 0,nspat);
							if (b2r > vcfl[cfl_br]) vcfl[cfl_br] = b2r;
							if (b2h > vcfl[cfl_bh]) vcfl[cfl_bh] = b2h;
						}
						#endif
					}
				}
			}
		}
		if (shell_ubt & EVOL_U) {
			if (nl_status_U) {
				SPAT_SHV3(nlu.r, nlu.t, nlu.p, NL.U.Tor[ir], NL.Su->get_data(0,ir), NL.U.Pol[ir]);
			} else {
				NL.U.zero_out_shell(ir);		NL.Su->zero_out_shell(ir);
			}
		}
		#ifdef XS_ADJUST_DT
		if (calc_cfl) compute_local_cfl(ir, vcfl);
		#endif
	}

	if (evol_ubt & (EVOL_B | EVOL_T | EVOL_C)) {			// SOLID SHELLS //
		if ((InnerCore.Omega_x != 0) || (InnerCore.Omega_y != 0))
			NLb_istart = NL.B.ir_bci;	// spatial terms for B span also inner-core
		if ((Mantle.Omega_x != 0) || (Mantle.Omega_y != 0))
			NLb_iend = NL.B.ir_bco;		// spatial terms for B span also mantle
		if (InnerCore.irs <= InnerCore.ire)
			spatial_terms_SolidBody(InnerCore, NL, Xlm,  Q, S, nlb.r, nlb.t, nlb.p);
		if (Mantle.irs <= Mantle.ire)
			spatial_terms_SolidBody(Mantle, NL, Xlm,  Q, S, nlb.r, nlb.t, nlb.p);
	}
  }
  else {
	  if (evol_ubt & EVOL_U) NL.U.zero_out();
	  if (evol_ubt & EVOL_B) NL.B.zero_out();
	  if (evol_ubt & EVOL_T) NL.T.zero_out();
  }
	#pragma omp barrier

	if (evol_ubt & EVOL_U) {
		NL.U.curl_from_TQS(NL.Su, Ulm.ir_bci, Ulm.ir_bco, ::U);		// includes MPI sync with tag ::U
		#pragma omp barrier
		#ifndef XS_SPARSE
		if ( ((spat_need & NEED_COR) == 0) && (frame.Omega_z != 0.0) ) {		// check if Coriolis is needed.
			Coriolis_force_add(NL.U, Xlm.U, frame.Omega_z);
			#pragma omp barrier
		}
		if (Grav0_r) {
			Radial_gravity_buoyancy(NL.U, Xlm.T, Xlm.C, Grav0_r);		// add buoyancy due to central gravity.
			#pragma omp barrier
		}
		#endif
		frame.add_Poincare_force(NL.U);
		#ifdef XS_BULK_FORCING
			bulk_forcing.add_forcing(NL, ftime);
		#endif
	}
	if (evol_ubt & EVOL_B) {
		NL.B.curl_from_TQS(NL.Sb, NLb_istart, NLb_iend, ::B);		// includes MPI sync with tag ::B
	}
	#ifndef XS_SPARSE
	if (evol_ubt & EVOL_T) {
		if ((T0lm) && (T0lm->lmax == 0)) {	// for l=0 imposed profile, no spherical harmonic transforms needed.
			#pragma omp for schedule(FOR_SCHED_SH) nowait
			for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {
				double dT0dr_r = real(T0lm->TdT[ir*2+1]) * r_1[ir] * (1.0/Y00_1);
				if (r[ir]==0.0) dT0dr_r = (2.0/Y00_1) * ( real(T0lm->TdT[(ir+1)*2]) - real(T0lm->TdT[ir*2]) ) * (r_1[ir+1]*r_1[ir+1]);		// compute 1/r*dT/dr for r=0,l=0 as 2*(T(dr)-T(0))/dr^2
				for (int lm=0; lm<NLM; lm++) {
					NL.T[ir][lm] += l2[lm]*Xlm.U.Pol[ir][lm] * dT0dr_r;		// ur.dT0/dr
				}
			}
		}
	}
	if (evol_ubt & EVOL_C) {
		if ((C0lm) && (C0lm->lmax == 0)) {	// for l=0 imposed profile, no spherical harmonic transforms needed.
			#pragma omp for schedule(FOR_SCHED_SH) nowait
			for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {
				double dT0dr_r = real(C0lm->TdT[ir*2+1]) * r_1[ir] * (1.0/Y00_1);
				if (r[ir]==0.0) dT0dr_r = (2.0/Y00_1) * ( real(C0lm->TdT[(ir+1)*2]) - real(C0lm->TdT[ir*2]) ) * (r_1[ir+1]*r_1[ir+1]);		// compute 1/r*dC/dr for r=0,l=0 as 2*(C(dr)-C(0))/dr^2
				for (int lm=0; lm<=NLM; lm++) {
					NL.C[ir][lm] += l2[lm]*Xlm.U.Pol[ir][lm] * dT0dr_r;		// ur.dC0/dr
				}
			}
		}
	}
	#endif
	#pragma omp barrier
}

#endif


/// compute the linear right hand side term (and save surface fields if required)
void implicit_rhs(StateVector& Y, StateVector& X)
{
	int i0, i1, lm0, lm1;
	lm0 = 0;	lm1 = NLM-1;
	thread_interval_lm(lm0, lm1);
	double dt_1 = 1.0/dt;

	#ifndef XS_SPARSE
	if (evol_ubt & EVOL_U) {
		/* V TOROIDAL */
		MUt.apply(X.U.Tor, Y.U.Tor, lm0, lm1, dt_1);
		/* V POLOIDAL */
		MUp.apply(X.U.Pol, Y.U.Pol, lm0, lm1);		// P imposed at the boundaries.
	}
	#endif

	if (evol_ubt & EVOL_B) {
		/* B POLOIDAL */
		MBp.apply(X.B.Pol, Y.B.Pol, lm0, lm1, dt_1);
		/* B TOROIDAL */
		MBt.apply(X.B.Tor, Y.B.Tor, lm0, lm1, dt_1);
	}

	#ifndef XS_SPARSE
	if (evol_ubt & EVOL_T) {
		/* TEMPERATURE */
		MT.apply(X.T.Sca, Y.T.Sca, lm0, lm1, dt_1);
/*		i0 = T_i0;		i1 = T_i1;
		mpi_interval(i0, i1);
		thread_interval_rad(i0, i1);
		if ((lm0==0)&&(i0 == T_i0)&&(r[Tlm.irs] == 0.0)) {	// special for r=0
			cTriMulBC(MT, X.T.Sca, Y.T.Sca, i0-1, i0-1, 0, 0);		// l=0 includes r=0
		}
		cTriMulBC(MT, X.T.Sca, Y.T.Sca, i0, i1, lm0, lm1);	*/
	}
	if (evol_ubt & EVOL_C) {
		/* COMPOSITION */
		MC.apply(X.C.Sca, Y.C.Sca, lm0, lm1, dt_1);
	}
	#endif
	#pragma omp barrier
}

/// returns the actual number of explicit rhs evaluations.
long step_UBT(double delta_t)
{
	long ex_evals = 0;
	#ifdef XS_DEBUG
		PRINTF0("  Omega : IC = (%g, %g, %g) \t M = (%g, %g, %g)\n", InnerCore.Omega_x, InnerCore.Omega_y, InnerCore.Omega_z, Mantle.Omega_x, Mantle.Omega_y, Mantle.Omega_z);
	#endif

	#ifdef XS_ADJUST_DT
	int istep = 0;
	#else
	int istep = delta_t/dt;
	#endif
	do {
		#ifndef XS_MPI
		if (SAVE_QUIT & 4) save_quit();
		#endif
		#ifdef XS_ADJUST_DT
		for (int k=0; k<MAX_CFL; k++) dt_cfl[k] = 0.0;
		#endif
		#if XS_OMP == 1
		#pragma omp parallel
		#endif
		{
			if (MAKE_MOVIE == 2) stack_fields();	// accumulate solution for time-averaging.

			// Predictor: Euler 1 + Crank-Nicolson
			#if  XS_OMP != 2
				explicit_terms(NL[0], Xlm, 1);		// NL(t) + CFL
				#pragma omp barrier
				#pragma omp master
				{
					#ifdef XS_ADJUST_DT
					adjust_dt(delta_t, istep);		// adjust time-step and istep
					#endif
				}
				#pragma omp barrier
			#else
				explicit_terms2(NL[0], Xlm, 1);		// NL(t) + CFL
				#ifdef XS_ADJUST_DT
				adjust_dt(delta_t, istep);		// adjust time-step and istep
				#endif
				#pragma omp parallel
			#endif
			{
				implicit_rhs(Ylm, Xlm);
				build_rhs(Xlm, Ylm, NL, 0, 1, 1.0, 0.0);		// first stage is explicit Euler + Crank-Nicolson
				update_all_BC();		// t + dt
				solve_state(Xlm);
			}
			for (int c=2; c>0; c--) {		// 2 corrector stages
				// corrector: Crank-Nicolson (order 2)
				#if XS_OMP != 2
					explicit_terms(NL[1], Xlm);		// NL(t+dt) estimate
				#else
					explicit_terms2(NL[1], Xlm);		// NL(t+dt) estimate
					#pragma omp parallel
				#endif
				{
					build_rhs(Xlm, Ylm, NL, 0, 2, 0.5, 0.5);	// Crank-Nicolson type
					solve_state(Xlm);	// corrector for t+dt
				}
			}
		}
		delta_t -= dt;
		ex_evals += 3;
	} while (--istep > 0);
	return ex_evals;
}

#ifndef XS_MPI
/// signal handler for saving/aborting during run.
void sig_handler(int sig_num)
{
	switch(sig_num) {
		case 15 : SAVE_QUIT = 4; break;		// TERM signal : save state as soon as possible !
		case 30 : SAVE_QUIT = 1; break;		// Save snapshot at next iter.
		case 31 : SAVE_QUIT = 2;			// Save & quit
	}
}
#endif

void nrj_and_summed_diagnostics(FILE* &fnrj, double treal=0.0, long nex=0)
{
	static diagnostics nrj;		// will stay allocated.
	static SpectralDiags sdU(LMAX,MMAX);
	static SpectralDiags sdB(LMAX,MMAX);
	static SpectralDiags sdT(LMAX,MMAX);
	static SpectralDiags sdC(LMAX,MMAX);
	double rspec_max = 0.0;

	double nrjUo = 0, nrjBo = 0;
	if (nrj.size() >= 2) {
		nrjUo = nrj[0];		nrjBo = nrj[1];
	}

	nrj.reset();		// the energies of the 3 fields.
	nrj.append(4, "% t\t Eu, Eb, Et, Ec\t dt\t ");
	if (evol_ubt & EVOL_U) { Ulm.energy(sdU);  nrj[0] = sdU.energy(); }
	if (evol_ubt & EVOL_B) { Blm.energy(sdB);  nrj[1] = sdB.energy(); }
	if (evol_ubt & EVOL_T) { Tlm.energy(sdT);  nrj[2] = sdT.energy(); }
	if (evol_ubt & EVOL_C) { Clm.energy(sdC);  nrj[3] = sdC.energy(); }
  #ifdef XS_CUSTOM_DIAGNOSTICS
	custom_diagnostic(nrj);		// call custom_diagnostic() (defined in xshells.hpp)
  #endif
  #ifdef XS_MPI
	MPI_Reduce((i_mpi==0) ? MPI_IN_PLACE : &nrj[0], &nrj[0] , nrj.size(), MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);		// sum all contributions.
  #endif

	double* rspec = nrj.append(8, " Sconv_U_l Sconv_U_m Sconv_B_l Sconv_B_m Sconv_T_l Sconv_T_m Sconv_C_l Sconv_C_m \t ");
	rspec[0] = sdU.Sconv[0];		rspec[1] = sdU.Sconv[1];
	rspec[2] = sdB.Sconv[0];		rspec[3] = sdB.Sconv[1];
	rspec[4] = sdT.Sconv[0];		rspec[5] = sdT.Sconv[1];
	rspec[6] = sdC.Sconv[0];		rspec[7] = sdC.Sconv[1];
//	printf("Sconv l = %g, %g, %g\n", sdU.Sconv[0],sdT.Sconv[0],sdB.Sconv[0]);
//	printf("Sconv m = %g, %g, %g\n", sdU.Sconv[1],sdT.Sconv[1],sdB.Sconv[1]);
  #ifdef XS_MPI
	MPI_Reduce((i_mpi==0) ? MPI_IN_PLACE : rspec, rspec, 8, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);		// max Sconv
  #endif

	if (i_mpi==0) {
		if (fnrj == 0) {
			std::string s = "energy." + std::string(job);
			fnrj = fopen(s.c_str(),"w");
		}
		if (nex==0) fprintf(fnrj, "%s", nrj.header.c_str());
		fprintf(fnrj,"\n%.10g\t %.10g %.10g %.10g %.10g\t %.10g\t",ftime, nrj[0], nrj[1], nrj[2], nrj[3], dt);		// record energies.
		for (int g=1, k=4; g<nrj.group.size(); g++) {
			for (int j=0; j<nrj.group[g]; j++) fprintf(fnrj," %.10g", nrj[k++]);		// record custom diags (if any).
			fprintf(fnrj, "\t");
		}
		fflush(fnrj);
		for (int k=0; k<8; k++)   if (rspec_max < rspec[k]) rspec_max = rspec[k];		// maximum of spectral convergence
	  #ifdef XS_RTC_TIMINGS
		printf("[it %d] t=%g, Eu=%g, Eb=%g, Et=%g, dt=%g  [Sconv=%g] (elapsed %g s for %ld evals)\n",iter,ftime,nrj[0], nrj[1], nrj[2], dt, rspec_max, treal, nex);
	  #else
		printf("[it %d] t=%g, Eu=%g, Eb=%g, Et=%g, dt=%g  [Sconv=%g]\n",iter,ftime,nrj[0], nrj[1], nrj[2],dt, rspec_max);
	  #endif
	  #ifdef XS_LINEAR
		if ((nrjUo > 0.0) || (nrjBo > 0.0)) {
			printf("        growth rate");
			if (nrjUo > 0.0) printf(" d|u|/|u|dt=%g", log(nrj[0]/nrjUo)/(2.*dt_log));
			if (nrjBo > 0.0) printf(" d|b|/|b|dt=%g", log(nrj[1]/nrjBo)/(2.*dt_log));
			printf("\n");
		}
	  #else
		if ((jpar.no_jxb) && (nrjBo > 0.0))
			printf("        growth rate d|b|/|b|dt=%g\n", log(nrj[1]/nrjBo)/(2.*dt_log));
	  #endif
	    if (rspec_max > 0.01) {
			if (rspec_max > 0.1) {
				printf("  !!! WARNING, bad spectral convergence !!!\n");
			} else {
				printf("  Warning, low spectral convergence.\n");
			}
		}
		fflush(stdout);
	}
	if ( isNaN(nrj[0]+nrj[1]+nrj[2]) ) runerr("NaN encountered");
	#ifndef XS_LINEAR
	if ((rspec_max >= 0.3)&&(iter > 0)) runerr("No spectral convergence. Increase resolution or decrease time-step or CFL factors.");
	#endif
}


int main (int argc, char *argv[])
{
	FILE *fnrj = NULL;
	double rmin, rmax;
	double tmp, b0, u0, gmax;
	int i;
	int iter_max, iter_save;
	long nbackup = 0;
	double treal = 0.;
	double tplot = 0.;
	double tsave;
  #ifdef XS_RTC_TIMINGS
	struct timeval time1, time2;
  #endif
	char command[100];

//	feenableexcept(FE_DIVBYZERO | FE_INVALID | FE_OVERFLOW);		// turn this on to track NaNs or other floating-point exceptions (requires gcc, #define _GNU_SOURCE and #include <fenv.h>)

#ifdef XS_MPI
  #ifndef _OPENMP
	MPI_Init(&argc, &argv);
  #else
	MPI_Init_thread(&argc, &argv, MPI_THREAD_FUNNELED, &i);		// init MPI with some thread support.
	if (i < MPI_THREAD_FUNNELED) runerr("MPI does not support multiple threads.");
  #endif
	MPI_Comm_rank(MPI_COMM_WORLD, &i_mpi);
	MPI_Comm_size(MPI_COMM_WORLD, &n_mpi);
#endif

	PRINTF0("[XSHELLS 2] eXtendable Spherical Harmonic Earth-Like Liquid Simulator\n          by Nathanael Schaeffer / CNRS, build %s, %s\n",__DATE__,__TIME__);
#ifdef XS_LINEAR
	PRINTF0("          ++ LINEAR,");
#else
	PRINTF0("          ++ Non-Linear,");
#endif
#ifdef XS_SPARSE
	PRINTF0(" Implicit Coriolis,");
	Eigen::initParallel();		// in order to call eigen from multiple threads.
#endif
	PRINTF0(" %ld bit version, id: " _HGID_ "\n",8*sizeof(void *));
#ifdef _OPENMP
	omp_set_dynamic(0);			// disable dynamic adjustment of the number of threads (use fixed number of threads).
	nthreads = omp_get_max_threads();		// number of threads.
	#if XS_OMP==1 && defined(XS_MKL)
		fftw3_mkl.number_of_user_threads = nthreads;		// required to call the fft of mkl from multiple threads.
	#endif
#endif
	PRINTF0("          ++ XSBIG using %d processes, with %d threads per process.\n", n_mpi, nthreads);

	read_Par(argc, argv);
	iter_max = jpar.iter_max;
	iter_save = jpar.iter_save;
	nbackup = jpar.nbackup;
	#ifdef XS_SPARSE
	if (jpar.dt_adjust != 0) runerr("Implicit Coriolis does not support dt_adjust yet!");
	#endif
	dt_adjust = jpar.dt_adjust;
	dt_log = 2.*dt*jpar.modulo;		// time interval between logs (legacy)
	for (int k=0; k<MAX_CFL; k++) C_cfl[k] = 1.0;
	C_cfl[cfl_ur] = jpar.C_u;		C_cfl[cfl_uh] = jpar.C_u;		C_cfl[cfl_w] = jpar.C_vort;
	C_cfl[cfl_br] = jpar.C_alfv;	C_cfl[cfl_bh] = jpar.C_alfv;	C_cfl[cfl_j] = jpar.C_vort;
	dt_tol_lo = jpar.dt_tol_lo;		dt_tol_hi = jpar.dt_tol_hi;
#ifndef XS_WRITE_SV
	if (lmax_out_sv) runerr("Surface data output not compiled.");
#endif
#ifndef XS_HYPER_DIFF
	if (hyper_diff_l0 > 0) runerr("Hyper-diffusivity not compiled.");
#endif

	if (ufile) evol_ubt |= EVOL_U;
	if (bfile) evol_ubt |= EVOL_B;
	if (tpfile) evol_ubt |= EVOL_T;
	if (cfile) evol_ubt |= EVOL_C;
	if (rfile) {		// load external grid
		if (!( load_Field_grid(rfile) || load_grid(rfile) )) {
			sprintf(command, "cannot read grid from file '%s' !", rfile);		runerr(command);
		}
	}
	if (evol_ubt == 0)	runerr("Nothing to do ?! at least u, b or tp must be defined.");
	if ((ufile == NULL) && (u0file == NULL)) runerr("No velocity field defined: solve the diffusion analytically ;-)");

	if (n_mpi > NR) runerr("Too many MPI processes. MPI processes cannot exceed NR (radial shell number).");
#if XS_OMP == 2
	if (nthreads > MMAX+1) runerr("Thread number cannot exceed Mmax+1. Use less threads or xsbig_hyb instead.");
	if (nthreads>1) {
		size_t l2m = (LMAX+1)*(LMAX+1)*(MMAX+1);
		if (l2m < 64*64*64*nthreads) PRINTF0("!!! WARNING !!! innefficient multi-threaded SHT due to low spherical harmonic resolution. Use less threads or xsbig_hyb instead.\n");
		if (l2m < 32*32*32*nthreads) runerr("too low spherical harmonic resolution for multi-threaded SHT. Use less threads or xsbig_hyb instead.");
	}
	if ((NR >= n_mpi*nthreads*4) || (NR % (n_mpi*nthreads) == 0)) PRINTF0("!!! WARNING !!! xsbig_hyb should be faster in this case !\n");
#else
	if (NR % (n_mpi*nthreads) != 0) {
		if (NR < n_mpi*nthreads*5) PRINTF0("!! WARNING !! optimal usage requires radial shells being a multiple of total threads.\n");
		if (NR < n_mpi*nthreads*3) runerr("Bad load balance. Reduce number of threads or processes, or try xsbig_hyb2 instead.");
	}
#endif

	#ifndef XS_LINEAR
	if ((jpar.parity & 1) && (jpar.no_ugradu == 0)) runerr("Odd parity not conserved by u.grad(u)");
	#endif

	init_sh(jpar.sht_type, jpar.polar_opt_max, NL_ORDER);
	#ifdef XS_VEC
		if (NLAT & (VSIZE-1)) runerr("NLAT must be a multiple of vector size !");
	#endif

	if (framecmd) {
		init_Frame(frame, framecmd, Omega0);
	} else {
		frame.set_rotation(Omega0, Omega0_angle);
	}
	if (frame.check_non_axial()) {
		#ifndef XS_LINEAR
		if (jpar.no_ugradu != 0) runerr("Non-axial global rotation not supported without u.grad(u). Use XS_LINEAR mode instead.\n");
		#endif
	}

	rmin = jpar.Rbs;		rmax = jpar.Rbe;
	if (rmin > jpar.Rus)	rmin = jpar.Rus;
	if (rmax < jpar.Rue)	rmax = jpar.Rue;
	if (rmin > jpar.Rts)	rmin = jpar.Rts;
	if (rmax < jpar.Rte)	rmax = jpar.Rte;
	init_rad_sph(rmin, jpar.Rus, jpar.Rue, rmax, jpar.Nin, jpar.Nout);
	#ifdef VAR_LTR
	init_ltr(jpar.rsat_ltr);
	#else
	if (jpar.rsat_ltr != 0.0) runerr("rsat_ltr != 0 needs variable l-truncation (VAR_LTR).");
	#endif

	srand( time(NULL) );		// we might need random numbers.
// set field limits :
	Blm.ir_bci = r_to_idx(jpar.Rbs);		Blm.ir_bco = r_to_idx(jpar.Rbe);
	Tlm.ir_bci = r_to_idx(jpar.Rts);		Tlm.ir_bco = r_to_idx(jpar.Rte);
	Clm.ir_bci = r_to_idx(jpar.Rcs);		Clm.ir_bco = r_to_idx(jpar.Rce);
// set solid body limits :
	InnerCore.set_limits(0, NG);
	Mantle.set_limits(NM, NR-1);

/* PRINT GRID */
	if (i_mpi == 0) {
		printf("[Grid] NR=%d => NG=%d, NM=%d, [rmin,rg,rm,rmax]=[%.4f, %.4f, %.4f, %.4f]\n       [dr(rmin), dr(rg), dr((NG+NM)/2), dr(rm), dr(rmax)]=[%.5e, %.5e, %.5e, %.5e, %.5e]\n", NR, NG,NM, r[0], r[NG], r[NM], r[NR-1], r[1]-r[0], r[NG+1]-r[NG], r[(NG+NM)/2+1]-r[(NG+NM)/2], r[NM]-r[NM-1], r[NR-1]-r[NR-2]);
		if ((r[0] != rmin)||(r[NR-1] != rmax)) printf("    !! Warning : rmin or rmax have changed !\n");
	}

#ifdef XS_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif

/* MEMORY ALLOCATION AND MATRIX INITIALIZATION */
	if (evol_ubt & EVOL_U) {
		Ulm.alloc(NG, NM, 2);		// 2 ghost shells for poloidal here
		Ulm.bci = (boundary) jpar.uBCin;	Ulm.bco = (boundary) jpar.uBCout;
		init_Umatrix(Ulm, jpar.nu);			Xlm.diff[::U] = jpar.nu;
		// don't conserve angular momentum if one of the boundaries is not free-slip :
		if ( ((r[Ulm.ir_bci]>0.)&&(Ulm.bci != BC_FREE_SLIP)) || (Ulm.bco != BC_FREE_SLIP) ) kill_sbr = 0;
	}
	if (evol_ubt & EVOL_B) {
		Blm.alloc(Blm.ir_bci, Blm.ir_bco, 1);		// 1 ghost shell is enough here
		Blm.bci = BC_MAGNETIC;	Blm.bco = BC_MAGNETIC;
		init_Bmatrix(Blm, jpar.eta);		Xlm.diff[::B] = jpar.eta;
	}
	if (evol_ubt & EVOL_T) {
		Tlm.alloc(Tlm.ir_bci, Tlm.ir_bco);
		Tlm.bci = (boundary) jpar.tBCin;	Tlm.bco = (boundary) jpar.tBCout;
		init_Tmatrix(Tlm, MT, MT_1, jpar.kappa);		Xlm.diff[::T] = jpar.kappa;
	}
	if (evol_ubt & EVOL_C) {
		Clm.alloc(Clm.ir_bci, Clm.ir_bco);
		Clm.bci = (boundary) jpar.cBCin;	Clm.bco = (boundary) jpar.cBCout;
		init_Tmatrix(Clm, MC, MC_1, jpar.kappa_c);	Xlm.diff[::C] = jpar.kappa_c;
	}
	Xlm.commit();
	Ylm.clone(Xlm);
	NL[0].clone(Xlm);
	NL[0].Su = new Spectral(1, NLM, Ulm.ir_bci, Ulm.ir_bco);		// shared storage for non-linear terms before curl
	NL[0].Sb = new Spectral(1, NLM, Blm.ir_bci, Blm.ir_bco);
	NL[1].clone(NL[0]);
	if (MAKE_MOVIE == 2) Xavg.clone(Xlm);		// alloc memory to store the time-averages...

	calc_Matrices(dt);

/* CHOOSE MPI BLOCK SIZE FOR LINEAR SOLVER */
	optimize_linear_solver();

/* TRY TO FIND RESTART DATA */
	if (jpar.allow_restart) {
		const char *sfx[] = {"_kill","_back",""};		// suffix to look for.
		char fname[240], ftest[240];
		int it_file = 0;
		int found = 0;
		char c='T';
		if (tpfile == NULL) {
			c='B';
			if (bfile == NULL)  c='U';
		}
		for (int k=0; k<3; k++) {
			sprintf(ftest, "field%c%s.%s",c,sfx[k],job);
			iter_from_file(ftest, &it_file);
			#ifdef XS_DEBUG
			PRINTF0("probing '%s' : it = %d\n",ftest, it_file);
			#endif
			if (it_file > iter) {
				strncpy(fname,  ftest, 239);
				iter = it_file;
				found = 1;
			}
		}
		if (found) {	// found.
			PRINTF0("=> restarting from iter=%d (%s)\n", iter, fname);
			if (iter == iter_max) runerr("job already finished.");
			if (ufile)  { strncpy(ufile,  fname, 239);	 ufile[5] = 'U'; }
			if (bfile)  { strncpy(bfile,  fname, 239);	 bfile[5] = 'B'; }
			if (tpfile) { strncpy(tpfile, fname, 239);	tpfile[5] = 'T'; }
			if (i_mpi==0) {
				sprintf(command, "energy.%s",job);		fnrj = fopen(command,"a");		// append to energy file.
				fprintf(fnrj, "\n");		// add new line.
			}
		}
	}

#ifdef XS_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif

/* INITIALIZATION OF FIELDS */

	/* INIT IMPOSED VELOCITY FIELD */
	u0 = 0.0;
	if (u0file) {
		#ifndef XS_LINEAR
			runerr("base velocity field is supported only for linear calculations.");
		#else
		PRINTF0("=> Imposed velocity field U0 :\n");
		PolTor* Vlm = new PolTor(NG,NM);
		Vlm->bci = BC_NONE;		Vlm->bco = BC_NONE;
		load_init(u0file, Vlm);
		u0 = Vlm->absmax(NG, NM);
		if (u0 == 0) runerr("zero imposed field. did you mean it ?\n");
		SpectralDiags sd(LMAX,MMAX);
		Vlm->energy(sd);
		int ltr = LMAX;
		int mtr = MMAX;
		sd.get_lmax_mmax(ltr, mtr);
		sprintf(command,"fieldU0.%s",job); 	Vlm->save_double(command, ltr, mtr);
		U0 = new SpatVect;
		U0->from_SH(*Vlm);
		if (Vlm->zero_curl == 0) {
			W0 = new SpatVect;
			W0->from_SH(*Vlm,1);		// curl
		} else PRINTF0("   Velocity field has no vorticity\n");
		delete Vlm;
		#endif
	}
	if (evol_ubt & EVOL_U) {
		tmp = 0.5*(jpar.Rus+jpar.Rue)*a_forcing;		// as we do not know which boundary will force, we use average radius.
		if (fabs(tmp) > fabs(u0)) u0 = tmp;		// maximum imposed velocity.
	}

	/* INIT MAGNETIC FIELDS */
	b0 = 0.0;
	if (evol_ubt & EVOL_B) {
		Blm.zero_out();
		PRINTF0("=> Initial magnetic field b :\n");
		ftime = load_init(bfile, &Blm);
		Blm.bci = BC_MAGNETIC;		Blm.bco = BC_MAGNETIC;		// reset the right BC for magnetic field.
		if (own(Blm.ir_bci)) {
			InnerCore.set_external_B(Blm.Pol[Blm.ir_bci-1]);		// copy boundary condition for future evolution.
			if (InnerCore.PB0lm != NULL) printf("   + Potential field imposed at inner boundary (lmax=%d, mmax=%d).\n", InnerCore.lmax, MRES*InnerCore.mmax);
		}
		if (own(Blm.ir_bco)) {
			Mantle.set_external_B(   Blm.Pol[Blm.ir_bco+1]);
			if (Mantle.PB0lm != NULL)    printf("   + Potential field imposed at outer boundary (lmax=%d, mmax=%d).\n", Mantle.lmax, MRES*Mantle.mmax);
		}
		b0 = Blm.absmax(NG, NM);		// max value of magnetic field in fluid domain.

		#ifdef XS_WRITE_SV
		if (lmax_out_sv) {
			Bp1 = (cplx *) malloc(4*NLM * sizeof(cplx));
			if (Bp1==0) runerr("lmax_out_sv allocation error");
			Bp2 = Bp1 + NLM;
			Up1 = Bp1 + 2*NLM;		Ut1 = Bp1 + 3*NLM;
			memset(Bp1, 0, 4*NLM*sizeof(cplx));
		}
		#endif
		if (b0file) {
			#ifndef XS_LINEAR
				runerr("base magnetic field supported only for linear calculations, use boundary conditions instead.");
			#else
			PRINTF0("=> Imposed magnetic field B0 :\n");
			PolTor* Vlm = new PolTor(Blm.ir_bci,Blm.ir_bco);
			Vlm->bci = BC_MAGNETIC;		Vlm->bco = BC_MAGNETIC;
			load_init(b0file, Vlm);
			b0 = Vlm->absmax(NG, NM);
			if (b0 == 0) runerr("zero imposed field. did you mean it ?\n");
			SpectralDiags sd(LMAX,MMAX);
			Vlm->energy(sd);
			int ltr = LMAX;
			int mtr = MMAX;
			sd.get_lmax_mmax(ltr, mtr);
			sprintf(command,"fieldB0.%s",job); 	Vlm->save_double(command, ltr, mtr);
			B0 = new SpatVect;
			B0->from_SH(*Vlm);
			if (Vlm->zero_curl == 0) {
				J0 = new SpatVect;
				J0->from_SH(*Vlm,1);		// curl
			} else PRINTF0("   Magnetic field is current-free\n");
			delete Vlm;
			#endif
		}
	}

	/* INIT TEMPERATURE FIELDS */
	gmax = 0.0;
	if (evol_ubt & EVOL_T) {
		if (phi0file) {		/* INIT IMPOSED GRAVITY */
			StatSpecScal *Phi0 = NULL;
			ScalarSH *Phi = new ScalarSH(0, NR-1);
			PRINTF0("=> Imposed gravity potential Phi0 :\n");
			load_init(phi0file, Phi);
			i = Phi->make_static(&Phi0);
			if (i == 0) runerr("Imposed potential field has 0 modes !");		// probably something is wrong...
			PRINTF0("   + Imposed potential field has %d modes (l<=%d, m<=%d).\n",i,Phi0->lmax,Phi0->mmax);
			sprintf(command,"fieldPhi0.%s",job); 	Phi->save_double(command, Phi0->lmax, Phi0->mmax/MRES);
			if (evol_ubt & EVOL_U) {
				if  (Phi0->lmax == 0) {
					Grav0_r = (double*) malloc(sizeof(double) * (NM-NG+1));
					if (Grav0_r==0) runerr("Grav0_r allocation error");
					Grav0_r -= NG;		// shift to access fluid shells.
					for (i=NG; i<=NM; i++) {
						Grav0_r[i] = Phi0->TdT[2*i+1].real() * r_1[i] * (1.0/Y00_1);		// dPhi/dr already computed.
						if (fabs(Grav0_r[i]*r[i]) > gmax) gmax = fabs(Grav0_r[i]*r[i]);		// record gmax
					}
					if (r[NG] == 0.0) {		// Gravity is zero, but Gravity/r is not. Compute it assuming dPhi0/dr = 0 because l=0
						int i = NG;
						Grav0_r[0] = (2.0/Y00_1) * ( Phi0->TdT[2*(i+1)].real() - Phi0->TdT[2*i].real() )/(r[i+1]*r[i+1]);		// 2*(T(dr)-T(0))/dr^2 
					}
					write_vect_npy("g_r.npy", &Grav0_r[NG], NM-NG+1);
				} else {
					Grav0_r = NULL;		// no central gravity.
					// we need a spatial gravity field...
					#ifdef XS_LINEAR
					gradPhi0 = new SpatVect;
					gradPhi0->from_SH(*Phi);
					gmax = gradPhi0->absmax2();
					#else
					gradPhi0 = new spat_vect[NR];
					size_t nr = Ulm.ire-Ulm.irs+1;		// only needed in the fluid.
					void* mem = fftw_malloc(nr*3*sizeof(double)*shtns->nspat);
					if (mem==0) runerr("Not enough memory for gravity field.");
					cplx* Q = (cplx*) fftw_malloc(2*NLM*sizeof(cplx));
					cplx* S = Q + NLM;
					for (int ir=Ulm.irs; ir<=Ulm.ire; ir++) {
						mem = gradPhi0[ir].alloc(shtns->nspat, mem);		// allocate shells in the fluid
						Phi->Gradr(ir, Q, S);		// compute gradient
						SH_SPAT(Q, gradPhi0[ir].r);
						SHS_SPAT(S, gradPhi0[ir].t, gradPhi0[ir].p);
						double gr = absmax2(gradPhi0[ir].r, gradPhi0[ir].t, gradPhi0[ir].p, 0, NLAT*NPHI);
						if (gr > gmax) gmax = gr;
					}
					fftw_free(Q);
					#endif
					gmax = sqrt(gmax);
				}
				#ifdef XS_MPI
				MPI_Allreduce( MPI_IN_PLACE, &gmax, 1, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD );
				#endif
				if (gmax == 0.0) runerr("zero gravity, something wrong ?");
			}
			free_StatSpecScal(Phi0);
			delete Phi;
		} else {
			Grav0_r = NULL;
			PRINTF0("=> No gravity field, temperature treated as a passive scalar.");
		}
		if (tp0file) {
			PRINTF0("=> Imposed Temperature field T0 :\n");
			load_init(tp0file, &Tlm);
			i = Tlm.make_static(&T0lm);
			if (i == 0) runerr("Imposed temperature field has 0 modes !");		// probably something is wrong...
			#ifdef XS_LINEAR
			if (T0lm->lmax > 0) {
				gradT0 = new SpatVect;
				gradT0->from_SH(Tlm);
			}
			#endif
			PRINTF0("   + Imposed temperature field has %d modes (l<=%d, m<=%d).\n",i,T0lm->lmax,T0lm->mmax);
			sprintf(command,"fieldT0.%s",job); 	Tlm.save_double(command, T0lm->lmax, T0lm->mmax/MRES);
			Tlm.bci = (boundary) jpar.tBCin;	Tlm.bco = (boundary) jpar.tBCout;		// reset the right BC for Tlm
		}
		PRINTF0("=> Temperature field boundary conditions (%d, %d)\n",Tlm.bci, Tlm.bco);

		PRINTF0("=> Initial temperature field t :\n");
		ftime = load_init(tpfile, &Tlm);
		Tlm.bci = (boundary) jpar.tBCin;		Tlm.bco = (boundary) jpar.tBCout;		// reset the right BC.
		if (Tlm.bci == BC_ZERO) Tlm.zero_out_shell(Tlm.ir_bci);	// ensure zero boundary conditions.
		if (Tlm.bco == BC_ZERO) Tlm.zero_out_shell(Tlm.ir_bco);
	
		if (evol_ubt & EVOL_C) {
			if (c0file) {
				PRINTF0("=> Imposed composition field C0 :\n");
				load_init(c0file, &Clm);
				i = Clm.make_static(&C0lm);
				if (i == 0) runerr("Imposed composition field has 0 modes !");		// probably something is wrong...
				#ifdef XS_LINEAR
				if (C0lm->lmax > 0) {
					gradC0 = new SpatVect;
					gradC0->from_SH(Clm);
				}
				#endif
				PRINTF0("   + Imposed composition field has %d modes (l<=%d, m<=%d).\n",i,C0lm->lmax,C0lm->mmax);
				sprintf(command,"fieldC0.%s",job); 	Clm.save_double(command, C0lm->lmax, C0lm->mmax/MRES);
				Clm.bci = (boundary) jpar.cBCin;	Clm.bco = (boundary) jpar.cBCout;		// reset the right BC for Clm
			}
			PRINTF0("=> Composition field boundary conditions (%d, %d)\n",Clm.bci, Clm.bco);

			PRINTF0("=> Initial composition field c :\n");
			ftime = load_init(cfile, &Clm);
			Clm.bci = (boundary) jpar.cBCin;		Clm.bco = (boundary) jpar.cBCout;		// reset the right BC.
			if (Clm.bci == BC_ZERO) Clm.zero_out_shell(Clm.ir_bci);	// ensure zero boundary conditions.
			if (Clm.bco == BC_ZERO) Clm.zero_out_shell(Clm.ir_bco);
		}
	}

	/* HANDLE Non-Linear terms related to base flow  (J0xB0, U0xW0, rho0.grad(Phi0)) */
	// unsupported.

	/* INIT VELOCITY FIELDS */
	if (evol_ubt & EVOL_U) {
		PRINTF0("=> Velocity field boundary conditions (%d, %d)\n",Ulm.bci, Ulm.bco);
		#ifdef U_FORCING
			PRINTF0("=> Forcing : " U_FORCING "\n");
			if ( (MRES*MMAX < FORCING_M) || (FORCING_M % MRES) ) {
				sprintf(command, "forcing requires mode m=%d !", FORCING_M);
				runerr(command);
			}
			if (w_forcing > 0.0) {
				PRINTF0("   + Time-localized forcing on time-scale t_forcing=%f\n",2.*M_PI/w_forcing);
			} else if (w_forcing < 0.0) {
				PRINTF0("   + Periodic forcing with pulsation w_forcing=%f\n",-w_forcing);
			}
		#else
			PRINTF0("=> No boundary forcing\n");
		#endif
		if (i_mpi==0) fflush(stdout);

		Ulm.zero_out();
		if (ufile) {
			PRINTF0("=> Initial velocity field u :\n");
			ftime = load_init(ufile, &Ulm);
	// *****  Feature request by Elliot Kaplan : ****
			double a = mp.var["randa"];
			if (a != 0.0) {
				Ulm.add_random(a, 0, MMAX, 1);		// add random noise on the odd symmetry.
				PRINTF0("=> Anti-symmetric random noise added to velocity field.\n");
			}
	// *****  end of feature request by Elliot Kaplan. ****
			Ulm.bci = (boundary) jpar.uBCin;		Ulm.bco = (boundary) jpar.uBCout;		// reset the right BC.
			if (Ulm.bci == BC_ZERO) Ulm.zero_out_shell(Ulm.ir_bci);	// ensure zero boundary conditions.
			if (Ulm.bco == BC_ZERO) Ulm.zero_out_shell(Ulm.ir_bco);
			tmp = Ulm.absmax(NG, NM);
			if (tmp > fabs(u0)) u0 = tmp;
			// save solid body rotation to SolidBodies:
			if ((Ulm.bci == BC_NO_SLIP)&&(own(Ulm.ir_bci))) InnerCore.set_rotation(r[Ulm.ir_bci], Ulm.Tor[Ulm.ir_bci]);
			if ((Ulm.bco == BC_NO_SLIP)&&(own(Ulm.ir_bco))) Mantle.set_rotation(r[Ulm.ir_bco], Ulm.Tor[Ulm.ir_bco]);
		}
		#ifdef XS_SET_BC
			if (a_forcing != 0.0) set_U_bc(a_forcing);		// set arbitray boundary conditions.
		#endif
		if (kill_sbr) 	conserve_momentum(Ulm, kill_sbr);		// save initial momentum.
		if (ffile != NULL) {
			PRINTF0("=> Constant volumic forcing f :\n");
			runerr("unsupported.");
		}
		#ifdef XS_BULK_FORCING
			bulk_forcing.init(mp, Xlm);
		#endif
	}

	if (iter==0) {
		if (MMAX>0) {
			double enz = 0;
			SpectralDiags sd(LMAX,MMAX);
			for (int f=0; f<MAXFIELD; f++) {
				if (evol_ubt & EVOL(f)) {
					Xlm[f].energy(sd);
					enz += sd.energy_nz();		// sum non-zonal parts
				}
			}
			#ifdef XS_MPI
				MPI_Allreduce(MPI_IN_PLACE, &enz, 1, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
			#endif
			if (enz == 0) {		// if non-zonal energy is zero, add some random noise for m>0
				PRINTF0("=> adding random noise to m>0\n");
				if (evol_ubt & EVOL_U) Ulm.add_random(u0*1e-3, 1, MMAX, 0);
				if (evol_ubt & EVOL_B) Blm.add_random(b0*1e-3, 1, MMAX, 0);
			}
		}
		for (int f=0; f<MAXFIELD; f++) {
			if (evol_ubt & EVOL(f)) {
				sprintf(command,"field%c_0000.%s",symbol[f],job);
				Xlm[f].save_generic(command, LMAX, MMAX, ftime,0,0, jpar.prec_out);
			}
		}
	}

	#ifdef XS_MPI
		// sync halo
		for (int f=0; f<MAXFIELD; f++) {
			if (evol_ubt & EVOL(f))  Xlm[f].sync_mpi();
		}
	#endif

  if (i_mpi == 0) {
/* PRINT PARAMS */
	printf("[Params] job name : ***  %s  ***\n",job);
	if (Omega0 != 0.0)
	printf("         Ek=%.2e, Ro=%.2e, Elsasser=%.2e, Lehnert=%.2e\n",jpar.nu/Omega0, u0/Omega0, b0*b0/(jpar.eta*Omega0), b0/Omega0);
	printf("         Pm=%.2e, Re=%.2e, S=%.2e, N=%.2e, M=%.2e\n",jpar.nu/jpar.eta, u0/jpar.nu, b0/jpar.eta, b0*b0/(u0*u0) , b0/sqrt(jpar.nu*jpar.eta));
	if (gmax)
	printf("         Pr=%.2e, gmax=%.2e, DeltaT=%.2e, Ra=%.2e, N^2=%.2e\n",jpar.nu/jpar.kappa, gmax, 0.0, gmax/(jpar.nu*jpar.kappa), 0.0);		// TODO: compute numbers.
	printf("         dt.Omega=%.2e, dt.nu.R^2=%.2e, dt.eta.R^2=%.2e\n",dt*Omega0, dt*jpar.nu*rmax*rmax, dt*jpar.eta*rmax*rmax);
  }

/* CHECK GRID RESOLUTION */
	if ((evol_ubt & EVOL_U) && (i_mpi==0)) {
		if (jpar.nu/(Omega0*r[Ulm.ir_bco]*r[Ulm.ir_bco]) < 1.0) {		// Ekman layers may exist
			double d = sqrt(jpar.nu/fabs(Omega0));		// Ekman layer thickness
			int nin = r_to_idx(r[Ulm.ir_bci]+d) - Ulm.ir_bci;
			int nout = Ulm.ir_bco - r_to_idx(r[Ulm.ir_bco]-d);
			printf("  points in inner and outer Ekman layers (thickness = %g): %d and %d.\n", d, nin, nout);
			if ((Ulm.bci != BC_FREE_SLIP) && (nin < 5))  printf("    !! Warning : inner Ekman layer underresolved !\n");
			if ((Ulm.bco != BC_FREE_SLIP) && (nout < 5)) printf("    !! Warning : outer Ekman layer underresolved !\n");
		}
	}

// Initializing signal handler.
	#ifndef XS_MPI
		signal(30,&sig_handler);	signal(31,&sig_handler);	signal(15,&sig_handler);
	#endif
	for (int f=0; f<MAXFIELD; f++) {
		if (evol_ubt & EVOL(f)) {
			NL[0][f].zero_out();		NL[1][f].zero_out();
		}
	}

/* DETERMINE WHAT NEEDS TO BE COMPUTED */
	if (evol_ubt & EVOL_U) {		// for Navier-Stokes equation
		PRINTF0("=> Navier-Stokes integration\n");
		if (jpar.no_ugradu == 0) spat_need |= NEED_U | NEED_W;		// u.grad u
		if ((evol_ubt & EVOL_B) && (jpar.no_jxb == 0)) spat_need |= NEED_B | NEED_J;		// Laplace force.
		if (gradPhi0) {
			if (evol_ubt & EVOL_T) spat_need |= NEED_T;				// spatial temperature
			if (evol_ubt & EVOL_C) spat_need |= NEED_C;				// spatial temperature
		}
	}
	if (evol_ubt & EVOL_B) {		// for Induction equation
		PRINTF0("=> Induction integration\n");
		spat_need |= NEED_U | NEED_B;
	}
	if (evol_ubt & EVOL_T) {		// for energy equation
		PRINTF0("=> Temperature integration\n");
		spat_need |= NEED_U | NEED_GT;
	}
	if (evol_ubt & EVOL_C) {		// for energy equation
		PRINTF0("=> Composition integration\n");
		spat_need |= NEED_U | NEED_GC;
	}
	#ifdef XS_LINEAR
		spat_need = 0;
		if (evol_ubt & EVOL_U) {
			if (U0) spat_need |= NEED_W;
			if (W0) spat_need |= NEED_U;
			if (B0) spat_need |= NEED_J;
			if (J0) spat_need |= NEED_B;
			if (gradPhi0) {
				if (evol_ubt & EVOL_T) spat_need |= NEED_T;
				if (evol_ubt & EVOL_C) spat_need |= NEED_C;
			}
			if (nonlin && strstr(nonlin, "ugu"))	spat_need |= NEED_UXW | NEED_U | NEED_W;
			if (frame.check_non_axial())	spat_need |= NEED_COR | NEED_U;		// Coriolis force needs to be computed as spatial terms.
			#ifdef XS_CORIOLIS_BASE
			if (!frame.check_inertial()) {
				spat_need |= NEED_COR | NEED_U;	// There is a Coriolis force, we need to compute it spatilly for the base flow.
				PRINTF0("**WARNING** adding forcing due to Coriolis force of base flow (XS_CORIOLIS_BASE).\n");
			}
			#endif
		}
		if (evol_ubt & EVOL_B) {
			if (U0) spat_need |= NEED_B;
			if (B0) spat_need |= NEED_U;
			if (nonlin) {
				if (strstr(nonlin, "uxb"))	spat_need |= NEED_UXB | NEED_B | NEED_U;
				if (strstr(nonlin, "jxb"))	spat_need |= NEED_JXB | NEED_J | NEED_B;
			}
		}
		if (evol_ubt & EVOL_T) {
			if (U0) spat_need |= NEED_GT;
			if (gradT0) spat_need |= NEED_U;
			if (nonlin && strstr(nonlin, "ugt"))	spat_need |= NEED_UGT | NEED_GT | NEED_U;
		}
		if (evol_ubt & EVOL_C) {
			if (U0) spat_need |= NEED_GC;
			if (gradC0) spat_need |= NEED_U;
			if (nonlin && strstr(nonlin, "ugc"))	spat_need |= NEED_UGC | NEED_GC | NEED_U;
		}
	#else
		if (nonlin) PRINTF0("**WARNING** Non-Linear term selection through 'nonlin' is only available when compiled with XS_LINEAR\n");
	#endif
	#ifdef XS_DEBUG
		PRINTF0("*DEBUG*:");
		PRINTF0("  evol_ubt = %d%d%d  spat_need = %d\n",(evol_ubt & EVOL_U) > 0, (evol_ubt & EVOL_B) > 0, (evol_ubt & EVOL_T) > 0, spat_need);
	#endif

	if (jpar.parity) {		// filter parity (for U and T only)
		if (evol_ubt & EVOL_U) Ulm.filter_parity(jpar.parity);
		if (evol_ubt & EVOL_T) Tlm.filter_parity(jpar.parity);
		if (evol_ubt & EVOL_C) Clm.filter_parity(jpar.parity);
	}
	#ifdef XS_SPARSE
	xs_sparse::prepare_state(Xlm, jpar.parity);				// sparse evolution matrices and state vectors.
	#endif

/* PREPARE FIRST ITERATION */
	PRINTF0("let's go for %d iterations ! (%g sub-steps each, PC2)\n",iter_max, dt_log/(2*dt));
	for (int k=0; k<MAX_CFL; k++) dt_cfl[k] = 0.0;
	frame.update(ftime);
	calc_U_solid();
	#if XS_OMP == 1
	#pragma omp parallel
	#endif
	{
		// allocate temporary fields for each shell (private).
	  #if XS_OMP == 2
		using namespace spatial_buffers;
		size_t Nspec = 0;		size_t Nspat = 0;
		if (spat_need & NEED_U) {  Nspec += 2;		Nspat += 3;	 }
		if (spat_need & NEED_B) {  Nspec += 2;		Nspat += 3;	 }
		if (spat_need & NEED_GT) { Nspec += 2;		Nspat += 3;	 }
		if (spat_need & NEED_GC) { Nspec += 2;		Nspat += 3;	 }
		if (spat_need & NEED_W) {  Nspec += 3;		Nspat += 3;	 }
		if (spat_need & NEED_J) {  Nspec += 3;		Nspat += 3;	 }
		if (spat_need & (NEED_T|NEED_C)) Nspat += 1;
		if ((spat_need & (NEED_T|NEED_C)) == (NEED_T|NEED_C)) Nspec += 1;		// if both terms are present we need to add them.
		spat_mem = (double*) fftw_malloc(sizeof(double)*(Nspec*2*NLM + Nspat*shtns->nspat));		// big buffer !
		if (!spat_mem)	runerr("not enough memory for spatial buffers.\n");
		void * mem = spat_mem;		size_t nspat_alloc = shtns->nspat;
		if (spat_need & NEED_U) mem = u.alloc(nspat_alloc, NLM, mem, 2);
		if (spat_need & NEED_W) mem = w.alloc(nspat_alloc, NLM, mem);
		if (spat_need & NEED_B) mem = b.alloc(nspat_alloc, NLM, mem, 2);
		if (spat_need & NEED_J) mem = j.alloc(nspat_alloc, NLM, mem);
		if (spat_need & NEED_GT) mem = gt.alloc(nspat_alloc, NLM, mem, 2);		// only two spectral components needed here
		if (spat_need & NEED_GC) mem = gc.alloc(nspat_alloc, NLM, mem, 2);		// only two spectral components needed here
		if (spat_need & (NEED_T|NEED_C)) {
			tspat = (double*) mem;			// spatial buoyancy (temperature+composition)
			tspec = (cplx*) (tspat + nspat_alloc);		// spectral buoyancy (if needed)
		}
	  #else
		#ifdef XS_LINEAR
		long nf = 6;
		if (evol_ubt & EVOL_U) nf += 3;
		if (evol_ubt & EVOL_B) nf += 3;
		if (evol_ubt & (EVOL_T | EVOL_C)) nf += 1;
		spat_mem = (double*) fftw_malloc(sizeof(double)*(6*NLM + nf*shtns->nspat));
		#else
		spat_mem = (double*) fftw_malloc(sizeof(double)*(6*NLM + 9*shtns->nspat));
		#endif
		if (!spat_mem)	runerr("not enough memory for spatial buffers. Try xsbig_hyb2 instead.\n");
	  #endif
	}
	#ifdef XS_DEBUG
	PRINTF0("    CFL parameters: dt_tol_lo=%g, dt_tol_hi=%g, C_u=%g, C_vort=%g, C_b=%g, C_j=%g, C_cori=%g\n",dt_tol_lo, dt_tol_hi, C_cfl[cfl_ur], C_cfl[cfl_w], C_cfl[cfl_br], C_cfl[cfl_j], jpar.C_cori);
	#endif

	nrj_and_summed_diagnostics(fnrj);

	#ifndef XS_NOPLOT
	Gnuplot plot;
	if (i_mpi == 0) {
		plot.init("energy." + std::string(job) + ".png", jpar.plot);
		plot.cmd("set style data linespoints\n");
		plot.cmd("set logscale y 10\n");
		plot.cmd("set title '" + std::string(job) + "'\n");
		plot.cmd("set xlabel 'time';  set ylabel 'energy'\n");
		plot.set_plotcmd("plot 'energy." + std::string(job) + "' using 1:2 title 'Eu', '' using 1:3 title 'Eb'\n");
		plot.plot();
	} else {
		 jpar.plot = 0;		// only MPI rank 0 does the plotting.
	}
	#endif

/* MAIN LOOP */
	#ifdef XS_RTC_TIMINGS
		gettimeofday(&time1, NULL);
	#endif
	tsave = 0.;			tsave_limit *= 60.;		// convert time-limit to seconds
	while (iter < iter_max) {

		long nex = step_UBT(dt_log);	// go for time integration !!

		#ifdef XS_RTC_TIMINGS
			gettimeofday(&time2, NULL);
			treal = tdiff(&time1, &time2);
			tsave += treal;  // elapsed time since last save (or iteration number if less than 1 sec)
		#endif

		iter++;

		// compute energies and other diagnostics summed between processes.
		nrj_and_summed_diagnostics(fnrj, treal, nex);
		#ifndef XS_NOPLOT
		if ((jpar.plot)&&(tsave-tplot >= 2.)) {		// at least two seconds have passed.
			tplot = tsave;
			plot.plot();
		}
		#endif

		if (tsave + treal*1.05 >= tsave_limit) SAVE_QUIT |= 1;       // save full fields if more than tsave_limit will be elapsed at next iteration
		#ifdef XS_MPI
			MPI_Bcast((void*) &SAVE_QUIT, 1, MPI_CHAR, 0, MPI_COMM_WORLD);		// Broadcast SAVE_QUIT information.
		#endif
		if (SAVE_QUIT) {
			save_snapshot();
			SAVE_QUIT &= 6;		tsave = 0.;		// mark snapshot as saved.
			nbackup--;
			if (nbackup == 0) SAVE_QUIT |= 2;      // don't continue if it is our last backup
		}

		#ifdef XS_WRITE_SV
		if (lmax_out_sv) {
			if ((evol_ubt & EVOL_B)&&(own(Bp_i1))) { sprintf(command,"UBsurf_vs_%05d.%s",iter,job);		write_SV(command,lmax_out_sv); }
		}
		#endif
		if ((MAKE_MOVIE != 0)&&(iter % iter_save == 0)) {		// save single-precision data snapshot.
			i = iter/iter_save;
			for (int f=0; f<MAXFIELD; f++) {
				if (evol_ubt & EVOL(f)) {
					sprintf(command,"field%c_%04d.%s",symbol[f],i,job);
					Xlm[f].save_generic(command, jpar.lmax_out, jpar.mmax_out, ftime,iter,0, jpar.prec_out);
				}
			}
			if (MAKE_MOVIE == 2) {
				tmp = 1.0/n_stack;
				for (int f=0; f<MAXFIELD; f++) {
					if (evol_ubt & EVOL(f)) {
						sprintf(command,"field%cavg_%04d.%s",symbol[f],i,job);
						Xavg[f] *= tmp;		// rescale
						Xavg[f].save_generic(command, jpar.lmax_out, jpar.mmax_out, ftime,iter,0, jpar.prec_out);
						Xavg[f].zero_out();
					}
				}
				n_stack = 0;
			}
		}
		if (SAVE_QUIT & 6) {
			PRINTF0("save & quit\n");
			break;
		}

		#ifdef XS_RTC_TIMINGS
			gettimeofday(&time1, NULL);
			treal = tdiff(&time2, &time1);
			#ifdef XS_DEBUG
			if ((i_mpi==0) && (treal > 1e-2)) printf("\tpost-process and saving time : %g\n", treal);
			#endif
			tsave += treal;
		#endif
	}

	if (fnrj) fclose(fnrj);
	// save full double-precision data at the end (for restart)
	save_snapshot();
	#ifndef XS_NOPLOT
	if (i_mpi==0) plot.save();		// always save plot to png at the end.
	#endif
#ifdef XS_MPI
	MPI_Finalize();
#endif
	if (iter < iter_max) return(2);     // resubmit job
	PRINTF0("[XSHELLS] job %s completed.\n",job);
	return(0);
}
