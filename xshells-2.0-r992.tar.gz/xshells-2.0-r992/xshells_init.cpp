/*
 * Copyright (c) 2010-2016 Centre National de la Recherche Scientifique.
 * written by Nathanael Schaeffer (CNRS, ISTerre, Grenoble, France).
 * 
 * nathanael.schaeffer@univ-grenoble-alpes.fr
 * 
 * This software is governed by the CeCILL license under French law and
 * abiding by the rules of distribution of free software. You can use,
 * modify and/or redistribute the software under the terms of the CeCILL
 * license as circulated by CEA, CNRS and INRIA at the following URL
 * "http://www.cecill.info".
 * 
 * The fact that you are presently reading this means that you have had
 * knowledge of the CeCILL license and that you accept its terms.
 * 
 */

/// \file xshells_init.cpp initialization and parameter reading functions.

#include <vector>

/// Class to record diagnostics.
class diagnostics : public std::vector<double> {
	int header_groups;
  public:
	std::string header;
	std::vector<int> group;
	void reset() {
		resize(0);
		group.resize(0);
	}
	/// adds n elements to the diagnostic vector and returns a pointer to the first added element.
	/// the caller can then simply fill the reserved elements with values.
	double* append(const int n, const char *s = 0) {
		if (n<=0) return 0;
		int ofs = size();
		resize(ofs+n);			// this may trigger reallocation; also sets the new values to zero.
		group.push_back(n);		// a new group with n entries
		if (group.size() > header_groups) {	// append header info for the new group
			if (s) {
				header += std::string(s);
			} else {
				for (int k=0; k<n; k++) header += "? ";
				header += "\t ";
			}
			header_groups ++;
		}
		return &((*this)[ofs]);
	}
};


/* INITIAL OR IMPOSED FIELDS */
#if defined(XS_LEGACY) || defined(XS_LINEAR)
#define CURRENT_FREE Blm.zero_curl = 1;		// mark field as current free
#else
#define CURRENT_FREE 0;
#endif

#define BEGIN_FIELD(field_name, desc) \
	if (strcmp(name,field_name) == 0) { \
		if (i_mpi==0) printf("   + predefined field '%s' : %s\n", name, desc);
#define END_FIELD return(1); }

/// This function is called to set initial magnetic field value. (see xshells.par)
int init_B0(PolTor &Blm, char *name, double b0, char *args)
{
	cplx z;		// temp variable.
	double rr, v;
	int i,l,m;
	int irs = Blm.ir_bci;
	int ire = Blm.ir_bco;

BEGIN_FIELD( "dipoleBC", "dipolar boundary conditions (imposed)")
	CURRENT_FREE	// mark magnetic field as current-free
	char d = args[0];
	switch(d) {
		case 'o' : i=ire+1;		break;
		case 'i' : i=irs-1;
	}
	l=1;
		Blm.set_Prlm(i, l, 0, b0 * Y10_ct );
END_FIELD

BEGIN_FIELD( "uniform", "uniform field (imposed)" )
	CURRENT_FREE	// mark magnetic field as current-free
	l=1;
	char d = args[0];
	switch(d) {
		case 'x' : m=1;		z = Y11_st;
			break;
		case 'y' : m=1;		z = cplx(0,Y11_st);
			break;
		default : d = 'z';
		case 'z' : m=0;		z = Y10_ct;		// Y10_ct  makes it unitary in physical space.
	}
	PRINTF0("   + along %c axis\n", d);
	for (i=irs; i <= ire+1; i++) {		// impose at outer boundary.
		rr = Blm.radius(i);
		Blm.set_Prlm(i, l, m,  b0*z* rr/2. );
	}
END_FIELD

BEGIN_FIELD( "dipole", "current-free internal dipole (imposed)" )
	CURRENT_FREE	// mark magnetic field as current-free
	l=1;
	if (r[irs] == 0) runerr("internal dipole singular at r=0");
	char d = args[0];
	switch(d) {
		case 'x' : m=1;		z = Y11_st;
			break;
		case 'y' : m=1;		z = cplx(0, Y11_st);
			break;
		default : d = 'z';
		case 'z' : m=0;		z = Y10_ct;
	}
	PRINTF0("   + along %c axis\n", d);
	for (i=irs-1; i <= ire; i++) {
		rr = Blm.radius(i);
		Blm.set_Prlm(i, l, m,  b0* z/(2.*rr*rr) );
	}
END_FIELD

BEGIN_FIELD( "bigsister", "bigsister current loop (imposed)" )
	CURRENT_FREE	// mark magnetic field as current-free
	double rloop = 1.89/1.46 * r[NM];
	int ltr = 11;
	m=0;
	for (i=irs; i <= ire+1; i++) {		// include boundary forcing.
		double rr = (Blm.radius(i)/rloop);
		double f = b0*sqrt(4./(3.*M_PI));		// normalization: |B(r=0)| = b0
		for (l=1; l <= ltr; l+=2) {
			Blm.set_Prlm(i, l, m, pow(rr, l) * f * sqrt(4*M_PI/(2*l+1)) );
			f *= -l/(l+3.);
		}
	}
END_FIELD

BEGIN_FIELD( "bench2001", "magnetic field used in Christensen et al 2001 for case 1" )
	for (i=irs; i <= ire; i++) {
		rr = Blm.radius(i);
		double rs4 = r[irs]*r[irs]/rr;		rs4 *= rs4;
		l=1;	m=0;
			z = (4*r[ire]*rr - 3*rr*rr - rs4)/8 * Y10_ct;
			Blm.set_Prlm(i, l, m,  b0* z );
		l=2;	m=0;
			z = sin(M_PI*(rr - r[irs])) * 4/3*sqrt(M_PI/5);
			Blm.set_Trlm(i, l, m, b0 * z );
	}
END_FIELD

BEGIN_FIELD( "bench2001_2", "magnetic field used in Christensen et al 2001 for case 2" )
	for (i=irs; i <= ire; i++) {
		rr = Blm.radius(i);
		double r2 = rr*rr;
		l=1;	m=0;
			z = (4*r[ire]*rr - 3*r2)/(6 + 2*r[ire]) * Y10_ct;
			Blm.set_Prlm(i, l, m,  b0* z );
		l=2;	m=0;
			z = sin(M_PI*rr/r[ire]) * 4/3*sqrt(M_PI/5);
			Blm.set_Trlm(i, l, m, b0 * z );
	}
END_FIELD


BEGIN_FIELD( "bench_fs", "initial magnetic field for the full-sphere benchmark" )
	b0 *= sqrt(4.*M_PI);
	for (i=irs; i<=ire; i++) {
		rr = Blm.radius(i);		double r2 = rr*rr;		double r4 = r2*r2;		double r6 = r4*r2;
		l=1;	m=1;
			z = b0 *rr*(3 -12*r2 +18*r4 -9*r6)/4 * cplx(1,1);
			if ((i>irs)&&(i<ire))
				Blm.set_Trlm(i, l, m, z * sqrt(2./3) );
		l=2;	m=0;
			z = b0 *r2*(6 -21*r2 +27*r4 -12*r6)/4;
			if ((i>irs)&&(i<ire))
				Blm.set_Trlm(i, l, m, z * sqrt(1./5) );
	}
END_FIELD

BEGIN_FIELD( "curfree", "current free multipole (imposed)" )
	CURRENT_FREE	// mark magnetic field as current-free
	l=1;	m=0;		// default to axial dipole
	double x = 1.0;		// default to pure external source
	sscanf(args,"%d,%d,%lf",&l,&m,&x);
	if (r[irs] == 0.0)	x = 1.0;		// no internal source possible (divergence).
	v = 1.0-x;
	PRINTF0("   + l = %d, m = %d, %3.2lf external, %3.2lf internal\n", l,m, x,v);
	for (i=irs; i <= ire; i++) {
		rr = Blm.radius(i);
		double z = 0.0;
		if (x != 0.0)	z += x*pow(rr, l);		// source externe
		if (v != 0.0)	z += v*pow(rr, -(l+1));		// source interne
		Blm.set_Prlm(i, l, m,  b0*z );
	}
	if (v != 0.0) {		// internal source imposed
		i = irs-1;
		rr = Blm.radius(i);
		double z = v*pow(rr, -(l+1));
		Blm.set_Prlm(i, l, m,  b0*z );
	}
	if (x != 0.0) {		// external source imposed
		i = ire+1;
		rr = Blm.radius(i);
		double z = x*pow(rr, l);
		Blm.set_Prlm(i, l, m,  b0*z );
	}
END_FIELD

BEGIN_FIELD( "toraxi", "axisymmetric toroidal field" )
	l=1; m=0;
	for (i=irs; i <= ire; i++) {
		rr = Blm.radius(i);
		z = Y10_ct*rr*(1.-rr);          // Toroidal vanish at both ends.
		Blm.set_Trlm(i, l, m,  b0* z );
	}
END_FIELD

BEGIN_FIELD( "dj08", "Jault 2008 (not current-free) normalized version" )
	for (i=irs; i <= ire; i++) {
		rr = Blm.radius(i);
	  if (rr != 0.0) {
		l=1; m=0;
			v = pi * rr;
			z = ((sin(v)/v-cos(v))/v - 0.3*(sin(2*v)/(2*v)-cos(2*v))/(2*v)) *sqrt(4.*pi/(2*l+1));	// j1(pi*rr) - 0.3*j1(2*pi*rr)
			Blm.set_Prlm(i, l, m,  b0* z );
		l=3; m=0;
			v = 5.7635 * rr;
			z = -0.2*((sin(v)*(3./(v*v)-1.)-3.*cos(v)/v)/v) *sqrt(4.*pi/(2*l+1));	// -0.2*j3(k*rr)
			Blm.set_Prlm(i, l, m,  b0* z );
	  }
	}
END_FIELD

BEGIN_FIELD( "dj3D", "3D based on Jault 2008 (dipole symmetry, not current-free, normalized version, no toroidal)" )
	double b1 = 0.0;
	sscanf(args,"%lf",&b1);
	PRINTF0("   + b1 = %g\n", b1);
	for (i=irs; i <= ire; i++) {
		rr = Blm.radius(i);
	  if (rr != 0.0) {
		l=1; m=0;
			v = pi * rr;
			z = ((sin(v)/v-cos(v))/v - 0.3*(sin(2*v)/(2*v)-cos(2*v))/(2*v));	// j1(pi*rr) - 0.3*j1(2*pi*rr)
			Blm.set_Prlm(i, l, m,  b0* z *sqrt(4.*pi/(2*l+1)) );
//              Blm.set_Trlm(i, l, m,  10.0 * b0*(rr-1.)*(rr-0.35)* z *sqrt(4.*pi/(2*l+1)) );
		l=MRES*2+1; m=MRES;
			if (MMAX>0) Blm.set_Prlm(i, l, m,  10.*rr*rr/(l*l) * b0* b1*z *sqrt(4.*pi/(2*l+1)) );
		l=3; m=0;
			v = 5.7635 * rr;
			z = -0.2*((sin(v)*(3./(v*v)-1.)-3.*cos(v)/v)/v);	// -0.2*j3(k*rr)
			Blm.set_Prlm(i, l, m,  b0* z *sqrt(4.*pi/(2*l+1)) );
		l=MRES*2+4; m=MRES;
			if (MMAX>0) Blm.set_Prlm(i, l, m,  10.*rr*rr/(l*l) * b0* b1*z *sqrt(4.*pi/(2*l+1)) );
	  }
	}
END_FIELD

BEGIN_FIELD( "quad3D", "3D quadrupole symmetry (not current-free, normalized version)" )
	double b1 = 0.0;
	sscanf(args,"%lf",&b1);
	PRINTF0("   + b1 = %g\n", b1);
	for (i=irs; i <= ire; i++) {
		rr = Blm.radius(i);
      if (rr != 0.0) {
        l=2; m=0;
                v = pi * rr;
                z = ((sin(v)/v-cos(v))/v - 0.3*(sin(2*v)/(2*v)-cos(2*v))/(2*v));        // j1(pi*rr) - 0.3*j1(2*pi*rr)
                Blm.set_Prlm(i, l, m,  b0* z *sqrt(4.*pi/(2*l+1)) );
        l=MRES+2; m=MRES;
                if (MMAX>0) Blm.set_Prlm(i, l, m,  10.*rr*rr/(l*l) * b0* b1*z *sqrt(4.*pi/(2*l+1)) );
        l=4; m=0;
                v = 5.7635 * rr;
                z = -0.2*((sin(v)*(3./(v*v)-1.)-3.*cos(v)/v)/v);        // -0.2*j3(k*rr)
                Blm.set_Prlm(i, l, m,  b0* z *sqrt(4.*pi/(2*l+1)) );
        l=MRES+5; m=MRES;
                if (MMAX>0) Blm.set_Prlm(i, l, m,  10.*rr*rr/(l*l) * b0* b1*z *sqrt(4.*pi/(2*l+1)) );
	  }
	}
END_FIELD

BEGIN_FIELD( "bna3D", "3D for bna runs (not current-free, normalized version)" )
	double b1 = 0.0;
	sscanf(args,"%lf",&b1);
	PRINTF0("   + b1 = %g\n", b1);
	for (i=irs; i <= ire; i++) {
		rr = Blm.radius(i);
	  if (rr != 0.0) {
		l=1; m=0;
			v = pi * rr;
			z = ((sin(v)/v-cos(v))/v - 0.3*(sin(2*v)/(2*v)-cos(2*v))/(2*v)) *sqrt(4.*pi/(2*l+1));   // j1(pi*r) - 0.3*j1(2*pi*r)
			Blm.set_Prlm( i, l, m, b0* z );
		l=MRES+1; m=MRES;
       		Blm.set_Prlm( i, l, m, b0* b1*z);
		l=3; m=0;
			v = 5.7635 * rr;
			z = -0.2*((sin(v)*(3./(v*v)-1.)-3.*cos(v)/v)/v) *sqrt(4.*pi/(2*l+1));   // -0.2*j3(k*r)
			Blm.set_Prlm( i, l, m, b0* z );
		l=MRES+4; m=MRES;
			Blm.set_Prlm( i, l, m , b0* b1*z );
		l=1; m=0;
			z = Y10_ct*rr*(1.-rr);
		//	Blm.set_Trlm(i, l, m,  b0* z );		// add a toroidal field
	  }
	}
END_FIELD

BEGIN_FIELD( "potential", "potential field imposed at boundaries (imposed)" )
	CURRENT_FREE	// mark magnetic field as current-free
	int iref, i0, i1;
	char arg2[4];
	char fname[48];
	std::vector<cplx> sh(NLM);

	iref = sscanf(args, "%47[^,],%3s",fname, arg2);
	if ((iref == 2)&&(arg2[0] == 'o')) {
		iref=ire;	i0=irs;		i1=ire+1;	// outer field includes outer boundary.
	} else {
		iref=irs;	i0=irs-1;	i1=ire;		// inner field includes inner boundary.
	}
	load_sh_text(fname, &sh.front(), NULL);	// read data from file (as poloidal scalar at a fixed r)

	for (i=i0; i <= i1; i++) {
		rr = Blm.radius(i);
		for (l=0; l<=LMAX; l++) {
			if (iref == irs) {
				z = pow(rr/r[iref], -l-1);	// internal field
			} else {
				z = pow(rr/r[iref], l);	// external field;
			}
			for (m=0; m<=MMAX*MRES; m+=MRES) {
				Blm.set_Prlm(i, l, m, b0*z* sh[ LM(l, m) ]);
			}
		}
	}
END_FIELD

BEGIN_FIELD( "magBC", "externally imposed magnetic boundary conditions (imposed)")
	l=1;	m=0;		// default l,m
	sscanf(args,"%d,%d",&l,&m);
	PRINTF0("   + l=%d, m=%d\n",l,m);
	i = ire+1;		// the boundary condition is stored in a ghost shell.
		Blm.set_Prlm(i, l, m, b0 * Y10_ct );
END_FIELD

BEGIN_FIELD( "geojet", "magnetic field counterpart of geojet" )
	double *Uth, *Uph;
	double sig2, s, s0, d2;
	int im,it;

	s0 = 0.5*(r[NM] + r[NG]);
	sig2 = 0.0025;		// default spatial size
	sscanf(args,"%lf",&sig2);		// read spatial size from args.
	PRINTF0("   + sig2 = %g\n",sig2);

	Uph = (double*) fftw_malloc(sizeof(double) * NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	Uth = (double*) fftw_malloc(sizeof(double) * NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	for (int ir=Ulm.irs; ir<=Ulm.ire; ir++)		// in the fluid volume.
	{
		for (int im=0; im<NPHI; im++) {
			for (int it=0; it<NLAT; it++) {
				s = r[ir]*st[it];
				d2 = (s-s0)*(s-s0);
				Uph[im*NLAT + it] = b0 * s * exp(- d2 / sig2);
				Uth[im*NLAT + it] = 0.0;
			}
		}
		spat_to_SHsphtor( shtns, Uth, Uph, Blm.Pol[ir], Blm.Tor[ir] );	// go to spectral space.
		for (int im=0; im<NLM; im++) Blm.Pol[ir][im] = 0.0;		// keep toroidal only
	}
	fftw_free(Uth);		fftw_free(Uph);
END_FIELD

BEGIN_FIELD( "geojet_m1", "magnetic field counterpart of geojet for m=1 uniform field" )
        double *Uth, *Uph;
        double sig2, s, s0, d2;
        int im,it;

        s0 = 0.5*(r[NM] + r[NG]);
        sig2 = 0.0025;          // default spatial size
        sscanf(args,"%lf",&sig2);               // read spatial size from args.
        PRINTF0("   + sig2 = %g\n",sig2);

        Uph = (double*) fftw_malloc(sizeof(double) * NLAT*(NPHI+2));    // alloc memory for spatial field (fftw-ready)
        Uth = (double*) fftw_malloc(sizeof(double) * NLAT*(NPHI+2));    // alloc memory for spatial field (fftw-ready)
        for (int ir=Ulm.irs+100; ir<=Ulm.ire-100; ir++)         // in the fluid volume.
        {
                for (int im=0; im<NPHI; im++) {
                        double bb = b0 * cos(phi_rad(im));
                        for (int it=0; it<NLAT; it++) {
                                s = r[ir]*st[it];
                                d2 = (s-s0)*(s-s0);
                                Uph[im*NLAT + it] = bb * s * exp(- d2 / sig2);
                                Uth[im*NLAT + it] = 0.0;
                        }
                }
                spat_to_SHsphtor( shtns, Uth, Uph, Blm.Pol[ir], Blm.Tor[ir] );  // go to spectral space.
                for (int im=0; im<NLM; im++) Blm.Pol[ir][im] = 0.0;             // keep toroidal only
        }
        free(Uth);      free(Uph);
END_FIELD


BEGIN_FIELD( "core", "Core-like magnetic field" )
	double b1 = 0.1;			// relative amplitude of surface poloidal field
	std::vector<double> p(NLAT*(NPHI+2));

	sscanf(args, "%lf",&b1);
	PRINTF0("   + b1 = %g\n", b1);
	b1 *= -0.53;		// scale so that b1 is a relative amplitude compared to sqrt(bs2)

	for (int ir=irs; ir<=ire; ir++) {
		p.clear();
		double rr = Blm.radius(ir);
		if (ir < Ulm.ir_bco) {
			double fr = pow(r[Ulm.ir_bco]-rr,2) * b0 * 4.0;
			for (int it=0; it<NLAT; it++) {
				double v=0;
				for (int l=2; l<=8; l+=2) v += pow(rr*st[it],l);
				v *= fr;
				for (int ip=0; ip<NPHI; ip++)  p[it+NLAT*ip] = v;
			}
		}
		SPAT_SH(&p[0], Blm.Pol[ir]);
		Blm.Pol[ir][LiM(2,0)] += b0*b1 * pow(rr, 2);		// add external quadrupole for coupling.
	}
	Blm.Pol[ire+1][LiM(2,0)] += b0*b1 * pow(Blm.radius(ire), 2);		// add external quadrupole for coupling (imposed).
END_FIELD

BEGIN_FIELD( "core2", "Core-like magnetic field (with m=1 dipole)" )
	double b1 = 0.1;			// relative amplitude of surface poloidal field
	std::vector<double> p(NLAT*(NPHI+2));

	sscanf(args, "%lf",&b1);
	PRINTF0("   + b1 = %g\n", b1);
	b1 *= -0.53;		// scale so that b1 is a relative amplitude compared to sqrt(bs2)

	for (int ir=irs; ir<=ire; ir++) {
		p.clear();
		double rr = Blm.radius(ir);
		if (ir < Ulm.ir_bco) {
			double fr = pow(r[Ulm.ir_bco]-rr,2) * b0 * 4.0;
			for (int it=0; it<NLAT; it++) {
				double v=0;
				for (int l=2; l<=8; l+=2) v += pow(rr*st[it],l);
				v *= fr;
				for (int ip=0; ip<NPHI; ip++)  p[it+NLAT*ip] = v;
			}
		}
		SPAT_SH(&p[0], Blm.Pol[ir]);
		Blm.Pol[ir][LiM(MRES,1)] += b0*b1 * Y11_st * rr/2.;		// add axial external dipole for coupling.
	}
	Blm.Pol[ire+1][LiM(2,0)] += b0*b1 * Y11_st * Blm.radius(ire)/2.;		// add axial external dipole for coupling (imposed).
END_FIELD

BEGIN_FIELD( "m0m1", "special taw field" )
	CURRENT_FREE	// mark magnetic field as current-free
	const double x = 1.0;		// default to pure external source
	double ratio = 0.0;	// ratio of non-axi / axi
	sscanf(args,"%lf",&ratio);
	for (i=irs; i <= ire; i++) {
		rr = Blm.radius(i);
		Blm.Pol[i][LiM(2,0)] = b0* Y10_ct * rr*rr;		// external quadrupole
		if (ratio != 0.0)
			Blm.Pol[i][LiM(MRES,1)] = b0*ratio * Y11_st * rr/2.;		// external axial dipole
	}
	i = ire+1;
		rr = Blm.radius(i);
		Blm.Pol[i][LiM(2,0)] = b0* Y10_ct * rr*rr;		// external quadrupole
		if (ratio != 0.0)
			Blm.Pol[i][LiM(MRES,1)] = b0*ratio * Y11_st * rr/2.;		// external axial dipole
END_FIELD

	return(0);		// return failure code.
}

/// This function is called to set initial velocity field value (see xshells.par)
int init_U0(PolTor &Ulm, char *name, double V0, char *args)
{
	cplx z;
	double v;
	int ir,l,m;
	int irs = Ulm.irs;
	int ire = Ulm.ire;

BEGIN_FIELD( "spinover", "Equatorial solid body rotation (l=1, m=1)" )
	for (ir=irs; ir<=ire; ir++) {
		l=1;	m=1;
			z = V0 * r[ir];
			Ulm.set_Trlm(ir, l, m, z * Y11_st);
	}
END_FIELD

BEGIN_FIELD( "sb_rot", "Axial solid body rotation (l=1, m=0)" )
	for (ir=irs; ir<=ire; ir++) {
		l=1;	m=0;
			z = V0 * r[ir];
			Ulm.set_Trlm(ir, l, m, z * Y10_ct);
	}
END_FIELD

BEGIN_FIELD( "precession", "Basic inviscid flow in a precessing spheroid: T(l=1,m=0+1) + P(l=2,m=1)" )
	double Po = 0.0;	// Poincare
	double flat = 0.0;	// flattening (or oblateness): sphere by default
	sscanf(args,"%lf,%lf", &Po, &flat);		// read params from args.
	PRINTF0("   + Po = %g, 1-c/a = %g\n",Po,flat);
	if ((Po==0) || (flat==0)) runerr("Po and 1-c/a must be non-zero\n");
	const double eta = flat * (2.-flat)/((1.-flat)*(1.-flat));
	const double V0_so  = V0 * Po*(2./eta + 1.) * Y11_st;		// amplitude of spin-over mode
	const double V0_pol = V0 * Po / 3 * sqrt(2*M_PI/15);		// amplitude of poloidal mode (l=2,m=1) [!! for orthonormal spherical harmonics !!]
	for (ir=irs; ir<=ire; ir++) {
		l=1;	m=0;
			z = V0 * r[ir];
			Ulm.set_Trlm(ir, l, m, z * Y10_ct);			// axial solid-body rotation
		l=1;	m=1;
			z = V0_so * r[ir];
			Ulm.set_Trlm(ir, l, m, z);			// spin-over
		l=2;	m=1;
			z = V0_pol * r[ir]*r[ir] * cplx(0.,-1.);
			Ulm.set_Prlm(ir, l, m, z);			// poloidal flow induced by non-sphericity (flattening)
	}
END_FIELD

BEGIN_FIELD( "bubble", "Free-fall bubble velocity field (Poloidal l=1, m=0)" )
	for (ir=irs; ir<=ire; ir++) {
		l=1;	m=0;
			z = V0 * 0.5*(r[ire]*r[ire] - r[ir]*r[ir])*r[ir];
			Ulm.set_Prlm(ir, l, m, z * Y10_ct);
			if (ir == ire)	// set analytic non-zero derivative at boundary.
				Ulm.set_Prlm(ir+1, l, m, -V0*r[ir]*r[ir] *Y10_ct );
	}
END_FIELD

BEGIN_FIELD( "dud02", "m=0 l=2 simple roll flow (eq 24 from Dudley & James 1989)" )
	for (ir=irs; ir<=ire; ir++) {
		l=2; m=0;
			z = r[ir]*sin(pi*r[ir]);
			Ulm.set_Trlm(ir, l, m,  V0* z );
			Ulm.set_Prlm(ir, l, m,  V0* z * 0.14 );
			if (ir == ire)	// set analytic non-zero derivative at outer boundary.
				Ulm.set_Prlm(ir+1, l, m, V0*0.14*(sin(pi*r[ir]) +r[ir]*pi*cos(pi*r[ir])) );
	}
END_FIELD

BEGIN_FIELD( "gubins02", "m=0 l=2 gubins flow (from Dudley & James 1989)" )
	for (ir=irs; ir<=ire; ir++) {
		l=2; m=0;
			z = -r[ir]*sin(2*pi*r[ir]) * tanh(2*pi*(1-r[ir]));
			Ulm.set_Trlm(ir, l, m,  V0* z );
			Ulm.set_Prlm(ir, l, m,  V0* z * 0.1 );
	}
END_FIELD

BEGIN_FIELD( "pekeris22", "m=2 l=2 j2 pekeris flow (eq 20-21 Dudley & James 1989)" )
	for (ir=irs; ir<=ire; ir++) {
		if (r[ir] != 0.0) {
		  l=2; m=0;
			v =  5.7634591968447*r[ir];
			z = 5.7634591968447 * ((3.0/(v*v*v) -1.0/v)*sin(v) - 3./(v*v) * cos(v));
			Ulm.set_Prlm(ir, l, m,  V0 * z );
			Ulm.set_Trlm(ir, l, m,  V0 * 5.7634591968447 * z );
		}
	}
END_FIELD

BEGIN_FIELD( "blob", "localized blob" )
	double rr,ph, cp, sp, x,y,z, x0,y0,z0, d2,sig2;
	double *S;
	cplx **X;		// pol or tor
	int im,it;

	if (strncmp(args, "tor", 3) == 0) {
		X = Ulm.Tor;		// toroial component
		PRINTF0("   + toroidal blob\n");
	} else {
		X = Ulm.Pol;		// poloidal component
		PRINTF0("   + poloidal blob\n");
	}
	sig2 = 0.002;		// default spatial size
	sscanf(args,"%*[^,],%lf",&sig2);		// read spatial size from args.
	PRINTF0("   + sig2 = %g\n",sig2);

	S = (double*) fftw_malloc(sizeof(double) * NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	for (ir=irs; ir<=ire; ir++) {
		x0 = 0.5*(r[NM] + r[NG]);	y0 = 0.0;	z0 = 0.0;
		rr = r[ir];
		for (im=0; im<NPHI; im++) {
			ph = 2.*(im-NPHI/2)*pi/(NPHI*MRES);	// phi centered around y0 = 0.0 so that mres periodicity is ok
			cp = rr*cos(ph);	sp = rr*sin(ph);
			for (it=0; it<NLAT; it++) {
				z = rr*ct[it];		x= cp*st[it];	y=sp*st[it];
				d2 = (x-x0)*(x-x0) + (y-y0)*(y-y0) + (z-z0)*(z-z0);
				S[im*NLAT + it] = V0 * exp(- d2 / sig2);
//				d2 = (x-x0)*(x-x0) + (y-y0)*(y-y0) + (z+z0)*(z+z0);
//				S[im*NLAT + it] -= V0 * exp(- d2 / sig2);
			}
		}
		spat_to_SH( shtns, S, X[ir] );	// go to spectral space.
	}
	free(S);
END_FIELD

BEGIN_FIELD( "vblob", "localized vector blob" )
	double rr,ph, cp, sp, x,y,z, x0,y0,z0, d2,sig2;
	double *S, *vr,*vt,*vp;
	int im,it;

	vr = (double*) fftw_malloc(sizeof(double) * 3*NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	if (vr == 0) runerr("vblob initialization: not enough memory.");
	vt = vr + NLAT*(NPHI+2);		vp = vr + 2*NLAT*(NPHI+2);

	if (strncmp(args, "r", 1) == 0) {
		S = vr;		// radial component
		PRINTF0("   + radial force blob\n");
	} else if (strncmp(args, "t", 1) == 0) {
		S = vt;		// theta component
		PRINTF0("   + theta force blob\n");
	} else {
		S = vp;		// phi component
		PRINTF0("   + azimutal force blob\n");
	}
	sig2 = 0.01;		// default spatial size
	sscanf(args,"%*[^,],%lf",&sig2);		// read spatial size from args.
	PRINTF0("   + sig2 = %g\n",sig2);

	ScalarSH* Sph = new ScalarSH;
	Sph->alloc(Ulm.ir_bci, Ulm.ir_bco);				// alloc temporary field

	for (ir=irs; ir<=ire; ir++) {
		x0 = 0.5*(r[NM] + r[NG]);	y0 = 0.0;	z0 = 0.0;
		rr = r[ir];
		memset(vr, 0, sizeof(double)*NLAT*(NPHI+2)*3);		// everything zero
		for (im=0; im<NPHI; im++) {
			ph = 2.*(im-NPHI/2)*pi/(NPHI*MRES);	// phi centered around y0 = 0.0 so that mres periodicity is ok
			cp = rr*cos(ph);	sp = rr*sin(ph);
			for (it=0; it<NLAT; it++) {
				z = rr*ct[it];		x= cp*st[it];	y=sp*st[it];
				d2 = (x-x0)*(x-x0) + (y-y0)*(y-y0) + (z-z0)*(z-z0);
				S[im*NLAT + it] = V0 * exp(- d2 / sig2);
//				d2 = (x-x0)*(x-x0) + (y-y0)*(y-y0) + (z+z0)*(z+z0);
//				S[im*NLAT + it] -= V0 * exp(- d2 / sig2);
			}
		}
		SPAT_SHV3(vr,vt,vp, Ulm.Tor[ir], Sph->get_data(0,ir), Ulm.Pol[ir]);
	}
	Ulm.curl_from_TQS(Sph, Ulm.ir_bci, Ulm.ir_bco, ::U);			// take the curl, includes MPI sync with tag ::U
	delete Sph;
	fftw_free(vr);
END_FIELD

BEGIN_FIELD( "geojet", "geostrophic axisymmetric azimutal jet" )
	double *Uth, *Uph;
	double sig2, s, s0, d2;
	int im,it;

	s0 = 0.5*(r[NM] + r[NG]);
	sig2 = 0.0025;		// default spatial size
	sscanf(args,"%lf",&sig2);		// read spatial size from args.
	PRINTF0("   + sig2 = %g\n",sig2);

	Uph = (double*) fftw_malloc(sizeof(double) * NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	Uth = (double*) fftw_malloc(sizeof(double) * NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	for (ir=irs; ir<=ire; ir++)		// in the fluid volume.
	{
		for (im=0; im<NPHI; im++) {
			for (it=0; it<NLAT; it++) {
				s = r[ir]*st[it];
				d2 = (s-s0)*(s-s0);
				Uph[im*NLAT + it] = V0 * s * exp(- d2 / sig2);
				Uth[im*NLAT + it] = 0.0;
			}
		}
		spat_to_SHsphtor( shtns, Uth, Uph, Ulm.Pol[ir], Ulm.Tor[ir] );	// go to spectral space.
		for (im=0; im<NLM; im++) Ulm.Pol[ir][im] = 0.0;		// keep toroidal only
	}
	fftw_free(Uth);		fftw_free(Uph);
END_FIELD

BEGIN_FIELD( "jupiter", "Alternating Jets (Jupiter-like)" )
	double *Uth, *Uph;
	double njets = 6.0;		// default number of jets.
	int im,it;

	sscanf(args,"%lf",&njets);		// read number of jets from args.
	PRINTF0("   + number of jets = %g\n",njets);

	Uph = (double*) fftw_malloc(sizeof(double) * NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	Uth = (double*) fftw_malloc(sizeof(double) * NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	for (ir=irs; ir<=ire; ir++)		// in the fluid volume.
	{
		for (im=0; im<NPHI; im++) {
			for (it=0; it<NLAT; it++) {
				Uph[im*NLAT + it] = V0 * r[ir]*st[it] * cos(njets * M_PI*(r[ir]*st[it]-1.));
				Uth[im*NLAT + it] = 0.0;
			}
		}
		spat_to_SHsphtor( shtns, Uth, Uph, Ulm.Pol[ir], Ulm.Tor[ir] );	// go to spectral space.
		for (im=0; im<NLM; im++) Ulm.Pol[ir][im] = 0.0;
	}
	free(Uth);	free(Uph);
END_FIELD

BEGIN_FIELD( "moss08", "axisymmetric roll flow (Moss 2008)" )
	double *Urr;
	int ip, it, lm;

	Urr = (double*) fftw_malloc(sizeof(double) * NLAT*(NPHI+2));	// alloc memory for spatial field (fftw-ready)
	for (ir=irs; ir<=ire; ir++)		// in the fluid volume.
	{
		double rr2 = (r[ire]-r[ir])*(r[ir]-r[irs]);
		if (r[irs] != 0.0)		// avoid singularity at r=0
			rr2 /= r[ir];
		rr2 *= rr2 * V0*4.0;
		for (ip=0; ip<NPHI; ip++) {
			for (it=0; it<NLAT; it++) {
				Urr[ip*NLAT +it] = rr2 * st[it]*st[it]*ct[it];	// m=4 (see Moss 2008)
			}
		}
		spat_to_SH( shtns, Urr, Ulm.Pol[ir] );		// go to spectral space.
		for (lm=0; lm<NLM; lm++) {
			Ulm.Pol[ir][lm] *= r[ir]*l_2[lm];
			Ulm.Tor[ir][lm] = 0.0;
		}
	}
	free(Urr);
END_FIELD

BEGIN_FIELD( "bench_fs", "initial velocity field for the full-sphere benchmark" )
	V0 *= sqrt(4.*M_PI);
	for (ir=irs; ir<=ire; ir++) {
		double rr = r[ir];		double r2 = rr*rr;		double r4 = r2*r2;		double r6 = r4*r2;
		l=2;	m=1;
			z = V0 *r2*cplx( (30 +1250./3*r2 -130*r4 -90*r6), 
					(105 -245*r2 +155*r4 -145./7*r6) );
				Ulm.set_Trlm(ir, l, m, z * sqrt(2./5) );
		l=1;	m=0;
			z = V0 *rr*(-54625./198 +350*r2 +625./2*r4 -325*r6);
				Ulm.set_Trlm(ir, l, m, z / sqrt(3) );
		l=3;	m=0;
			z = V0 *rr*r2*(45 -575*r2 +835*r4 -350*r6);
				Ulm.set_Trlm(ir, l, m, z / sqrt(7) );
	}
END_FIELD

BEGIN_FIELD( "elliptic", "elliptic base flow" )
	double ro2 = r[ire]*r[ire];
	for (ir=irs; ir<=ire; ir++) {
		double r2 = r[ir]*r[ir];
		l=2;	m=2;
			z = V0/3 * r2;	// * (1. - r2/ro2);		// must vanish at r=0 and r=ro.
			Ulm.set_Prlm(ir, l, m, z * 4.*sqrt(2.*M_PI/15.) );
	}
END_FIELD

	return(0);		// return failure code.
}

int init_T0(ScalarSH &Tlm, char *name, double T0, char *args)
{
	cplx z;
	int ir,l,m;
	int irs = Tlm.ir_bci;
	int ire = Tlm.ir_bco;

BEGIN_FIELD( "internal", "homogeneous internal heating profile (l=0)" )
	for (ir=irs; ir<=ire; ir++) {
		l=0;	m=0;
			z = (T0/6) * (r[ire]*r[ire] -  r[ir]*r[ir]);
			Tlm.set_rlm(ir, l, m, z * Y00_1);
	}
END_FIELD

BEGIN_FIELD( "flux", "fixed temperature flux (l=0)" )
	if (r[irs] == 0) runerr("fixed flux not supported for r=0.");
	for (ir=irs; ir<=ire; ir++) {
		l=0;	m=0;
			z = T0*r[ire]*(r[ire]/r[ir] - 1.0);
			Tlm.set_rlm(ir, l, m, z * Y00_1);
	}
END_FIELD

BEGIN_FIELD( "freezing", "solutal only powered constant-flux freezing inner-core (l=0)" )
	if (r[irs] == 0) runerr("freezing not supported for r=0.");
	double ri = r[irs]/r[ire];
	double C0 = T0/(1. - ri*ri*ri);
	for (ir=irs; ir<=ire; ir++) {
		l=0;	m=0;
			z = C0 * ( 1.0/r[ir] + 0.5*r[ir]*r[ir] - 1.5);
			Tlm.set_rlm(ir, l, m, z * Y00_1);
	}
END_FIELD

BEGIN_FIELD( "delta", "fixed temperature difference (l=0)" )
	if (r[irs] == 0) runerr("not supported for r=0.");
	for (ir=irs; ir<=ire; ir++) {
		l=0;	m=0;
			z = (-T0*r[irs]/(r[ire]-r[irs])) * (r[ire]/r[ir] -1.0);
			Tlm.set_rlm(ir, l, m, z * Y00_1);
	}
	//Tlm.bci = BC_FIXED_TEMPERATURE;		Tlm.bco = BC_FIXED_TEMPERATURE;
END_FIELD

BEGIN_FIELD( "bench2001", "initial temperature and boundary conditions for the geodynamo benchmark (l=4,m=4)" )
	for (ir=irs; ir<=ire; ir++) {
		l=4;	m=4;
			double x2 = 2*r[ir]-r[irs]-r[ire];
			x2 *= x2;
			z = T0 * (1. - 3.*x2 + 3.*x2*x2 - x2*x2*x2);	// the factor 210/sqrt(17920*pi) is included in the spherical harmonic definition.
			if ((ir>irs)&&(ir<ire))
				Tlm.set_rlm(ir, l, m, z);
	}
END_FIELD

BEGIN_FIELD( "bench_fs", "initial temperature perturbation for the full-sphere benchmark (l=3,m=3)" )
	for (ir=irs; ir<=ire; ir++) {
		l=3;	m=3;
			z = T0 * r[ir]*r[ir]*r[ir]*(1.-r[ir]*r[ir]);
			if ((ir>irs)&&(ir<ire))
				Tlm.set_rlm(ir, l, m, z);
	}
END_FIELD

BEGIN_FIELD( "thermochem", "thermochemical codensity profile (l=0) see Aubert et al. GJI 2009" )
	double fch = 0.75;				// default chemical power fraction.
	sscanf(args,"%lf",&fch);		// read spatial size from args.
	PRINTF0("   + fch = %g\n",fch);
	double ri3 = r[irs]*r[irs]*r[irs];
	double ro3 = r[ire]*r[ire]*r[ire];
	double xi = 0.5*(2*fch-1)/(ro3-ri3);
	double xt = (ro3*fch - ri3*(1-fch))/(ro3-ri3);

	for (ir=irs; ir<=ire; ir++) {
		l=0;	m=0;
			z = xi*r[ir]*r[ir]  + xt*r_1[ir];
			Tlm.set_rlm(ir, l, m, T0 * z * Y00_1);
	}
END_FIELD

BEGIN_FIELD( "strati", "stratified layer at the top of the core" )
        double delta = 0.05;                    // layer size.
        sscanf(args,"%lf",&delta);              // read size from args.
        PRINTF0("   + delta = %g\n",delta);
        double r0 = r[ire]*(1.0-delta);
        for (ir=irs; ir<=ire; ir++) {
                l=0;    m=0;
                double z = 0.0;
                if (r[ir] > r0)   z = r[ir]-r0;
                Tlm.set_rlm(ir, l, m, z * Y00_1);
        }
END_FIELD

	return(0);		// return failure code.
}

int init_Phi0(ScalarSH &Tlm, char *name, double g0, char *args)
{
	cplx z;
	int ir,l,m;
	int irs = 0;
	int ire = NR-1;

BEGIN_FIELD( "radial", "radial gravity increasing linearly with r (l=0)" )
	g0 *= Y00_1 / (2*r[ire]);	// input value is gravity at the outer shell.
	for (ir=irs; ir<=ire; ir++) {
		l=0;	m=0;
			z = g0 * r[ir]*r[ir];
			Tlm.set_rlm(ir, l, m, z);
	}
END_FIELD

BEGIN_FIELD( "vertical", "constant gravity along z (l=1)" )
	g0 *= -Y10_ct;		// input value is g, downward (-e_z)
	for (ir=irs; ir<=ire; ir++) {
		l=1;	m=0;
			z = g0 * r[ir];
			Tlm.set_rlm(ir, l, m, z);
	}
END_FIELD

BEGIN_FIELD( "centrifuge", "centrifugal force (l=0+2)" )
	g0 *= g0 * 0.5*(4.*sqrt(M_PI)/3);		// orthonormal SH, input value is Omega.
	for (ir=irs; ir<=ire; ir++) {
		z = g0 * (r[ir]*r[ir]);
		l=0;	m=0;
			Tlm.set_rlm(ir, l, m, z);
		l=2;	m=0;
			Tlm.set_rlm(ir, l, m, -1.*z/sqrt(5.));
	}
END_FIELD

	return(0);		// return failure code.
}

#undef BEGIN_FIELD
#undef END_FIELD


#include "mparser.hpp"
mparser mp;		// math parser.

/// include a printable version of xshells.hpp
static const unsigned char xshells_h[] = {
	#include "xshells_h.hex"
	0	// string must end with 0
};

/// returns amplitude
double split_name_args_ampl(char *cmd, char *name, char *args)
{
	double ampl = 1.0;		// default amplitude.
	char *val;
	char dump[240];

	strcpy(dump, cmd);
	args[0] = 0;	// zero-terminated string.
	val = strchr(dump, '*');
	if (val) {
		*val++ = 0;		// split cmd and scaling.
		int res = mp.parse(val, &ampl);
		if (res) {
			PRINTF0("parsing '%s'", val);
			runerr("[load_init] parse error\n");
		}
	}
	sscanf(dump,"%[^ (\t]%*[ (\t]%[^)])",name,args);		// split name and args.
	return ampl;
}


void init_Frame(RefFrame &frame, char *cmd, double Omega0)
{
	char name[127], args[127];

	double amplitude = split_name_args_ampl(cmd, name, args);
	if (strcmp(name,"precessing") == 0) {
		double angle = M_PI_2;
		sscanf(args,"%lf",&angle);
		frame.set_precession(Omega0, amplitude, angle*M_PI/180.);
	} else
	if (strcmp(name,"librating") == 0) {
		double freq = 0.0;
		char axis = 'z';
		sscanf(args,"%lf,%c",&freq,&axis);
		frame.set_libration(Omega0, amplitude, freq, axis);
	} else
	if (strcmp(name,"nutating") == 0) {
		double freq = 0.0;
		sscanf(args,"%lf",&freq);
		frame.set_nutation(Omega0, amplitude, freq);
	} else
		runerr("unknown frame");
}

/// Return pointer to first non-whitespace char in given string.
///  from inih https://github.com/benhoyt/inih
static char* lskip(const char* s)
{
    while (*s && isspace((unsigned char)(*s)))
        s++;
    return (char*)s;
}

/// contains Job parameters read from .par file by \ref read_Par
struct JobPar {
	int iter_max, modulo, iter_save, nbackup;
	int uBCin, uBCout;		// boundary conditions for u
	int tBCin, tBCout;		// BC for t
	int cBCin, cBCout;		// BC for c
	double nu, eta, kappa, kappa_c;		// viscosity, magnetic diffusivity, thermal diffusivity, compositional diffusivity
	double Rbs, Rbe;		// radial limits for b
	double Rus, Rue;		// radial limits for u
	double Rts, Rte;		// radial limits for t
	double Rcs, Rce;		// radial limits for c
	double polar_opt_max;
	double C_vort, C_alfv, C_cori, C_u;	// for variable time-step.
	double dt_tol_lo, dt_tol_hi;	// for variable time-step.
	double rsat_ltr;		// for variable l-truncation (if enabled).
	int lmax_out, mmax_out;
	int prec_out;		// if 1 => single precision (default) otherwise double-precision.
	int sht_type, allow_restart;
	int no_j0xb0, cur_free;
	int Nin, Nout, NH;			// points in boundary layer (velocity).
	int dt_adjust;
	int no_ugradu, no_jxb;
	int plot, parity;
};

struct vartabd {	const char* name;		double *d; };		// double variables
struct vartabi {	const char* name;		int *i;	};			// integer variables
struct vartabs {	const char* name;		char **s;	const char *fmt; };		// string variables


// filenames or init commands for different fields :
char *ufile, *bfile, *u0file, *b0file, *rfile, *ffile, *tpfile, *tp0file, *phi0file, *cfile, *c0file, *framecmd;
char *nonlin = 0;

JobPar jpar;		///< job parameter structure

// .par file to variable mapping.
static vartabd vard[] = {
	{ "nu", &jpar.nu },  { "eta", &jpar.eta },  { "kappa", &jpar.kappa },  { "kappa_c", &jpar.kappa_c },
	{ "Omega0", &Omega0 },  { "Omega0_angle", &Omega0_angle },
#ifdef XS_DTS_POTENTIAL
	{ "eta_t", &eta_t },  { "alpha_t", &alpha_t },
#endif
#ifdef XS_HYPER_DIFF
	{ "hyper_nu", &h_nu },  { "hyper_kappa", &h_kappa }, { "hyper_diff_l0", &hyper_diff_l0 },
#endif
	{ "Rmin", &(jpar.Rbs) }, { "Ric", &(jpar.Rus) }, { "Rcmb", &(jpar.Rue) }, { "Rmax", &(jpar.Rbe) },
	{ "DeltaOmega", &a_forcing }, { "a_forcing", &a_forcing }, { "w_forcing", &w_forcing },
	{ "dtU", &dt }, { "dtB", &dt }, { "dt", &dt },		// aliases for time-step dt.
	{ "sht_polar_opt_max", &jpar.polar_opt_max },
	{ "C_vort", &jpar.C_vort }, { "C_alfv", &jpar.C_alfv }, { "C_cori", &jpar.C_cori }, { "C_u", &jpar.C_u },
	{ "dt_tol_lo", &jpar.dt_tol_lo }, { "dt_tol_hi", &jpar.dt_tol_hi },
	{ "backup_time", &tsave_limit },
	{ "rsat_ltr", &jpar.rsat_ltr },
	{ NULL, NULL }
};
static vartabi vari[] = {
	{ "NR", &NR },	{ "NH", &jpar.NH },	{ "Nlat", &NLAT },	{ "Lmax", &LMAX },
	{ "Mmax", &MMAX }, { "Mres", &MRES }, {"Nphi", &NPHI },
	{ "dt_adjust", &jpar.dt_adjust },
	{ "iter_max", &jpar.iter_max }, { "modulo", &jpar.modulo }, { "sub_iter", &jpar.modulo }, { "iter_save", &jpar.iter_save },
	{ "movie", &MAKE_MOVIE }, { "no_j0xb0", &jpar.no_j0xb0 }, { "current_free", &jpar.cur_free }, { "kill_sbr", &kill_sbr },
	{ "lmax_out", &jpar.lmax_out }, { "mmax_out", &jpar.mmax_out }, { "prec_out", &jpar.prec_out },
	{ "sht_type", &jpar.sht_type }, { "interp", &xsio_allow_interp }, { "restart", &jpar.allow_restart },
	{ "lmax_out_sv", &lmax_out_sv }, { "nbackup", &jpar.nbackup }, { "plot", &jpar.plot },
	{ "sconv_lmin", &sconv_lmin }, { "sconv_mmin", &sconv_mmin },
	{ "no_jxb", &jpar.no_jxb }, { "no_ugradu", &jpar.no_ugradu },
	{ "parity", &jpar.parity }, 
	{ NULL, NULL }
};
static struct vartabs vars[] = {
	{ "job", &job, "%239s" }, { "r", &rfile, "%239s" },  { "f", &ffile, "%239[^#\n\r]" },
	{ "u", &ufile, "%239[^#\n\r]" }, { "u0", &u0file, "%239[^#\n\r]" },
	{ "b" , &bfile, "%239[^#\n\r]" }, { "b0" , &b0file, "%239[^#\n\r]" },
	{ "tp", &tpfile, "%239[^#\n\r]" }, { "tp0", &tp0file, "%239[^#\n\r]" },
	{ "phi0" , &phi0file, "%239[^#\n\r]" }, { "frame", &framecmd, "%239[^#\n\r]" },
	{ "c", &cfile, "%239[^#\n\r]" }, { "c0", &c0file, "%239[^#\n\r]" },
	{ "nonlin", &nonlin, "%239[^#\n\r]" },
	{ NULL , NULL }
};

/// read parameters from xshells.par file (see \ref par_file).
/// Parameters are returned in a \ref JobPar structure.
void read_Par(int argc, char *argv[], int backup=1)
{
	static double tmp, tmp2, nin, nout;
	static int i, k, err, erri, tmpi, match, parse_error, argi;
	FILE *fp, *fpw;
	char *val;
	static char fname[120] = "xshells.par";
	char str[240];
	char str2[240];
	char name[60];
	char dump[240];

	argi=1;
	if ((argi<argc) && (argv[argi][0] != '-')) {		// par file given as argument ?
		strncpy(fname, argv[argi], 119);		fname[119]=0;
		argi++;	// go to next argument.
	}
	
	PRINTF0("[read_Par] reading parameters from '%s'...\n",fname);
	fp = fopen(fname,"r");
	if (fp == NULL) runerr("[read_Par] file not found !");
	if (i_mpi==0) fpw = fopen("tmp.par","w");	// keep the parameters for that job.

	// DEFAULT VALUES
	memset(&jpar, 0, sizeof(jpar));	// set evrything to zero by default.
	Omega0 = 1.0;		// global rotation is on by default.
	jpar.eta = 0;	jpar.nu = 0;		jpar.kappa = 0;		jpar.kappa_c = 0;		// if eta, nu or kappa is not set, copy the other value. (Pm=1)
	jpar.C_vort = 1000;		jpar.C_alfv = 5.5;		// default values for variable time-step.
	jpar.C_cori = 1.0;		jpar.C_u = 0.7;
	jpar.dt_tol_lo = 0.9;	jpar.dt_tol_hi = 1.05;	// default values for time-step tolerance range.
	jpar.dt_adjust = 0;		// no time-step adjustment by default.
	jpar.nbackup = 0;		// no backup limit by default.
	jpar.plot = 1;			// controls gnuplot: screen output by default, if available.
	#ifdef VAR_LTR
	jpar.rsat_ltr = VAR_LTR;	// default value for variable ltr.
	#else
	jpar.rsat_ltr = 0.0;	// default value for variable ltr.
	#endif
	MRES = 1;
	InnerCore.zero_out();	Mantle.zero_out();
	k=-1;	while (vars[++k].name != NULL) *vars[k].s = NULL;	// mark all files and string variables as unused.

	jpar.Rbs = 1.e290; 	jpar.Rbe = 0.;		// default radii
	jpar.Rus = 1.e290; 	jpar.Rue = 0.;
	jpar.Rts = 1.e290; 	jpar.Rte = 0.;
	jpar.uBCin = BC_NO_SLIP;	jpar.uBCout = BC_NO_SLIP;
	jpar.polar_opt_max = 1e-14;		// default SHT optimization (very safe).
	jpar.lmax_out = -1;		jpar.mmax_out = -1;	// auto = defaults to max values.
	jpar.prec_out = 2;			// double precision movie output by default.
 	jpar.sht_type = sht_gauss;	// default SHT type.
 	jpar.iter_max = 0;             jpar.modulo = 1;               jpar.iter_save = 1;    // default iteration numbers
 	jpar.allow_restart = 0;
 	nin = 0;	nout = 0;	jpar.NH = 0;
 	#ifdef NO_J0xB0
		jpar.no_j0xb0 = 1;		// legacy define, can be overriden by xshells.par
	#endif
	#ifdef XS_CUR_FREE
		jpar.cur_free = 1;		// legacy define, can be overriden by xshells.par
	#endif
	jpar.no_ugradu = 0;			jpar.parity = 0;		// compute u.grad(u) by default; and both parities.
	jpar.no_jxb = 0;			// compute j x b  by default.

	i=0;	// line counter.
	while (!feof(fp))
	{
		fgets(str, 239, fp);
		if (i_mpi==0) fputs(str, fpw);		// save file...
		i++;
		char* start = lskip(str);	// skip whitespaces at beginning of str
		if ((*start != 0) && (*start != '#')) {		// ignore commented lines (#) and empty lines.
		  parse_error = 1;
		  strcpy(str2, start);		// copy to str2 where we can modify it.
		  val = strchr(str2, '#');	if (val) *val = 0;			// remove comment.
		  val = strchr(str2, '=');
		  if (val) {
			*val++ = 0;		// split at '='.
			val = lskip(val);		// remove leading spaces.
			parse_error = 0;
			match = sscanf(str2,"%59s", name);		// get name of token (max 59 chars)
			err = mp.parse(start, &tmp);
			tmpi = tmp;		erri = err + (tmpi != tmp);

			if (err == 0) {		// assign double precision variables.
				k=-1;	while ((match) && (vard[++k].name != NULL))
					if (strcmp(name,vard[k].name) == 0) {	*vard[k].d = tmp;	match=0;  }
				if ((match)&&(strcmp(name,"t_forcing") == 0))	{
					w_forcing = (tmp != 0.0) ? 2.*M_PI/tmp : 0.0;
					k=0;	match=0;
				}
			}
			if (erri == 0) {
				k=-1;	while ((match) && (vari[++k].name != NULL))		// assign integer variables.
					if (strcmp(name,vari[k].name) == 0) {	*vari[k].i = tmpi;	match=0;  }
			}

			k=-1;	while ((match) && (vars[++k].name != NULL))		// assign string variables.
				if (strcmp(name,vars[k].name) == 0) {
					*vars[k].s = (char*) malloc(240);	sscanf(val, vars[k].fmt, *vars[k].s);	match=0;
				}

			if (match) {		// Boundary Conditions
				int err = 2 - sscanf(val, "%d%*[ ,:\t]%d", &tmpi, &k);
				//PRINTF0("%d :: %d x %d\n",err, tmpi, k);
				if (err != 0) parse_error = 1;
				match = 0;
				if (strcmp(name,"BC_U") == 0) {
					if (err == 0) {		jpar.uBCin = tmpi;		jpar.uBCout = k; 	}
				}
				else if (strcmp(name,"BC_T") == 0) {
					if (err == 0) {		jpar.tBCin = tmpi;		jpar.tBCout = k; 	}
				}
				else if (strcmp(name,"BC_C") == 0) {
					if (err == 0) {		jpar.cBCin = tmpi;		jpar.cBCout = k; 	}
				}
				else match = 1;
			}
			if (match) {
				parse_error = 0;
				int err = 2 - sscanf(val, "%119[^ ,:\t]%*[ ,:\t]%119[^ ,:\t]", dump, dump+120);
				//PRINTF0("%d :: %s x %s\n",err, dump, dump+120);
				if (err == 0) {
					err += mp.parse(dump, &tmp);
					err += mp.parse(dump+120, &tmp2);
				}
				if (err) parse_error = 1;
				match = 0;
				if (strcmp(name,"R_U") == 0) {
					if (err == 0) {		jpar.Rus = tmp;	jpar.Rue = tmp2; 	}
				}
				else if (strcmp(name,"R_B") == 0) {
					if (err == 0) {		jpar.Rbs = tmp;	jpar.Rbe = tmp2; 	}
				}
				else if (strcmp(name,"R_T") == 0) {
					if (err == 0) {		jpar.Rts = tmp;	jpar.Rte = tmp2; 	}
				}
				else if (strcmp(name,"R_C") == 0) {
					if (err == 0) {		jpar.Rcs = tmp;	jpar.Rce = tmp2; 	}
				}
				else if (strcmp(name,"N_BL") == 0) {
					if (err == 0) {		nin = tmp;			nout = tmp2; 	}
				}
				else match = 1;
			}
			if (match) {	// no match found
				parse_error = err;		// we may have defined a user variable in the parser
			}
		  }
		  if (parse_error) {
			PRINTF0(" parse error (line %d of %s) : '%s = %s'\n",i, fname, name, val);
			runerr("[Read_Par] malformed line in xshells.par\n");
		  }
		}
	}
	// SOME BASIC COMPUTATIONS
	if (nin < 1.0)  nin *= NR;		// interpret fractional values as a fraction from total.
	if (nout < 1.0) nout *= NR;
	jpar.Nin = nin;		jpar.Nout = nout;
	if ((jpar.NH > 0) && (nin == 0.0) && (nout == 0.0)) {
		jpar.Nout = jpar.NH/5;		jpar.Nin = jpar.NH-(jpar.NH/5);		// NH is deprecated, but can still be used
	}

/* PARSE COMMAND LINE OPTIONS */
	while (argi+1<argc) {
		match = 1;
		if (argv[argi][0] == '-') {		// we have an option
			k=-1;	while ((match) && (vars[++k].name != NULL))	{	// assign string variables.
				if (strcmp(argv[argi]+1,vars[k].name) == 0) {
					*vars[k].s = (char*) malloc(240);	sscanf(argv[argi+1], vars[k].fmt, *vars[k].s);	match=0;
				}
			}
			if ((match) && (strcmp(argv[argi]+1, "iter") == 0)) {		// override iteration number
				iter_from_file(argv[argi+1], &iter);	match=0;
			}
		}
		if (match) {
			sprintf(dump, "command line option '%s' not understood (or missing argument) !",argv[argi]);
			runerr(dump);
		}
		argi+=2;
	}

	if (job == NULL) runerr("job name was not defined.");
	fclose(fp);
	if (i_mpi==0) {
		fflush(stdout);		// when writing to a file.
		fclose(fpw);
		if (backup) {
			sprintf(str, "%s.%s",fname,job);	rename("tmp.par", str);		// rename file.
			// saves xshells.hpp used at compile time.
			sprintf(str, "xshells.hpp.%s",job);	fpw = fopen(str,"w");
			fwrite(xshells_h, 1, strlen((char*)xshells_h), fpw);		fclose(fpw);
		}
	}
	#ifdef XS_MPI
		MPI_Barrier(MPI_COMM_WORLD);
	#endif
}


/// load or initialize field.
/// Warning, this resets boundary conditions !
double load_init(char* fname, PolTor *Vlm)
{
	double ampl;
	double ftime = 0.0;
	int res;
	FieldInfo jinfo;
	char args[120], name[60];
	double lscale = 0.0;		// correlation length scale for random fields.

	if (Vlm == NULL) runerr("[load_init] try to load unallocated field");

	Vlm->zero_out();		// start with zero everywhere.
	if (fname == NULL) {
		PRINTF0("   + zero\n");
		return(0.0);
	}

	ampl = split_name_args_ampl(fname, name, args);
#ifdef XS_DEBUG
	PRINTF0("   + name = '%s', ampl = '%g', args = '%s'\n",name, ampl, args);
#endif

	if ( (strcmp(name, "0") == 0) || (ampl == 0.0) ) {
		PRINTF0("   + zero\n");
		return(0.0);
	}
#ifdef XS_SURF_PAIS
	if (strcmp(name, "surf_pais") == 0) {	// load sh surface data 
		pt_surf = load_poltor_surf_txt(args, ampl);
		calc_Usurf_to_vol(&U, 0.0);		// U should always be allocated.
		spat_to_PolSphTor(&U, Vlm->Pol, NULL, Vlm->Tor, NG, NM);
		return(0.0);
	}
	if (strcmp(name, "pc_modes") == 0) {	// load pc modes
		load_PC_surf("pc_modes.par", ampl);
		calc_Usurf_to_vol(&U, 0.0);		// U should always be allocated.
		spat_to_PolSphTor(&U, Vlm->Pol, NULL, Vlm->Tor, NG, NM);
		return(0.0);
	}
#endif

	res = Vlm->bco;		// use this to select imposed velocity or magnetic fields.
	Vlm->bci = BC_NONE;		Vlm->bco = BC_NONE;		/// set BC to none
	if (res == BC_MAGNETIC) {
		res = init_B0(*Vlm, name, ampl, args);
		if (res) {
			for (int lm=0; lm<NLM; lm++) {		// multiply potential imposed at boundaries by 2l+1 (as required by BC).
				Vlm->Pol[Vlm->irs-1][lm] *= (el[lm]+el[lm]+1.);
				Vlm->Pol[Vlm->ire+1][lm] *= (el[lm]+el[lm]+1.);
			}
		}
	} else {
		res = init_U0(*Vlm, name, ampl, args);
	}

	if (res == 0) {		// no field match, try file name and random :
	  int rand_sym = -1;
	  #ifndef XS_MPI
		lscale = 10. * Vlm->delta_r((Vlm->ir_bci+Vlm->ir_bco)/2);		// correlation length scale for random fields.
	  #endif
	  if (strcmp(name, "random") == 0) {		// random
		PRINTF0("   + Random field (correlation length=%f)\n", lscale);
		rand_sym = 0;
	  } else if (strcmp(name, "rands") == 0) {		// random, symmetric only
		PRINTF0("   + Random symmetric field (correlation length=%f)\n", lscale);
		rand_sym = 2;
	  } else if (strcmp(name, "randa") == 0) {		// random, anti-symmetric only
		PRINTF0("   + Random anti-symmetric field (correlation length=%f)\n", lscale);
		rand_sym = 1;
	  }
	  if (rand_sym >= 0) {
		Vlm->add_random(ampl, 0, MMAX, rand_sym);
		#ifndef XS_MPI
		Vlm->filter_scale(lscale);
		#endif
	  } else {
		PRINTF0("   + loading from file \"%s\" ...\n",name);
		if ( load_FieldInfo(name, &jinfo) ) {
			Vlm->load(name, &jinfo);		if (i_mpi==0) print_FieldInfo(&jinfo);		// load from file.
			ftime = jinfo.t;
		} else {
	#ifndef XS_MPI
			load_PolTor_text(name, Vlm);
	#else
			runerr("file not found.");
	#endif
		}
		if (ampl != 1.0) Vlm->scale(ampl);
	  }
	}

	#ifdef XS_MPI
		Vlm->sync_mpi();		// exchange ghost shells.
	#endif
	if (ampl != 1.0) PRINTF0("   + amplitude scaled by %g\n",ampl);
	return(ftime);
}

/// load or initialize field.
/// Warning, this resets boundary conditions !
double load_init(char* fname, ScalarSH *Tlm)
{
	double ampl;
	double ftime = 0.0;
	int res;
	FieldInfo jinfo;
	char args[120], name[60];
	double lscale = 0.0;		// correlation length scale for random fields.

	if (Tlm == NULL) runerr("[load_init] try to load unallocated field");

	Tlm->zero_out();		// start with zero everywhere.
	if (fname == NULL) {
		PRINTF0("   + zero\n");
		return(0.0);
	}

	ampl = split_name_args_ampl(fname, name, args);
#ifdef XS_DEBUG
	PRINTF0("   + name = '%s', ampl = '%g', args = '%s'\n",name, ampl, args);
#endif

	if ( (strcmp(name, "0") == 0) || (ampl == 0.0) ) {
		PRINTF0("   + zero\n");
		return(0.0);
	}

	if (fname == phi0file) {
		res = init_Phi0(*Tlm, name, ampl, args);		// gravity field.
	} else
		res = init_T0(*Tlm, name, ampl, args);			// temperature field.

	if (res == 0) {		// no field match, try file name and random :
	  int rand_sym = -1;
	  #ifndef XS_MPI
		lscale = 10. * Tlm->delta_r((Tlm->ir_bci+Tlm->ir_bco)/2);		// correlation length scale for random fields.
	  #endif
	  if (strcmp(name, "random") == 0) {		// random
		PRINTF0("   + Random field (correlation length=%f)\n", lscale);
		rand_sym = 0;
	  } else if (strcmp(name, "rands") == 0) {		// random, symmetric only
		PRINTF0("   + Random symmetric field (correlation length=%f)\n", lscale);
		rand_sym = 2;
	  } else if (strcmp(name, "randa") == 0) {		// random, anti-symmetric only
		PRINTF0("   + Random anti-symmetric field (correlation length=%f)\n", lscale);
		rand_sym = 1;
	  }
	  if (rand_sym >= 0) {
		Tlm->add_random(ampl, 0, MMAX, rand_sym);
		#ifndef XS_MPI
		Tlm->filter_scale(lscale);
		#endif
	  } else {
		PRINTF0("   + loading from file \"%s\" ...\n",name);
		if ( load_FieldInfo(name, &jinfo) ) {
			Tlm->load(name, &jinfo);		if (i_mpi==0) print_FieldInfo(&jinfo);		// load from file.
			ftime = jinfo.t;
		} else runerr("file not found.");
		if (ampl != 1.0) Tlm->scale(ampl);
	  }
	}
	#ifdef XS_MPI
		Tlm->sync_mpi();		// exchange ghost shells.
	#endif
	if (ampl != 1.0) PRINTF0("   + amplitude scaled by %g\n",ampl);
	return(ftime);
}

