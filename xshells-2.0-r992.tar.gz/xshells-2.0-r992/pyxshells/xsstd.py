from pylab import *
from numpy import *
from pyxshells import *
import shtns
import xsplot
import sys

if len(sys.argv) != 7:
    print('  usage: %s field_avg base ext istart iend istep' % sys.argv[0])
    exit()

favg = sys.argv[1] # average field to be removed
base = sys.argv[2] # 'fieldU_'
ext = sys.argv[3]  # 'st1ns_hr2'
istart = int(sys.argv[4])  # 37
iend = int(sys.argv[5])    # 423
istep = int(sys.argv[6])   # 1

def save_merid(filename, r, ct, V):
	b = zeros((len(r)+1, len(ct)+1))
	b[1:,0] = r
	b[0,1:] = ct
	b[1:,1:] = V
	savetxt(filename, b)

Alm = load_field( favg )		# load average field (to be subtracted)
nr = Alm.ire - Alm.irs + 1

info,r =get_field_info('fieldU_%04d.%s' % (istart,ext))
sh = shtns.sht(info['lmax'], info['mmax'], info['mres'])
sh.set_grid(nl_order=2, flags=shtns.sht_gauss)
sh.print_info()
Y00_1 = sh.sh00_1()
l2 = sh.l*(sh.l+1)

U2avg = zeros((nr, sh.nlat))
count = 0
for i in range(istart, iend+1, istep):
	try:
		Ulm = load_field( '%s%04d.%s' % (base,i ,ext), lazy=False)
	except FileNotFoundError:
		print('[%04d] missing file' % i)
	else:
		print('[%04d]\r' % i)
		count += 1
		# compute fluctuations
		Ulm.data -= Alm.data		# subtract average
		for ir in range(Ulm.irs, Ulm.ire+1):
			if Ulm.ncomp() == 2:
				ur_lm = Ulm.rad(ir).astype(complex128)
				us_lm = Ulm.sph(ir).astype(complex128)
				ut_lm = Ulm.tor(ir).astype(complex128)
				ur,ut,up = sh.synth(ur_lm, us_lm, ut_lm)
				er = square(ur) + square(ut) + square(up)	# energy of fluctuations
			else:
				s_lm = Ulm.sh(ir).astype(complex128)
				s = sh.synth(s_lm)
				er = square(s)       # energy of fluctuations
			U2avg[ir-Ulm.irs,:] += mean(er,axis=1)

print("%d files averaged" % count)

U2avg /= 2*count		# kinetic energy: divide by 2.

save_merid('o_Efluct',r,sh.cos_theta, U2avg)

